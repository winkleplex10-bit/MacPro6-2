# MacPro6,2 LGA1700 CPU board (CB) - rev A part-level floorplan fl2.1 (4 x DDR5 UDIMM, single 12 V entry)

Primary CPU board since 2026-10-01 (Aidan: skip COM-HPC; the carrier `/workspace/kicad/macpro62-cpu-carrier/` is the archived fallback).
Plan / feasibility study: `/workspace/macpro62-lga1700-board-plan.md`. Spec: `macpro62-architecture-spec-v0.2.md` §6.

Rebuild (KiCad 9, system python3 with pcbnew; needs openpyxl, ezdxf, shapely and the Intel ballout xlsx in
`/workspace/mp62-spec-refs/lga1700/`):

    python3 tools/make_placeholders.py
    rm -f macpro62_lga1700.kicad_pcb macpro62_lga1700.kicad_pro macpro62_lga1700.kicad_prl
    python3 tools/build_pcb.py          # writes fitcheck_floorplan.txt
    python3 tools/postprocess.py        # 10L stackup + net classes
    kicad-cli pcb drc --severity-all -o drc_report.txt macpro62_lga1700.kicad_pcb    # 0 violations
    sh tools/render.sh macpro62_lga1700.kicad_pcb floorplan                          # floorplan.png / floorplan_notes.png

Frame: x 0..156 right, y up from the board bottom (tab tip 1.722, shoulder 12.982, top 169.5); FRONT = socket/core side.

Contents (no nets, not routed):
- Edge.Cuts: stock riser outline (mirror-invariant above the shoulder, checked: 0.000 mm2) + Mini Cool Edge 224 tab (as the carrier).
- U1 LGA1700 land pattern: 1700 land positions from Intel 743844-001_S_LGA_Ballout.xlsx (public); pad 0.45 [Estimate];
  orientation assumes the Intel X/Y are a top view -> VERIFY. Land groups drawn on Dwgs.User (DDR top, PCIe bottom-right,
  DMI right, DDI bottom-left, VCCGT left, VCCCORE left/bottom of the cavity).
- U2 PCH: 1045 ball positions from Intel 743835_001_Ballout.xlsx (B760/H770/Z790 share it); pad 0.25 [Estimate].
- H1-H4 core holes D5 (69.5 x 55, fixed), H5-H8 contact-frame seat screws (own pattern), MP62 contact frame on Eco1.User.
- VRM: 7 x SiC654 (5x5) + 7 x Eaton FP4 (10.2 x 6.8 x 5.0) = 6 core + 1 GT phases, RT3628AE area; VCCIN_AUX, 1P05/1P8, PCH rails,
  VDD2, 5 V VIN_BULK areas.
- Back (fl2, 2026-10-01 ~18:30 ET): 4 x DDR5 UDIMM VERTICAL sockets (UMAX 90414 short latch, drawing C-90414 rev 3:
  body 141.7 x 6.3, seat <= 2.0, closed 142 / open-latch keep-out 152 on Dwgs.User) at the stock card centrelines
  x 6.5 / 15.8 / 140.55 / 149.85, y centre 95.6; 2DPC daisy chain J6 -> J7 (CH-A near -> far), J9 -> J10 (CH-B).
  Module top <= 33.25 mm off the back (stock DDR3 30.0 + seat) -> M-CC15. Stock DIMM-pair bodies drawn on Eco2.
  VRM power stages at x 11.15 so their vias fall in the corridor between the J7/J6 pad rows (Eco2). 12 V bulk CB1/CB2
  moved to x 19.7-36.3 / 120.2-136.8, y 39.7-70.3. Also M.2 2280, J3 MCIO RA (IOB-HS incl. 2 x DDI), BT1.
- 12 V (fl2.1, 2026-10-01 ~21:15 ET, from Aidan's stock photos): single entry at the LEFT lug pair only.
  LUG1 (x 27.95) / LUG2 (x 40.75), y 159.8, front, +-0.8 mm from the photo; 2 x 2 PTH per lug [Estimate];
  polarity TBD (M-CC7). LUG3/LUG4 and eFuse U12 removed; U11 TPS259851 (36, 146) feeds the whole CB (ILIM ~25 A).
  12 V plane L5+L6 >= 20 mm down the left edge to the VRM, >= 8 mm across the top band (Cmts notes at x 3, y 131-136).
  Right notch (x 108-132) = GPU bus-bar pass-through (Aidan ~21:19 ET), no CB lugs: rule area GPU_BUSBAR_PASSTHROUGH
  x 105-135, y 160.5-169.5 (notch + 3 mm [Proposal]), all copper layers, no footprints/pads/tracks/vias/pour.
  Sides re-checked against the back photo: DIMMs J6/J7/J9/J10 on B (288 SMD pads on B.Cu), U1/VRM/lugs on F.
- fl1 (2 x DDR5 SO-DIMM UMAX 90415-4015SR, lying flat in the strips) is the documented fallback:
  docs/fl1_sodimm_variant/ (render, fit check, build script; the SO-DIMM footprint stays in the library).
- Keep-outs: D12 around H1-H4 (no tracks/vias), backplate zone on B (no footprints), tab y < 6 (no vias/pour).
