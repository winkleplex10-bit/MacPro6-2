# MacPro6,2 build cost estimate (PCBs, components, cables, mechanical)

Prepared 2026-10-04, about 08:50 ET. All prices are in USD. **This is an estimate, not a quote.** Most boards are floorplans with placeholder footprints and no routing, so treat every figure as a range. JLC instant quotes and a cable-vendor quote will change these numbers.

Read-only inputs: the KiCad projects under `/workspace/kicad/` (copied to `/tmp` for analysis, nothing modified), `macpro62-io-board-plan.md`, `macpro62-lga1700-board-plan.md`, `macpro62-storage-board-plan.md`, `macpro62-interface-control.md` (rev 2.1), `macpro62-architecture-spec-v0.2.md`, `macpro62-face-module-spec-v0.1.md` and `mechanical/io_plate_v2/`.

## How to read this

- **Qty 1** means one machine built at JLC minimums:
  - 5 bare PCBs per rigid design. JLC's FR-4 minimum is 5.
  - **2 boards assembled.** JLC's Standard PCBA minimum is 2, so you get one assembled spare.
  - Port modules: 6 MOD-C, 4 MOD-A and 2 MOD-H assembled (MOD-H is held at the PCBA minimum of 2).
  - Parts are bought for every assembled board.
- **Qty 5** means five machines:
  - 5 PCBs per design, all 5 assembled, with no spare boards.
  - Port modules: 30 MOD-C, 20 MOD-A and 5 MOD-H.
  - Cables and mechanical parts are scaled ×5.
- The face template is a single development order in both columns.
- **Excluded** (prices listed separately at the end): the CPU, RAM, SSDs and the donor GPU card. The reused stock Mac Pro 6,1 enclosure, PSU, thermal core, fan, audio-jack flex and speaker are also excluded.
- **Fees** follow the JLC Standard PCBA fee table updated 2026-09-09:
  - setup: $25.56 single-sided, $51.12 double-sided
  - stencil: $8.21 single-sided, $16.42 double-sided
  - feeder loading: $1.53 per unique part
  - SMT: $0.0016 per joint; manual/THT: $0.0164 per joint
  - X-ray: tiered from $1.64 down to $0.082 per part
  - fixture: rigid $16.42, flex $49.25 (1–29 pcs) / $73.88 (30–99 pcs)
  - consignment: $0.142 per piece, plus $8 baking
  - The high end of each range adds +25 % and about $10 for global-sourcing and review extras.
- **Component prices** come from LCSC product pages fetched **2026-10-04**, using the 1- and 10-piece price breaks. Low and high per-board sums carry +8–20 % for attrition and minimum buys at qty 1, and +5–12 % at qty 5. Where a part is out of stock, the high end assumes a global-sourcing premium.
- **US import duty.** JLC's US DDP pre-collected rates (schedule of 2026-03-17) are PCB/SMT 35 %, 3D print 40 % and aluminium CNC 90 %. They are shown on a separate line, because they apply only if the order ships to the US. The user's time zone is America/Detroit.

## 1. Board facts from the KiCad files

| Board | KiCad file | Outline (bbox) | JLC billed area | Layers / stackup | Impedance classes (netclasses) | Min via (hole/pad) | Sides used | Placed fps | Design state |
|---|---|---|---|---|---|---|---|---|---|
| I/O main board | `macpro62-io-board/macpro62-io-board.kicad_pcb` | 101.1 × 173.7 mm (163 cm² real) | 175.6 cm² | 6L, 1.6 mm, JLC06161H-2116, ENIG | USB3 90 Ω, PCIe 85 Ω, DP/MDI 100 Ω, USB2 90 Ω | 0.30 / 0.45 | F + B (62 / 103 fps) | 165 on PCB; 485 in schematic BOM | Placement A0; **not routed**, small passives not placed |
| LGA1700 CPU board | `macpro62-lga1700/macpro62_lga1700.kicad_pcb` | 156.1 × 167.9 mm (247 cm² real) | 262 cm² | **10L**, 1.6 mm, **placeholder stackup** (no JLC code yet), ENIG, **bevelled card edge** (224 fingers) | DDR5 40 Ω SE, PCIe 85 Ω, USB/DDI 90 Ω | **0.15 / 0.25** | F + B (43 / 10) | 53 (mostly area placeholders) | Part-level floorplan fl2.1; no schematic; **not routed** |
| Backplane (HUB fp5) | `macpro62-backplane/backplane.kicad_pcb` | 122.1 × 122.1 mm round (117 cm² real) | 149 cm² | 6L, 1.6 mm, JLC06161H-2116, ENIG | PCIe 85 Ω, USB2/SATA 90 Ω | 0.30 / 0.60 (rule min 0.45) | F only | 29 (placeholders) | Floorplan; block-diagram stubs; **not routed** |
| Storage face SM-1 | `macpro62-storage-face/macpro62-storage-face.kicad_pcb` | 104.0 × 166.1 mm (170 cm² real) | 172.7 cm² | 6L, 1.6 mm, JLC06161H-2116, ENIG | PCIe 85 Ω, REFCLK 85 Ω, DISP 100 Ω, USB2 90 Ω | 0.30 / 0.60 | F + B (21 / 55) | 76 on PCB; 154 in BOM | Floorplan + full schematic (ERC 0); **not routed** |
| Face template | `macpro62-face-template/macpro62-face-template.kicad_pcb` | 104.0 × 166.1 mm | 172.7 cm² | 6L, JLC06161H-2116 | as SM-1 | 0.30 / 0.60 | F + B | 14 | Template only |
| MOD-C (USB-C) flex | `macpro62-io-modules/mod_usbc/mod_usbc.kicad_pcb` | 39.2 × 8.8 mm | panelised | 2L PI FPC 0.11 mm + 2 × FR4 1.0 stiffener | 90 Ω diff (JLC does not test FPC impedance; TDR coupon in `tdr/`) | 0.20 / 0.40; **min track 0.075 mm** | F | 4 | Routing open (8 unconnected) |
| MOD-A (USB-A) flex | `mod_usba/mod_usba.kicad_pcb` | 41.3 × 8.8 mm | panelised | as MOD-C | 90 Ω | as MOD-C | F (+THT legs) | 4 | Routed, DRC 0 |
| MOD-H (HDMI) flex | `mod_hdmi/mod_hdmi.kicad_pcb` | 44.2 × 9.4 mm | panelised | as MOD-C | 100 Ω | as MOD-C | F (+THT shell) | 4 | Routed, DRC 0 |
| GPU board (Face P) | none | 104 × 166 face outline (assumed) | 172.7 cm² | 8–10L, via-in-pad (face spec §3.8) | PCIe/DP + GDDR6 | — | F + B | — | **Not designed** |

**Module count per machine:**
- 6 × MOD-C (C1–C6, one design; the O-column modules are the same part rotated)
- 4 × MOD-A (A1–A4)
- 1 × MOD-H

The main board carries 11 DF40C-50DS receptacles (JM1–JM11). There are **no separate audio or RJ45 modules**:
- The 2 × RJ45 (Lingqiang C55547809 + JASN V24P05S magnetics) are on the I/O main board.
- Audio reuses the stock audio-jack flex through J28, driven by the CM108B codec and a PAM8302 amp on the I/O board.

## 2. Per-board summary (USD, before US import duty)

| Board / group | Qty 1 (one machine, JLC minimums) | Qty 5 (five machines) | Per machine at qty 5 |
|---|---|---|---|
| I/O main board (IOB) | $640 – $960 | $1,070 – $1,630 | $210 – $330 |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | $440 – $670 | $690 – $1,130 | $140 – $230 |
| LGA1700 CPU board (CB) | $1,210 – $2,560 | $1,990 – $3,930 | $400 – $790 |
| Backplane / base board (BP, HUB fp5) | $280 – $450 | $450 – $750 | $90 – $150 |
| Storage face board (SM-1, Face S) | $340 – $540 | $510 – $860 | $100 – $170 |
| Face template (MP62-FACE v0.1, fit-check / dev blank) | $100 – $160 | $100 – $160 | $20 – $30 |
| GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED | $950 – $2,460 | $1,780 – $4,670 | $360 – $930 |
| Cables | $250 – $2,260 | $800 – $3,910 | $160 – $780 |
| I/O plate and mechanical | $50 – $120 | $120 – $270 | $20 – $50 |
| Logistics | $100 – $220 | $150 – $320 | $30 – $60 |
| **Subtotal before import duty** | **$4,400 – $10,400** | **$7,700 – $17,600** | **$1,500 – $3,500** |
| US DDP import duty pre-collected by JLC (35 % on PCB/PCBA, 40 % on 3D prints, 90 % on Al CNC) | $1,250 – $2,430 | $1,990 – $3,790 | $400 – $760 |
| **Grand total, delivered to the US** | **$5,600 – $12,800** | **$9,700 – $21,400** | **$1,900 – $4,300** |

Without the rough GPU-board estimate, the subtotal before duty is $3,400 – $7,900 at qty 1 and $5,900 – $12,900 at qty 5. The cable line alone spans $250 – $2,260 at qty 1, because the custom MCIO quote could land anywhere in that range.

## 3. Line items

Line items are rounded to $5. **[Estimate]** means no vendor price was found. The basis column cites the source and its date.

| Board / group | Item | Qty 1 low | Qty 1 high | Qty 5 low | Qty 5 high | Duty class | Basis / source |
|---|---|---|---|---|---|---|---|
| I/O main board (IOB) | PCB fab: 6L JLC06161H-2116, 101.1 x 173.7 mm (bbox 175.6 cm2), 1.6 mm, ENIG, impedance 85/90/100 ohm, 0.30/0.45 vias | 60 | 90 | 60 | 90 | pcb | JLC 6L 100x100 x5 = $35.10 (jlcpcb.com/6-layer-pcb, 2026-10); scaled by area x1.0-1.5; qty 5 = same 5-pc order |
| I/O main board (IOB) | PCBA fees: double-sided, ~110 unique parts, ~3,200 SMT + ~30 THT joints, ~55 X-ray parts (QFN/USON) | 325 | 415 | 380 | 485 | pcb | JLC fee table 2026-09-09 (setup $51.12, stencil $16.42, feeder $1.53/part, X-ray, THT) |
| I/O main board (IOB) | Components (485 placements; LCSC per-unit ~$120-188/board) x assembled boards + attrition/MOQ | 260 | 450 | 625 | 1055 | pcb | LCSC product pages fetched 2026-10-04 (TPS65994AD C2864593 $2.81-3.25, TUSB1046A C702363 $4.13-4.24 [8 in stock], i226-V C26159200 $5.35-6.26, MCIO124 C4867471 $9.37-9.59 [0 stock], MCIO74 C5433520 $6.88-7.94, DF40C-50DS C424646 $0.44-0.55, ...); shortages priced at global-sourcing premium in the high |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | FPC fab, 2L PI 0.11 mm, ENIG, 2 x FR4 1.0 stiffeners each (<4 => no stiffener surcharge): MOD-C 39.2x8.8, MOD-A 41.3x8.8, MOD-H 44.2x9.4 mm, panelised | 70 | 140 | 100 | 200 | pcb | JLC FPC from $25/5 pcs (jlcpcb.com/blog/flex-pcb-cost-pricing-guide, 2026-09); qty1 = 10 C + 5 A + 5 H; qty5 = 30 C + 20 A + 5 H (+5 spare C); +20 % if the 0.075 mm (2.95 mil) min track stays (FPC difficulty fee) |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | FPC assembly fees: 3 designs x (setup $25.56 + stencil + flex fixture $49.25-73.88 + panel), THT legs hand/selective-soldered on MOD-A/MOD-H | 330 | 445 | 415 | 545 | pcb | JLC fee table 2026-09-09 (flex fixture 2 x $24.63 for 1-29 pcs, 3 x for 30-99) |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | Module components: receptacle (HYCW417 C5342202 $0.94-1.13 / HC-USB3.0-L137 C7501870 $0.10-0.12 / HYC79 HDMI C711353 $0.38-0.49) + DF40C-50DP (C424645 $0.55-0.66) + BL24C02F (C2828222 $0.08-0.10) + 0201 cap | 15 | 25 | 70 | 100 | pcb | LCSC 2026-10-04; HYCW417 only 196 in stock, USB-A alt kinghelm C2979037 has 2 in stock |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | SUS304 0.2 mm shield sleeves (11 per machine + spares); 0.2 mm is below JLCCNC sheet-metal minimum (0.5 mm), so photo-etch/hand-bent | 15 | 40 | 70 | 180 | none | modules README "$1-3 each" [Estimate]; photo-etch run setup $40-120 at qty 5 |
| Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine) | Printed cradles (3 groups) + clamp plates (3) MJF PA12 1.6 mm, dyed black; not modelled yet | 10 | 25 | 40 | 100 | 3d | JLC3DP MJF PA12 $0.275/g, parts from $1 (jlc3dp.com news 2025-08-13); [Estimate] $1.5-4 per part |
| LGA1700 CPU board (CB) | PCB fab: 10L, 156.1 x 167.9 mm (bbox 262 cm2), 1.6 mm, ENIG, 0.15/0.25 vias + POFV, DDR5 40 ohm SE / 85-90 ohm diff impedance, hard-gold bevelled 224-finger card edge, 5 pcs | 300 | 900 | 300 | 900 | pcb | JLC 10L: 2022 published eng. fee $136.82 + $171/m2 small batch (jlcpcb.com/news/high-precision-multi-layer-pcb-8-20-layer) + gold fingers/0.15 mm via/impedance extras; CB plan §9 estimate $450-1,000; instant quote needed (stackup is still a PLACEHOLDER, not a JLC10161H code) |
| LGA1700 CPU board (CB) | PCBA fees: double-sided, ~90 unique, ~9,500 joints (socket 1,700 + PCH 1,045 + 4 x 288 DIMM + ~2,000 passives), ~30 X-ray parts, consigned PCH + baking | 355 | 530 | 470 | 695 | pcb | JLC fee table 2026-09-09 + consignment T&C ($0.142/pc, $8 baking) |
| LGA1700 CPU board (CB) | Components ex-PCH (~$118-252/board): socket PE17007 C38520273 $4.95-5.79, RT3628AE C3249940, 7 x SiC654 C1852094, 7 x FP4-150-R C2454106 (0 stock), 4 x DDR5 UDIMM short-latch (not on LCSC; C2922443 long latch $4.44 as proxy), MCIO124, TPS259851 C31786575 $9.44-10.59, INA228, RP2350, SPI, rails, ~1,500-2,500 passives + bulk | 255 | 605 | 620 | 1410 | pcb | LCSC 2026-10-04 + CB plan §9 [Estimate for areas not yet designed] |
| LGA1700 CPU board (CB) | Z790 PCH FH82Z790 (consigned, loose broker stock; qty1 buys 2 + 2 spares, qty5 buys 5 + 3 spares) | 200 | 280 | 400 | 520 | none | CB plan §1.3: EUR 45-48 listings (unverified sellers), not stocked by LCSC/Mouser/Digi-Key |
| LGA1700 CPU board (CB) | Contact frame (CNC 7075) + steel backplate + springs/screws (own design, replaces the ILM) | 100 | 250 | 200 | 400 | cnc | CB plan §9: $100-250 (2 sets) / $200-400 (5 sets) [Estimate]; JLCCNC aluminium = 90 % US DDP rate |
| Backplane / base board (BP, HUB fp5) | PCB fab: 6L JLC06161H-2116, 122.1 x 122.1 mm round (bbox 149 cm2), 1.6 mm, ENIG, impedance 85/90 ohm | 50 | 80 | 50 | 80 | pcb | JLC 6L $35.10/100 cm2 x5, scaled x1.0-1.5 |
| Backplane / base board (BP, HUB fp5) | PCBA fees: single-sided (all 29 footprints on F), ~40 unique, ~1,400 SMT joints; Mini Cool Edge 224 + 2 x MCIO124 pegs/THT | 145 | 190 | 185 | 245 | pcb | JLC fee table 2026-09-09 |
| Backplane / base board (BP, HUB fp5) | Components (~$41-76/board): Amphenol ME1022410103011 Mini Cool Edge 224 (not on LCSC; brokers $6.14-10.08), 2 x MCIO124 RA (0 LCSC stock), RP2350, W25Q128, 2 x TMP1075, 3 x GH15, Micro-Fit, M.2 2242 socket, standby/main power blocks (placeholders), ~120 passives | 90 | 180 | 215 | 425 | pcb | LCSC 2026-10-04; unikeyic/htelec broker listings for ME1022410103011; power blocks [Estimate] |
| Storage face board (SM-1, Face S) | PCB fab: 6L JLC06161H-2116, 104.0 x 166.1 mm (bbox 172.7 cm2), 1.6 mm, ENIG, impedance 85/100 ohm | 60 | 90 | 60 | 90 | pcb | JLC 6L $35.10/100 cm2 x5, scaled x1.0-1.5 (storage plan §7 said $70-140) |
| Storage face board (SM-1, Face S) | PCBA fees: double-sided (BGA on F, sockets/power on B), ~45 unique, ~1,300 joints, BGA X-ray | 175 | 230 | 200 | 265 | pcb | JLC fee table 2026-09-09 |
| Storage face board (SM-1, Face S) | Components (~$44-84/board): ASM2824 (JLC C9900092023, price not shown; $15-40 [Unverified]), MCIO124 RA, 4 x LOTES APCI0107 C841661 $0.36-0.46, TPS259824 C2155766 $5.04-5.90, TPS56C215 C473372, INA228 C2887910 (0 stock), TMP1075 x2, ~110 passives | 95 | 200 | 235 | 470 | pcb | LCSC 2026-10-04 + storage plan §6 |
| Storage face board (SM-1, Face S) | 3.0 mm gap pad ~25 x 25 for the ASM2824 (bought separately) | 5 | 15 | 15 | 40 | none | storage plan §6 |
| Face template (MP62-FACE v0.1, fit-check / dev blank) | PCB fab: 6L JLC06161H-2116, 104.0 x 166.1 mm, ENIG, impedance netclasses only (no routing) | 60 | 90 | 60 | 90 | pcb | JLC 6L, 5 pcs; same order for qty 1 and qty 5 (it is a template, not one per machine) |
| Face template (MP62-FACE v0.1, fit-check / dev blank) | Optional connector kit on 2 boards (MCIO124 + MCIO74 + GH15 RA + INA228/shunt), hand-soldered | 40 | 70 | 40 | 70 | none | face spec §15 interface kit ~$24 (GPU) / $17 (storage), LCSC 2026-10-04 |
| GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED | PCB fab: assume 10L (face spec §3.8: 8-10L, via-in-pad) on the 104 x 166 face outline, 5 pcs | 220 | 650 | 220 | 650 | pcb | Scaled from the CB 10L estimate by area (0.66x) [Estimate] |
| GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED | PCBA fees for everything except the salvaged BGAs (double-sided, ~80 unique, ~4,000 joints) | 190 | 330 | 230 | 420 | pcb | JLC fee table [Estimate] |
| GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED | Components: ~10-phase VRM (controller + power stages + inductors), memory/aux rails, MCIO124 + MCIO74 + GH15 + eFuse + INA228 + EEPROM + TMP1075 kit, VBIOS SPI, ~500-800 passives, Cu die shim + spreaders | 240 | 580 | 580 | 1350 | pcb | [Estimate] $110-240 per board; GPU-VR controller choice (SVI3) is an open unknown |
| GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED | Salvage + reball Navi 23 + 4 x GDDR6 from a donor card and solder to the new board (BGA rework shop) | 300 | 900 | 750 | 2250 | none | [Estimate] $150-450 per board (remove, clean, reball, place, X-ray); yield risk on reused dies |
| Cables | 2 x MCIO 124 straight-straight ~55 mm (BP J9/J10 -> Face P/S), custom length - QUOTE NEEDED (ICD U-21) | 150 | 2000 | 300 | 2800 | none | Catalogue minimum is 150 mm (Molex 216610-1121, no distributor price). Low = Asian cable house, small MOQ (~$25-40 ea, MOQ 5-10); high = Amphenol/Molex custom NRE $500-1,500 + MOQ |
| Cables | 1 x MCIO 124 HS1 cable CB J3 -> IOB J1 (length TBD, M9) per machine | 45 | 150 | 220 | 600 | none | catalogue MCIO 8i/16i straight cables ~$40-90 [Estimate]; custom if no catalogue length fits |
| Cables | 1 x MCIO 74 (8i) DISPLAY-LINK Face P -> IOB J2 per machine | 45 | 90 | 230 | 400 | none | face spec §15: MCIO 8i straight 0.5 m ~$46-52 |
| Cables | 3 x GH15 1:1 cables + Micro-Fit 2x4 IOB->BP harness per machine | 10 | 25 | 45 | 110 | none | pre-crimped JST GH / Molex leads [Estimate] |
| I/O plate and mechanical | I/O plate io_plate_v2_A0, MJF PA12 dyed black (9.0 cm3, 52 x 163 x 4.7 mm bbox) + clear SLA button cap; qty1 = 2 plates, qty5 = 6 | 15 | 40 | 45 | 110 | 3d | JLC3DP MJF PA12 $0.275/g (2025-08-13 news) + dye; IOB plan §4.6 "$10-20 per part"; SLA alternative $5-15 |
| I/O plate and mechanical | Screws/hardware: M2 clamp-post screws, M1.6 plate corner/centre screws, CB M3 frame-seat screws + PEMs, washers (stock core/face screws reused); thermal paste/pads; DP420 epoxy/PSA for sleeves; foam insulator | 35 | 80 | 70 | 160 | none | [Estimate]; one-off assortments + per-machine parts |
| Logistics | Shipping: separate JLCPCB (PCB/PCBA), FPC, JLC3DP, JLCCNC parcels + LCSC/consignment to JLC + domestic | 100 | 220 | 150 | 320 | none | [Estimate] DHL/UPS DDP |

### CSV (same data)

```csv
group,item,qty1_low_usd,qty1_high_usd,qty5_low_usd,qty5_high_usd,us_duty_class,basis
I/O main board (IOB),"PCB fab: 6L JLC06161H-2116, 101.1 x 173.7 mm (bbox 175.6 cm2), 1.6 mm, ENIG, impedance 85/90/100 ohm, 0.30/0.45 vias",60,90,60,90,pcb,"JLC 6L 100x100 x5 = $35.10 (jlcpcb.com/6-layer-pcb, 2026-10); scaled by area x1.0-1.5; qty 5 = same 5-pc order"
I/O main board (IOB),"PCBA fees: double-sided, ~110 unique parts, ~3,200 SMT + ~30 THT joints, ~55 X-ray parts (QFN/USON)",325,415,380,485,pcb,"JLC fee table 2026-09-09 (setup $51.12, stencil $16.42, feeder $1.53/part, X-ray, THT)"
I/O main board (IOB),Components (485 placements; LCSC per-unit ~$120-188/board) x assembled boards + attrition/MOQ,260,450,625,1055,pcb,"LCSC product pages fetched 2026-10-04 (TPS65994AD C2864593 $2.81-3.25, TUSB1046A C702363 $4.13-4.24 [8 in stock], i226-V C26159200 $5.35-6.26, MCIO124 C4867471 $9.37-9.59 [0 stock], MCIO74 C5433520 $6.88-7.94, DF40C-50DS C424646 $0.44-0.55, ...); shortages priced at global-sourcing premium in the high"
"Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine)","FPC fab, 2L PI 0.11 mm, ENIG, 2 x FR4 1.0 stiffeners each (<4 => no stiffener surcharge): MOD-C 39.2x8.8, MOD-A 41.3x8.8, MOD-H 44.2x9.4 mm, panelised",70,140,100,200,pcb,"JLC FPC from $25/5 pcs (jlcpcb.com/blog/flex-pcb-cost-pricing-guide, 2026-09); qty1 = 10 C + 5 A + 5 H; qty5 = 30 C + 20 A + 5 H (+5 spare C); +20 % if the 0.075 mm (2.95 mil) min track stays (FPC difficulty fee)"
"Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine)","FPC assembly fees: 3 designs x (setup $25.56 + stencil + flex fixture $49.25-73.88 + panel), THT legs hand/selective-soldered on MOD-A/MOD-H",330,445,415,545,pcb,"JLC fee table 2026-09-09 (flex fixture 2 x $24.63 for 1-29 pcs, 3 x for 30-99)"
"Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine)",Module components: receptacle (HYCW417 C5342202 $0.94-1.13 / HC-USB3.0-L137 C7501870 $0.10-0.12 / HYC79 HDMI C711353 $0.38-0.49) + DF40C-50DP (C424645 $0.55-0.66) + BL24C02F (C2828222 $0.08-0.10) + 0201 cap,15,25,70,100,pcb,"LCSC 2026-10-04; HYCW417 only 196 in stock, USB-A alt kinghelm C2979037 has 2 in stock"
"Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine)","SUS304 0.2 mm shield sleeves (11 per machine + spares); 0.2 mm is below JLCCNC sheet-metal minimum (0.5 mm), so photo-etch/hand-bent",15,40,70,180,none,"modules README ""$1-3 each"" [Estimate]; photo-etch run setup $40-120 at qty 5"
"Flex port modules (MOD-C x6, MOD-A x4, MOD-H x1 per machine)","Printed cradles (3 groups) + clamp plates (3) MJF PA12 1.6 mm, dyed black; not modelled yet",10,25,40,100,3d,"JLC3DP MJF PA12 $0.275/g, parts from $1 (jlc3dp.com news 2025-08-13); [Estimate] $1.5-4 per part"
LGA1700 CPU board (CB),"PCB fab: 10L, 156.1 x 167.9 mm (bbox 262 cm2), 1.6 mm, ENIG, 0.15/0.25 vias + POFV, DDR5 40 ohm SE / 85-90 ohm diff impedance, hard-gold bevelled 224-finger card edge, 5 pcs",300,900,300,900,pcb,"JLC 10L: 2022 published eng. fee $136.82 + $171/m2 small batch (jlcpcb.com/news/high-precision-multi-layer-pcb-8-20-layer) + gold fingers/0.15 mm via/impedance extras; CB plan §9 estimate $450-1,000; instant quote needed (stackup is still a PLACEHOLDER, not a JLC10161H code)"
LGA1700 CPU board (CB),"PCBA fees: double-sided, ~90 unique, ~9,500 joints (socket 1,700 + PCH 1,045 + 4 x 288 DIMM + ~2,000 passives), ~30 X-ray parts, consigned PCH + baking",355,530,470,695,pcb,"JLC fee table 2026-09-09 + consignment T&C ($0.142/pc, $8 baking)"
LGA1700 CPU board (CB),"Components ex-PCH (~$118-252/board): socket PE17007 C38520273 $4.95-5.79, RT3628AE C3249940, 7 x SiC654 C1852094, 7 x FP4-150-R C2454106 (0 stock), 4 x DDR5 UDIMM short-latch (not on LCSC; C2922443 long latch $4.44 as proxy), MCIO124, TPS259851 C31786575 $9.44-10.59, INA228, RP2350, SPI, rails, ~1,500-2,500 passives + bulk",255,605,620,1410,pcb,LCSC 2026-10-04 + CB plan §9 [Estimate for areas not yet designed]
LGA1700 CPU board (CB),"Z790 PCH FH82Z790 (consigned, loose broker stock; qty1 buys 2 + 2 spares, qty5 buys 5 + 3 spares)",200,280,400,520,none,"CB plan §1.3: EUR 45-48 listings (unverified sellers), not stocked by LCSC/Mouser/Digi-Key"
LGA1700 CPU board (CB),"Contact frame (CNC 7075) + steel backplate + springs/screws (own design, replaces the ILM)",100,250,200,400,cnc,CB plan §9: $100-250 (2 sets) / $200-400 (5 sets) [Estimate]; JLCCNC aluminium = 90 % US DDP rate
"Backplane / base board (BP, HUB fp5)","PCB fab: 6L JLC06161H-2116, 122.1 x 122.1 mm round (bbox 149 cm2), 1.6 mm, ENIG, impedance 85/90 ohm",50,80,50,80,pcb,"JLC 6L $35.10/100 cm2 x5, scaled x1.0-1.5"
"Backplane / base board (BP, HUB fp5)","PCBA fees: single-sided (all 29 footprints on F), ~40 unique, ~1,400 SMT joints; Mini Cool Edge 224 + 2 x MCIO124 pegs/THT",145,190,185,245,pcb,JLC fee table 2026-09-09
"Backplane / base board (BP, HUB fp5)","Components (~$41-76/board): Amphenol ME1022410103011 Mini Cool Edge 224 (not on LCSC; brokers $6.14-10.08), 2 x MCIO124 RA (0 LCSC stock), RP2350, W25Q128, 2 x TMP1075, 3 x GH15, Micro-Fit, M.2 2242 socket, standby/main power blocks (placeholders), ~120 passives",90,180,215,425,pcb,LCSC 2026-10-04; unikeyic/htelec broker listings for ME1022410103011; power blocks [Estimate]
"Storage face board (SM-1, Face S)","PCB fab: 6L JLC06161H-2116, 104.0 x 166.1 mm (bbox 172.7 cm2), 1.6 mm, ENIG, impedance 85/100 ohm",60,90,60,90,pcb,"JLC 6L $35.10/100 cm2 x5, scaled x1.0-1.5 (storage plan §7 said $70-140)"
"Storage face board (SM-1, Face S)","PCBA fees: double-sided (BGA on F, sockets/power on B), ~45 unique, ~1,300 joints, BGA X-ray",175,230,200,265,pcb,JLC fee table 2026-09-09
"Storage face board (SM-1, Face S)","Components (~$44-84/board): ASM2824 (JLC C9900092023, price not shown; $15-40 [Unverified]), MCIO124 RA, 4 x LOTES APCI0107 C841661 $0.36-0.46, TPS259824 C2155766 $5.04-5.90, TPS56C215 C473372, INA228 C2887910 (0 stock), TMP1075 x2, ~110 passives",95,200,235,470,pcb,LCSC 2026-10-04 + storage plan §6
"Storage face board (SM-1, Face S)",3.0 mm gap pad ~25 x 25 for the ASM2824 (bought separately),5,15,15,40,none,storage plan §6
"Face template (MP62-FACE v0.1, fit-check / dev blank)","PCB fab: 6L JLC06161H-2116, 104.0 x 166.1 mm, ENIG, impedance netclasses only (no routing)",60,90,60,90,pcb,"JLC 6L, 5 pcs; same order for qty 1 and qty 5 (it is a template, not one per machine)"
"Face template (MP62-FACE v0.1, fit-check / dev blank)","Optional connector kit on 2 boards (MCIO124 + MCIO74 + GH15 RA + INA228/shunt), hand-soldered",40,70,40,70,none,"face spec §15 interface kit ~$24 (GPU) / $17 (storage), LCSC 2026-10-04"
"GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED","PCB fab: assume 10L (face spec §3.8: 8-10L, via-in-pad) on the 104 x 166 face outline, 5 pcs",220,650,220,650,pcb,Scaled from the CB 10L estimate by area (0.66x) [Estimate]
"GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED","PCBA fees for everything except the salvaged BGAs (double-sided, ~80 unique, ~4,000 joints)",190,330,230,420,pcb,JLC fee table [Estimate]
"GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED","Components: ~10-phase VRM (controller + power stages + inductors), memory/aux rails, MCIO124 + MCIO74 + GH15 + eFuse + INA228 + EEPROM + TMP1075 kit, VBIOS SPI, ~500-800 passives, Cu die shim + spreaders",240,580,580,1350,pcb,[Estimate] $110-240 per board; GPU-VR controller choice (SVI3) is an open unknown
"GPU board, Face P (salvaged Navi 23 + 4 x GDDR6) - ROUGH, NOT DESIGNED",Salvage + reball Navi 23 + 4 x GDDR6 from a donor card and solder to the new board (BGA rework shop),300,900,750,2250,none,"[Estimate] $150-450 per board (remove, clean, reball, place, X-ray); yield risk on reused dies"
Cables,"2 x MCIO 124 straight-straight ~55 mm (BP J9/J10 -> Face P/S), custom length - QUOTE NEEDED (ICD U-21)",150,2000,300,2800,none,"Catalogue minimum is 150 mm (Molex 216610-1121, no distributor price). Low = Asian cable house, small MOQ (~$25-40 ea, MOQ 5-10); high = Amphenol/Molex custom NRE $500-1,500 + MOQ"
Cables,"1 x MCIO 124 HS1 cable CB J3 -> IOB J1 (length TBD, M9) per machine",45,150,220,600,none,catalogue MCIO 8i/16i straight cables ~$40-90 [Estimate]; custom if no catalogue length fits
Cables,1 x MCIO 74 (8i) DISPLAY-LINK Face P -> IOB J2 per machine,45,90,230,400,none,face spec §15: MCIO 8i straight 0.5 m ~$46-52
Cables,3 x GH15 1:1 cables + Micro-Fit 2x4 IOB->BP harness per machine,10,25,45,110,none,pre-crimped JST GH / Molex leads [Estimate]
I/O plate and mechanical,"I/O plate io_plate_v2_A0, MJF PA12 dyed black (9.0 cm3, 52 x 163 x 4.7 mm bbox) + clear SLA button cap; qty1 = 2 plates, qty5 = 6",15,40,45,110,3d,"JLC3DP MJF PA12 $0.275/g (2025-08-13 news) + dye; IOB plan §4.6 ""$10-20 per part""; SLA alternative $5-15"
I/O plate and mechanical,"Screws/hardware: M2 clamp-post screws, M1.6 plate corner/centre screws, CB M3 frame-seat screws + PEMs, washers (stock core/face screws reused); thermal paste/pads; DP420 epoxy/PSA for sleeves; foam insulator",35,80,70,160,none,[Estimate]; one-off assortments + per-machine parts
Logistics,"Shipping: separate JLCPCB (PCB/PCBA), FPC, JLC3DP, JLCCNC parcels + LCSC/consignment to JLC + domestic",100,220,150,320,none,[Estimate] DHL/UPS DDP
TOTAL before duty,,4400,10400,7700,17600,,
US DDP duty,,1250,2430,1990,3790,,JLC US DDP schedule 2026-03-17
GRAND TOTAL,,5600,12800,9700,21400,,
```
## 4. Largest cost drivers

1. **LGA1700 CPU board: ≈ $1.2k–2.6k at qty 1.**
   - 10-layer 262 cm² fab with hard-gold card-edge fingers and 0.15 mm vias: $300–900.
   - Double-sided PCBA with two big BGAs (the socket and the consigned PCH) and about 9,500 joints.
   - Z790 PCHs from loose broker stock, including spares.
   - The CNC contact frame and backplate.
2. **GPU board (rough): ≈ $0.95k–2.5k at qty 1.**
   - Salvage, reball and placement of the die and 4 GDDR6 parts at a rework shop.
   - A second 10-layer fab.
   - An unknown VRM controller.
3. **Custom MCIO cables: ≈ $0.25k–2.3k at qty 1.**
   - The 2 × 55 mm MCIO 124 straight-to-straight cables are below every catalogue length (the minimum is 150 mm).
   - A Western-vendor NRE plus MOQ alone would exceed every other line except the CPU and GPU boards.
4. **Fixed JLC charges at qty 1** (setup, stencils, $1.53 per unique part, fixtures, 5-piece fab minimums) are **≈ $2.3k–4.2k, more than half of the qty-1 total.**
   - At qty 5 the same charges are spread over 5 machines. That is why the per-machine cost falls from ≈ $4.4k–10.4k to ≈ $1.5k–3.5k before duty.
   - The port modules show it most clearly: about $16–25 of parts against about $330–440 of FPC assembly fees for three designs.
5. **US import duty: about +$1.3k–2.4k at qty 1.** JLC pre-collects 35 % on PCB/PCBA, 40 % on 3D prints and 90 % on aluminium CNC parts.
6. **I/O main board: ≈ $0.64k–0.96k at qty 1.**
   - The components (≈ $120–190 per board) are driven by 6 × TUSB1046A, 3 × TPS65994AD, 2 × i226-V, the MCIO 124 + 74 receptacles, the eFuse and the INA228.
   - About 110 unique parts make about $170 of feeder-loading fees.

## 5. Big unknowns (where this estimate can be badly wrong)

| Unknown | Why | Effect on the estimate |
|---|---|---|
| **GPU board** | Not designed. No schematic, layer count or VRM controller. The Navi 23 needs an SVI3-class VR controller with no public data. Salvaged-die rework yield is unknown. | Labelled **ROUGH**. Could be 2× either way. A respin is likely. |
| **Custom 55 mm MCIO 124 cables** (ICD U-21) | No vendor quote. Shortest catalogue part is Molex 216610-1121 (150 mm, no distributor price). NRE and MOQ are unknown. | $150 to over $2,000 for 2 cables. **Get quotes from Amphenol AssembleTech, Molex, TE, Luxshare and at least one Shenzhen cable house.** |
| HS1 (CB→IOB) and DISPLAY-LINK cable lengths (U-6, M9) | Not measured | Catalogue $40–90 each if a stock length fits; otherwise custom (see above). |
| **Unfinished boards** | None of the rigid boards is routed. The CB, BP and GPU are part-level floorplans with area placeholders. The IOB has 485 schematic parts, but small passives are not on the PCB. | Passive counts, unique-part counts, X-ray counts and layer/via choices will move. The CB stackup is a placeholder, not a JLC 10L code, so impedance control may cost extra. |
| 10-layer fab price | JLC publishes no current 8–20L rate. The only published figures are from the 2022 news post (eng. fee $136.82 + $171/m²). | CB $300–900, GPU $220–650. **Run an instant quote** with a dummy Gerber at the real outline, 10L, ENIG, gold fingers, 0.15 mm vias. |
| Loose Z790 PCH | Broker-only (€45–48). Authenticity and fuse state are unverified. | Spares are included. A bad batch means buying again. |
| ASM2824 price | The JLC part C9900092023 shows no price | $15–40 [Unverified] |
| Stock-outs at LCSC (2026-10-04) | See §7 | Global sourcing or consignment adds cost and lead time |
| Respin | The CB plan expects a rev B (70–100 % of rev A) | **Not included.** Budget separately. |

## 6. Ways to cut cost

1. **Put all three flex-module designs in one FPC panel.**
   - JLC accepts up to 10 different designs in one FPC outline, subject to audit.
   - You pay one setup, one stencil, one flex fixture and one panel fee instead of three: saves ≈ $180–250 per order.
   - Also widen the 0.075 mm (2.95 mil) minimum track to ≥ 3 mil, ideally 3.5 mil, to avoid JLC's 20 % FPC difficulty fee.
2. **Cut unique part numbers.**
   - Every unique part costs $1.53 in feeder loading.
   - Merge passive values (e.g. all 220 nF / 100 nF / 10 µF to one or two part numbers each), especially on the IOB (about 110 unique → 70 saves ≈ $60 per order).
   - Prefer JLC "basic" parts.
3. **Assemble the BP with Economic PCBA.** It is single-sided 6-layer, which Economic supports. Setup is $8.18 instead of $25.56 and the stencil $1.53 instead of $8.21. Check that the Mini Cool Edge and MCIO pitch/size rules allow it.
4. **Avoid the custom MCIO cable**, if the geometry allows:
   - a catalogue 150 mm straight cable with a service loop, or
   - ICD backup B1, a rigid-flex/FPC MCIO jumper. SI is marginal at Gen4 x16; prototype it with the TDR coupon first.
   - Otherwise, order all 5 machines' cables at once to spread the NRE (the 2 custom cables cost ≈ $60–560 per machine at qty 5, vs $150–2,000 for one machine).
5. **Interim GPU: MXM RX 6600 + a simple MXM carrier** (lineup plan option 1, $280 card + JAE MXM socket ≈ $11). This defers the salvaged-die board and its rework/VRM risk.
6. **Buy the scarce parts yourself and consign them in one shipment** to avoid per-part global-sourcing markups:
   - 7 × MCIO 124 RA and 2 × MCIO 74 RA per machine
   - TUSB1046A ×6
   - INA228 ×4–5
   - TDP158, ASM1182e, FP4-150-R ×7
   - the short-latch DDR5 sockets and the Mini Cool Edge 224
7. **Skip the face template build** (−$100–160). Use the SM-1 storage board as the first fit check, since it has the same outline, holes and connectors.
8. **Keep the Gen5 redrivers off the BP** (they are already excluded): 5 × DS320PR810 is ≈ $95–115 per BP, and LCSC has 0 in stock.
9. **Combine shipments** of PCB, PCBA, FPC and 3DP into as few DDP parcels as possible. Order the I/O plate, cradles and clamp plates in one JLC3DP order.
10. **For qty 5, order 10 CB PCBs instead of 5** (+≈ $150–400) only if you want bare spares. The table assumes exactly 5.

## 7. Sourcing / stock flags (LCSC, 2026-10-04)

| Part | Where used (per machine) | LCSC stock | Note |
|---|---|---|---|
| Amphenol G97R24332HR MCIO 124 RA (C4867471) | IOB J1, CB J3, BP J9/J10, SM-1 J1, GPU J_PCIE = **6** (+1 template) | **0** | $9.37–9.59 list; global source or consign |
| Amphenol G97R22332HR MCIO 74 RA (C5433520) | IOB J2, GPU J_DISP = 2 (+1 template) | 4 | Alt. ACES 52730-0740D-021 |
| TI TUSB1046A-DCIRNQR (C702363) | IOB ×6 | **8** | Qty 5 needs 30. LCSC datasheet page lists up to $10.39 |
| TI INA228AIDGSR (C2887910) | IOB, CB, SM-1, (template, GPU) | **0** | $6.24–6.38 list |
| TI TDP158RSBR (C544773) | IOB | **0** | |
| ASMedia ASM1182e (JLC C2833072) | IOB | **0** | Also check the package: the IOB footprint is a QFN-64 9×9 placeholder |
| Eaton FP4-150-R (C2454106) | CB ×7 | **0** | |
| TI DS320PR810 (C6539580) | BP option ×5 | **0** | Optional (Gen5) only |
| UMAX 90414 short-latch DDR5 socket | CB ×4 | not listed | The long-latch C2922443 ($4.44, 71 in stock) does not fit the outer slots |
| Amphenol ME1022410103011 Mini Cool Edge 224 | BP J1 | not listed | Brokers $6.14–10.08 |
| HOAUC HYCW417 USB-C (C5342202) | MOD-C ×6 | 196 | Qty 5 needs 30 (+spares): fine |
| kinghelm KH-3.0AF180ZJ-11.5JB (C2979037) | MOD-A | **2** | The BOM already uses the HC-USB3.0-L137-WJ alternative (C7501870, 645) |
| WCH CH334R (C4154405) | IOB ×4 | 15,162 | **Footprint mismatch:** the CH334R is QSOP-16. The QFN-24 placeholder matches the CH334F (C5187527, $0.54–0.63). Fix before routing. |

## 8. Excluded items: typical prices for context (not in the totals)

| Item | Typical price | Source / date |
|---|---|---|
| CPU Intel Core i5-14500T (tray) | $254–300 | Aztek $253.91, SHI $283, Neutron $300.23 (CB plan §9, 2026-10-01) |
| DDR5 UDIMM (JEDEC height ≤ 33.25 mm, no tall heat spreader), 2 × 16 GB | ≈ $250 (4800 CL38) – $560 (6000 CL30) | rampricesusa.com / Newegg, early Oct 2026 (DRAM prices are high) |
| DDR5 UDIMM, 4 × 16 GB or 2 × 32 GB | ≈ $500 – $1,100 | Same, scaled [Estimate] |
| NVMe 2280 Gen4 SSD, per drive (CB M.2 + 4 × SM-1 slots) | 1 TB $144–249; 2 TB $246–390 | best-ssd.com, Sep–Oct 2026 |
| M.2 2242 SATA SSD (BP OpenCore boot) | ≈ $30–60 | [Estimate] |
| Donor GPU: used Radeon RX 6600 (Navi 23, 8 GB GDDR6) | $154–221 (median ≈ $183) | getpcparts.com eBay sold data to 2026-09-26 |
| MXM RX 6600 (interim GPU option) | ≈ $280 | lineup options doc [40] |
| Optional Gen5 BP redrivers 5 × DS320PR810 | ≈ $95–115 per BP | LCSC C6539580 $18.75–22.99 (0 stock) |
| Stock Mac Pro 6,1 donor (enclosure, PSU, core, fan, audio flex, speaker) | assumed owned | — |

## 9. Sources (fetched 2026-10-04 unless noted)

- JLCPCB PCBA fee table (updated 2026-09-09): https://jlcpcb.com/help/article/pcb-assembly-price
- JLCPCB 6-layer pricing ("6-layer 100×100 mm from $35.10 / 5 pcs"): https://jlcpcb.com/resources/multilayer-pcb ; capabilities: https://jlcpcb.com/6-layer-pcb
- JLCPCB 8–20 layer published rates (2022-12-02, the only published 10L figures): https://jlcpcb.com/news/high-precision-multi-layer-pcb-8-20-layer
- JLCPCB 6+ layer lead-time notice (2026-08-06): https://jlcpcb.com/news/pcb-lead-time-and-price-adjustment-august2026
- JLCPCB FPC pricing guide (2026-09-01) and FPC extra charges (updated 2026-09-09): https://jlcpcb.com/blog/flex-pcb-cost-pricing-guide ; https://jlcpcb.com/help/article/fpc-extra-charges
- JLCPCB PCBA MOQ / capabilities: https://jlcpcb.com/solutions/pcb-prototype-assembly ; https://jlcpcb.com/capabilities/pcb-assembly-capabilities ; consignment T&C: https://jlcpcb.com/help/article/consignment-part-terms-conditions
- JLC US tariff / DDP rates (update 2026-03-17): https://jlcpcb.com/news/logistics-update-us-china-tariff
- JLC3DP MJF PA12 $0.275/g (2025-08-13) and July 2026 update: https://jlc3dp.com/news/drastic-material-price-cuts-and-adjusted-post-processing-service-fees ; https://jlc3dp.com/news/materials-finishing-pricing-update-july2026
- JLCCNC sheet metal (0.5–6 mm, SUS304): https://jlccnc.com/sheet-metal-fabrication
- LCSC product pages (prices and stock read 2026-10-04): C4867471, C5433520, C424646, C424645, C5342202, C7501870, C2979037, C711353, C2828222, C106794, C138714, C2827281, C55547809, C7502869, C2155766, C473372, C111004, C2870250, C265027, C841661, C5301773, C38520273, C3249940, C1852094, C2922443, C2922442, C42411118, C6539580, C26159200, C2864593, C702363, C1849392, C544773, C4154405, C5187527, C371347, C2887910, C31786575, C626968, C2454106, C88373, C2928168, C431048 (`https://www.lcsc.com/product-detail/<C#>.html`); ASM2824 https://jlcpcb.com/partdetail/JLCPCBAssembly-ASM2824ASmedia/C9900092023 (no price); ASM1182e https://jlcpcb.com/partdetail/ASMEDIA-ASM1182e/C2833072 (0 stock)
- Mini Cool Edge ME1022410103011 broker prices: https://www.unikeyic.com/products/edgeboard-connectors/me1022410103011/5896176.html ; https://www.htelec.com/products/detail/me1022410103011-2287796
- Project docs: CB plan §1.3 (PCH listings) and §9; storage plan §6–7; IOB plan §4.6 (plate) and §11; modules README (costs, sleeves); ICD rev 2.1 §5 (MCIO cable U-21, catalogue Molex 216610-1121); face spec §3.8 and §15.
- Excluded-item prices: rampricesusa.com/32gb-ram-prices, best-ssd.com/1tb-nvme-prices and /2tb-nvme-prices, getpcparts.com/market-prices/gpu-graphics-cards/rx-6600 (all Sep–Oct 2026).

*Method notes:*
- Board sizes, layer counts, stackups, netclasses and via rules were read with KiCad 9 `pcbnew` from copies of the projects.
- IOB and SM-1 BOMs came from `kicad-cli sch export bom`.
- Joint counts were summed from the project footprint libraries.
- Nothing under `/workspace/kicad`, `/workspace/mechanical` or the plan docs was modified.

## 10. What-if: AM5 CPU board instead of LGA1700 (added 2026-10-04, about 11:30 ET)

This is a delta against the LGA1700 CPU-board (CB) lines in §3. Everything else (IOB, modules, BP, storage, template, GPU, cables, mechanical) is unchanged unless stated. As in §3, "low" is the favourable end and "high" the unfavourable end, summed line by line. **[Estimate]** means no vendor price was found.

### 10.1 Headline delta

| | Qty 1 | Qty 5 |
|---|---|---|
| CB delta before duty, if the board stays **10-layer** (likely for rev A) | **−$170 to +$170** | **−$360 to +$260** |
| CB delta before duty, if **8-layer** works | −$470 to +$170 | −$660 to +$260 |
| US duty delta (35 % PCB/PCBA, 90 % CNC; the consigned chipset is not dutiable) | −$150 to +$80 | −$200 to +$160 |
| **Delivered delta, 10L / 8L** | **≈ −$220 to +$240 / −$620 to +$240** | **≈ −$450 to +$420 / −$850 to +$420** |
| Effect on the grand total (§2: $5.6k–12.8k / $9.7k–21.4k) | **within ±5 %: essentially a wash** | **within ±5 %** |
| Excluded CPU, per machine (§10.4) | ≈ −$60 to −$120 vs the i5-14500T | same |

The money hardly moves. The real AM5 issues are **firmware**, **which CPUs boot** and **power**, not BOM cost (see §10.3).

### 10.2 Line-by-line delta (USD, before duty)

| Item | LGA1700 (current §3) | AM5 equivalent | Δ qty 1 | Δ qty 5 | Basis |
|---|---|---|---|---|---|
| CPU socket | Foxconn PE17007 LGA1700, LCSC C38520273, $4.95–5.79 (32 in stock) | LGA1718: Foxconn PE17181-11AJ0-1H / PE17186-11ZZ0-1H or Lotes AZIFS055. **Not on LCSC.** Repair-parts retail $12.06 to €37.99. Consign it, and buy 1 spare because it is hard to re-buy. | +$20 to +$105 | +$45 to +$205 | atombilgisayar.com and gpufix.de listings; ecer.com Foxconn agent (factory MOQ 560). Fetched 2026-10-04. |
| Retention hardware | Own CNC 7075 contact frame, steel backplate and springs ($100–250 / $200–400) replace the ILM | **Same approach, new geometry**: 40 × 40 mm package, 4-screw ILM with 2 backplate studs. Option: the stock ILM + BP set (Lotes AZIF0002 SAM + AHSK0001 BP, Foxconn PM1A112-11AN0-4H, broker ≈ $10–25 [Estimate]) **if it fits the core-plate Z stack (unlikely)**. | −$60 to +$20 | −$120 to +$40 | Lotes socket brochure (kaztech.jp PDF); ecer.com |
| Chipset | Z790 FH82Z790, loose broker stock, €45–48 each; 2 + 2 spares = $200–280 / 5 + 3 = $400–520 | **One PROM21** (ASMedia-made, 19 × 19 mm FCBGA, ~7 W): B650 **218-0891018**, or the X870-marked **218-0891025** (lower dead-on-arrival rate, per an AIC developer). **No franchised channel**: new parts come only from AMD at a 1,000-unit MOQ, and AliExpress/Taobao parts are "mostly recycled from scrap motherboards". No credible unit price was found; hkinventory's $0.74–4.82 listings look bogus. Assume **$15–50 each [Estimate]**, 2 + 3 spares / 5 + 3. | −$125 to −$30 | −$280 to −$120 | geerlingguy/raspberry-pi-pcie-devices #818 (2026-06-05); wepc.com PROM21 specs; ithome.com 2025-12-30 |
| PCB fab | 10L, 262 cm², $300–900 (5 pcs, both columns) | Retail B650/B850 boards are 6L (MSI B650/B850 Gaming Plus WiFi) to 8L (MAG B850 Tomahawk MAX). PROM21 is smaller and coarser than the 1,045-ball 0.5 mm Z790 PCH, which was the CB's tight fan-out. The socket and 2DPC DDR5 escape are unchanged, so **keep 10L for rev A**; 8L is plausible for rev B. | $0 (10L) to −$300 (8L) | same | MSI spec pages; Kingston population rules (AMD's "6-layer" AM5 reference) |
| PCBA fees | ~9,500 joints, ~90 unique, ~30 X-ray parts | Socket +18 balls; PROM21 has fewer balls than the PCH (count [Unverified]). Adds 1–2 consigned lines (socket, VR controller). | −$10 to +$25 | −$15 to +$35 | JLC fee table (2026-09-09) |
| VRM | RT3628AE (IMVP 9.1) $2.18 + 9 SiC654 stages + FP4 inductors; 6 core + 1 GT + 2 VCCIN_AUX phases; 35 W T-series | **SVI3** controller for three rails: VDDCR core, VDDCR_SOC, VDD_MISC. Candidates are Renesas RAA229620/621/628, MPS MP2857 (12 + 4) and Infineon XDPE192C3B (12 + 0 … 6 + 6, "available on demand only"). **None found at LCSC.** Brokers ≈ $3–15 [Estimate]. The config tools are NDA, as with the RT3628AE. Ryzen 5 7600-class limits are 88 W PPT / 75 A TDC / 150 A EDC, so ≈ 6–8 core + 2 SoC + 1 MISC phases (+1 to +2 stages and inductors). Running at cTDP 45 W keeps it near the current 6 + 1. | +$8 to +$45 | +$15 to +$100 | Infineon XDPE192C3B page and datasheet; atombilgisayar MP2857 listing; igorslab AM5 teardowns; techenclave / techreviewer 7600 limits; hwbusters SVI3 article |
| DDR5 | 4 × DDR5 UDIMM, 2DPC; Intel RPL 2DPC 4000 (1R) / 3600 (2R) | **Also DDR5 UDIMM only (no DDR4 on AM5), 2 channels × 2DPC.** AMD official: 1DPC 5200 (7000) / 5600 (9000); **2DPC 3600 (1R and 2R)**. 8600G: 4 × 1R/2R 3600. Same 4 sockets and routing class; AMD's DDR layout guide is NDA. | $0 | $0 | Kingston memory-population rules; AMD 9600 and 8600G spec pages (fetched 2026-10-04) |
| PCH-rail bucks, EC, SPI | PCH 0.82 V 15 A + 1.8 V; RP2350 EC; SPI | PROM21 rails are smaller (~7 W). The CPU's integrated FCH takes the SPI ROM (32 MB), RTC and SMBus. The RP2350 EC stays (RSMRST_L, PWR_GOOD, SLP_S3/S5 instead of the Intel signals). | ≈ $0 (±$5) | ≈ $0 | [Inference] |

**Knock-on effects on the backplane, faces, IOB and cables: $0 in hardware, but an ICD/CPU-LINK re-map (engineering time).**

- **Lanes, Raphael / Granite Ridge (7600 / 9600):**
  - 28 Gen5 lanes, 24 usable: x16 → Face P, x4 → Face S, x4 → M.2 boot (moved from the PCH to the CPU), plus x4 to the chipset. That is more CPU lanes than the i5-14500T's 16 + 4.
  - The chipset uplink is **x4 Gen4**, versus Z790's DMI 4.0 x8.
- **Single PROM21 supply:** 8 × Gen4 (2 × x4), 4 × Gen3/SATA flex lanes and 6 × USB 10 G. That covers 2 × i226-V (x1 each), the future AQC107 (x4) and SATA0 to the BP.
- **USB 10 G:** the CPU has 4 native (+1 USB2) and PROM21 has 6, which is exactly the **10 × 10 G** the IOB needs, the same as Z790. Phoenix (8600G) has only 2 × 10 G + 2 × USB4 natively, so it gets 8 × 10 G plus 2 USB4-capable ports. It needs either 2 USB4 ports run at 10 G or an X670-style second PROM21 (+$30–100 per board [Estimate]).
- **Phoenix 8600G/8700G** have 20 lanes, 16 usable: **x8 to Face P** (the Navi 23 is natively x8, so no loss today), x4 Face S and x4 M.2. The Face P x16 contract would be capped at x8.
- **Display:** the iGPU DP outputs (USB-C DP alt mode) replace Intel DDI-B/DDI-C to IOB C5/C6. The IOB's TUSB1046A stays.
- **BP and faces:** no new lanes are needed, so no PCB change. The optional Gen5 redrivers are unchanged.

### 10.3 Non-cost issues that matter more than the delta

- **Firmware (biggest risk):**
  - There is no public FSP equivalent for Raphael or Granite Ridge. Their AGESA/PSP sources and the APCB format are NDA or undocumented.
  - The only open desktop AM5 firmware is **Dasharo v0.9.0 for the MSI PRO B850-P WIFI** (coreboot 25.12 + openSIL `phoenix_poc`, released 2026-07-30). It boots **only Phoenix Ryzen 8000G** (8300G–8700G), was validated on an 8600G, and **Ryzen 7000/9000 "will not boot"**. The remaining closed parts are PSP blobs.
  - So a custom AM5 CB realistically means **Phoenix 8600G/8700G**: PCIe 4.0 only, x8 to the GPU, RDNA3 iGPU. The equivalent of the CB plan's de-risk mule is the 3mdeb "Dasharo Full PC Build MSI PRO B850-P" at **€965–1,135 ex VAT**, or a retail B850-P plus the Dasharo package. Neither is in the totals.
  - PROM21 also needs its own SPI firmware image, extractable from a retail BIOS (per the AIC developer).
- **Power and thermals:** AM5 has no retail 35 W "T" part. The 7600/9600/8600G are 65 W TDP (8600G cTDP 45–65 W); the Ryzen PRO 8x00GE are 35 W but OEM-only [Unverified availability]. Plan on cTDP 45 W in the trashcan core, and check the CB 12 V allocation and the TPS259851 limit. PROM21 adds ~7 W (Z790 is ~6 W [Unverified]).
- **Sourcing:** the socket, chipset and SVI3 controller are all off-LCSC, broker or recycled. That is similar risk to Z790, but **recycled PROM21 dead-on-arrival rates are high**, so buy the 1025 variant and spares, and X-ray them.

### 10.4 Excluded CPU, typical prices (context only)

| CPU | Typical price | Source / date | Note |
|---|---|---|---|
| Intel i5-14500T (current plan) | $254–300 tray | CB plan §9, 2026-10-01 | 35 W |
| Ryzen 5 7600 (Raphael, Zen 4) | $144–177 tray, $210 box; one tracker shows $330 (single Newegg offer, 2026-10-03 — outlier) | Newegg via search, Sep 2026; thecomparator.tech | 65 W, 24 usable Gen5 lanes. **Not bootable with open firmware today.** |
| Ryzen 5 9600 (Granite Ridge, Zen 5) | $250 box (Newegg, 2026-09-25); tray ≈ £150 (UK) | thecomparator.tech; qual.co.uk | 65 W, 24 usable Gen5 lanes. **Not bootable with open firmware today.** |
| Ryzen 5 8600G (Phoenix, Zen 4) | $177–197 box | Newegg / NeweggBusiness, Sep–Oct 2026; pcguide 2026-09-21 | 65 W (cTDP 45), 16 usable Gen4 lanes, **the only family Dasharo boots** |

### 10.5 macOS impact (brief)

- **Works:** Ryzen hackintoshes run through **macOS Tahoe 26** with OpenCore plus the **AMD Vanilla** kernel patches. Zen 4 is family 19h and Zen 5 is 1Ah (OpenCore ≥ 1.0.2). A supported AMD dGPU is required, and the Navi 23 Face P already is one.
- **Limits versus Intel:**
  - **no Apple Hypervisor (AppleHV)**, so Docker Desktop, Parallels and UTM/QEMU acceleration don't work; VirtualBox is slow
  - **no iGPU**: RDNA2/RDNA3 iGPUs are unsupported (Intel's UHD 770 is also unusable on Tahoe, so nothing is lost here)
  - occasional app incompatibilities with Intel-specific code paths
  - core-count patches have to be maintained across macOS updates
  - Zen 5 maturity [Unverified]
- Tahoe is the last x86 macOS on both platforms (lineup options doc).

### 10.6 Sources for §10 (fetched 2026-10-04 unless noted)

- AMD AM5 chipset table (lanes, USB, SATA per chipset): https://www.amd.com/en/products/processors/chipsets/am5.html
- AMD Ryzen 5 9600 specs (28/24 lanes, 4 × USB 10 G, 2DPC 3600): https://www.amd.com/en/products/processors/desktops/ryzen/9000-series/amd-ryzen-5-9600.html ; Ryzen 5 8600G specs (20/16 lanes, 2 × USB4, cTDP 45–65 W): https://www.amd.com/en/products/processors/desktops/ryzen/8000-series/amd-ryzen-5-8600g.html ; 8600G/8700G x8 GPU link: https://www.techspot.com/news/101573-ryzen-8000g-apus-could-drastically-reduce-ssd-gpu.html (2024-01-19)
- Kingston DDR5 population rules (AMD and Intel 2DPC speeds): https://www.kingston.com/en/memory/memory-population-rules
- PROM21 specs: https://www.wepc.com/news/am5-prom21-chipset-technical-information-revealednbspnbsp/ ; PROM21 sourcing, part numbers and MOQ: https://github.com/geerlingguy/raspberry-pi-pcie-devices/issues/818 (comments 2026-06-03…05) ; PROM21 as a PCIe switch / open AIC: https://www.ithome.com/0/909/288.htm (2025-12-30) ; WisdPi PROM21 card $199: https://wisdpi.com/products/prom21
- AM5 socket part numbers and prices: https://www.lotes.cc/en/product.php ; https://kaztech.jp/wp-content/uploads/2024/05/Lotes-socket-introduction_E1_230131-1.pdf ; https://www.atombilgisayar.com/am5-cpu-soket-socket-degisim-yuvasi-konnektor-bga-lotes-foxconn-3245 ($12.06) ; https://www.gpufix.de/en/foxconn-am5-socket-lga1718.html (€37.99 incl. VAT) ; https://www.ecer.com/corp/details-uuue6xe-p1af8y5-foxconn-pe17186-11zz0-1h-desktop-and-workstation-cpu-socket-amd-am5-platform.html
- SVI3 controllers: https://www.infineon.com/part/XDPE192C3B-0000 ; https://www.atombilgisayar.com/mp2857gqkt-mp2857-mps-amd-multi-phase-controller-tqfn-48-12109 ; https://www.igorslab.de/en/asrock-x870e-taichi-ocv-in-the-test-more-is-almost-impossible/2/ ; https://hwbusters.com/news/amds-scalable-voltage-interface-3-svi3-how-to-check-if-your-mainboard-is-safe/
- AM5 board layer counts: https://www.msi.com/Motherboard/B650-GAMING-PLUS-WIFI ; https://qbit.pk/msi-mag-b850-tomahawk-max-wifi-motherboard-review/
- Open AM5 firmware: https://blog.3mdeb.com/2026/2026-07-30-msi-pro-b850p-v090-release/ ; https://shop.3mdeb.com/product/dasharo-full-pc-build-msi-pro-b850-p-wifi-ddr5/
- CPU prices: https://thecomparator.tech/cpu/amd-ryzen-5-7600/ (2026-10-03) ; https://thecomparator.tech/cpu/amd-ryzen-5-9600/ (2026-09-25) ; https://www.newegg.com/p/pl?d=ryzen+5+8600g ; https://www.neweggbusiness.com/product/product.aspx?item=9b-19-113-814 ; https://online.qual.co.uk/amd-ryzen-5-9600-processor-3-8-ghz-32-mb-l3-tray-amd-100-000000718
- macOS on AMD: https://github.com/AMD-OSX/AMD_Vanilla ; https://github.com/mikigal/ryzen-hackintosh ; project doc `macpro62-lineup-options.md` (refs [6], [13], [14])
