#!/usr/bin/env python3
"""Inject the 8-layer JLC stackup and net classes into cpu_carrier.kicad_pcb / .kicad_pro.
Stack: JLC 8L 1.6 mm controlled-impedance class (JLC08161H-2116 by JLC's naming scheme; the exact
dielectric table must be taken from JLC's order-page stackup selector - values below are PLACEHOLDERS
chosen to sum to 1.6 mm). L1 sig (B fingers) / L2 GND / L3 sig (stripline) / L4 GND / L5 PWR (12V_MOD) /
L6 sig (stripline) / L7 GND / L8 sig (A fingers)."""
import json, os
PRJ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
pcb = os.path.join(PRJ, "cpu_carrier.kicad_pcb")
D = lambda n, t, th, mat, er, lt=0.02: f'\t\t\t(layer "dielectric {n}" (type "{t}") (thickness {th}) (material "{mat}") (epsilon_r {er}) (loss_tangent {lt}))\n'
C = lambda name, th: f'\t\t\t(layer "{name}" (type "copper") (thickness {th}))\n'
HEAD = '\t\t(stackup\n\t\t\t(layer "F.SilkS" (type "Top Silk Screen"))\n\t\t\t(layer "F.Paste" (type "Top Solder Paste"))\n\t\t\t(layer "F.Mask" (type "Top Solder Mask") (thickness 0.01))\n'
TAIL = '\t\t\t(layer "B.Mask" (type "Bottom Solder Mask") (thickness 0.01))\n\t\t\t(layer "B.Paste" (type "Bottom Solder Paste"))\n\t\t\t(layer "B.SilkS" (type "Bottom Silk Screen"))\n\t\t\t(copper_finish "ENIG")\n\t\t\t(dielectric_constraints no)\n\t\t\t(edge_connector bevelled)\n\t\t)\n'
body = (C("F.Cu", 0.035) + D(1, "prepreg", 0.12, "2116 (NP-155F) PLACEHOLDER", 4.16) +
        C("In1.Cu", 0.0152) + D(2, "core", 0.25, "FR4 core PLACEHOLDER", 4.6) +
        C("In2.Cu", 0.0152) + D(3, "prepreg", 0.22, "2116 x2 PLACEHOLDER", 4.16) +
        C("In3.Cu", 0.0152) + D(4, "core", 0.25, "FR4 core PLACEHOLDER", 4.6) +
        C("In4.Cu", 0.0152) + D(5, "prepreg", 0.22, "2116 x2 PLACEHOLDER", 4.16) +
        C("In5.Cu", 0.0152) + D(6, "core", 0.25, "FR4 core PLACEHOLDER", 4.6) +
        C("In6.Cu", 0.0152) + D(7, "prepreg", 0.12, "2116 (NP-155F) PLACEHOLDER", 4.16) +
        C("B.Cu", 0.035))
tag = "JLC 8L 1.6mm (JLC08161H-2116 class, confirm)"
s = open(pcb).read()
if "(stackup" not in s:
    s = s.replace("\t(setup\n", "\t(setup\n" + HEAD + body + TAIL, 1)
    open(pcb, "w").write(s)
pro = pcb.replace(".kicad_pcb", ".kicad_pro")
d = json.load(open(pro))
classes = d["net_settings"]["classes"]
for c in classes:
    if c["name"] == "Default":
        c.update(clearance=0.1, track_width=0.12, via_diameter=0.3, via_drill=0.15)
if not any(c["name"] == "PCIE_85R" for c in classes):
    base = dict([c for c in classes if c["name"] == "Default"][0])
    base.update(name="PCIE_85R", clearance=0.15, track_width=0.20, diff_pair_width=0.20, diff_pair_gap=0.20, diff_pair_via_gap=0.25,
                via_diameter=0.3, via_drill=0.15,
                description="PCIe Gen4 85 ohm diff. L1/L8 microstrip and L3/L6 stripline. START VALUES, compute with the JLC impedance calculator for the chosen 8L stack")
    classes.append(base)
    u = dict(base); u.update(name="USB_DDI_90R", description="USB2/USB3/SATA 90 ohm, DDI 85-100 ohm diff. START VALUES"); classes.append(u)
    p = dict(base); p.update(name="PWR_12V", clearance=0.3, track_width=2.0, description="12V_IN / 12V_MOD (<= 12 A): pours on L5 + L1/L8, not tracks"); classes.append(p)
d["board"]["design_settings"]["rules"]["min_hole_clearance"] = 0.2
d.setdefault("text_variables", {})["STACKUP"] = tag
json.dump(d, open(pro, "w"), indent=2)
print("postprocess ok", tag)
