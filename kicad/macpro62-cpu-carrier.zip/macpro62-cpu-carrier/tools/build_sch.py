#!/usr/bin/env python3
"""Generate the MacPro6,2 CPU carrier top-level block-diagram schematic (KiCad 9 format):
a root sheet with hierarchical sheet symbols + labels, and one stub file per block that
holds the matching hierarchical labels and a text description. No components yet."""
import os, uuid
PRJ = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
U = lambda: str(uuid.uuid4())
ROOT_UUID = "6a1c2d3e-0000-4000-8000-000000000c62"
VER = '(version 20250114)\n\t(generator "eeschema")\n\t(generator_version "9.0")'
F = '(effects (font (size 1.27 1.27))'

def g(v):  # snap to 1.27 mm grid
    return round(v / 1.27) * 1.27

# name, file, description lines, pins [(name, type)] ; type in input/output/bidirectional/passive
I, O, B, P = "input", "output", "bidirectional", "passive"
SHEETS = [
 ("COM-HPC module connectors (P1/P2)", "module.kicad_sch", [
   "P1 = mate of module J1 (rows A-D), P2 = mate of module J2 (rows E-H): Samtec ASP-214802-01 (5 mm) or ASP-209948-01 (10 mm)",
   "Module: Kontron COMh-ccAS COM-HPC Client Size C (LGA1700, i5-14500T) - fit: see spec 6.4 (Size C overhangs; A/B fallback)",
   "VCC 12V (P1 A1-A9/B/C/D VCC pins): 4.75-20 V module input; VCC_5V_SBY optional (from BP 5V_SBY)",
   "PCIe 16-31 (PEG, P2 rows E/F) -> CPU-LINK Face P x16; PCIe 12-15 (P1) -> Face S x4; PCIe 8-11 (P1) -> M.2 (opt.)",
   "Module TX AC caps are on the module (CDG 3.6.2); no carrier AC caps (device-TX caps on the faces)",
   "Mounting: 4 of 6 Size C holes usable at option C1 (M2.5, 5 mm spacers); module/HSP-to-core adapter plate TBD"],
  [("VCC_12V_MOD", I), ("VCC_5V_SBY", I), ("VCC_RTC", I), ("PEG_TX0_15", O), ("PEG_RX0_15", I), ("PCIE12_15_TX", O), ("PCIE12_15_RX", I),
   ("PCIE8_11_TX", O), ("PCIE8_11_RX", I), ("REFCLK0", O), ("REFCLK1", O), ("REFCLK2", O), ("SATA0", B), ("USB2_0_3", B),
   ("USB3_0_3", B), ("DDI0", O), ("DDI1", O), ("GBE0_MDI", B), ("ESPI", B), ("BOOT_SPI", B), ("SMB", B), ("I2C0", B), ("UART0", B), ("UART1", B),
   ("PWRBTN_N", I), ("RSTBTN_N", I), ("SUS_S3_N", O), ("SUS_S4_S5_N", O), ("RSMRST_OUT_N", O), ("VIN_PWR_OK", I), ("PLTRST_N", O),
   ("THERMTRIP_N", O), ("CARRIER_HOT_N", I), ("WAKE0_N", I), ("FAN_PWMOUT", O), ("FAN_TACHIN", I), ("BIOS_SEL", I), ("GPIO0_3", B)]),
 ("CPU-LINK card-edge fingers (J1)", "cpu_link.kicad_sch", [
   "J1: Mini Cool Edge 224 card edge (mates BP J1 Amphenol ME1022410103011), 1.57 mm card, hard gold, 30 deg bevel",
   "Front (F.Cu, module side) = side B = host RX; back (B.Cu) = side A = host TX; A1/B1 at low x (front view); key F x=57.70",
   "Pinout: docs/cpulink_224_pinout_draft.csv (shared with the BP); positions: docs/cc_tab_fingers.csv",
   "Bays 1-2: Face P x16 + FP_REFCLK + USB2_FACEP; bay 3: Face S x4 + FS_REFCLK + SATA0 + USB2 MCU/FACES/SPARE; bay 4: sideband + 5V_SBY x6 + 3V3_SB x2",
   "CC_PRSNT1#/2# (A1/A112): last-mate setback pads, tied to GND on the carrier (presence detect on the BP)"],
  [("PEG_TX0_15", I), ("PEG_RX0_15", O), ("PCIE12_15_TX", I), ("PCIE12_15_RX", O), ("REFCLK0", I), ("REFCLK1", I), ("SATA0", B),
   ("USB2_0_3", B), ("SMB", B), ("I2C0", B), ("UART0", B), ("PWRBTN_N", O), ("RSTBTN_N", O), ("SUS_S3_N", I), ("SUS_S4_S5_N", I),
   ("RSMRST_OUT_N", I), ("VIN_PWR_OK", O), ("PLTRST_N", I), ("THERMTRIP_N", I), ("CARRIER_HOT_N", O), ("WAKE0_N", O),
   ("FAN_PWMOUT", I), ("FAN_TACHIN", O), ("BIOS_SEL", O), ("GPIO0_3", B), ("5V_SBY", O), ("3V3_SB", O)]),
 ("12 V input, eFuse, rails", "power.kicad_sch", [
   "LUG1-LUG4: stock PSU bus-bar lug landings (X 23.8-31.8 / 36.2-44.4 / 110.0-117.6 / 121.0-129.9 at the top edge); polarity TBD (M-CC7)",
   "U1/U2: TI TPS259851RQPR eFuse per lug pair (4.5-16 V, 0.59 mOhm, 60 A RMS, OVP 16.7 V fixed), ILIM ~15 A each, DVDT soft start",
   "Input TVS (SMBJ14A class) per pair; CB1/CB2 bulk 12V_MOD; IMON -> I2C ADC (optional) for module power telemetry",
   "eFuse PG AND BP VIN_PWR_OK -> module VIN_PWR_OK (open-drain wired-AND); FLT# -> CARRIER_HOT_N (TBD)",
   "No standby VR needed: 5V_SBY and 3V3_SB come from the BP over CPU-LINK; U5 3V3 LDO from 5V_SBY = DNP option",
   "U4: 12V -> 3V3_M2 3 A buck (only with the M.2), EN = SUS_S3_N"],
  [("5V_SBY", I), ("3V3_SB", I), ("VIN_PWR_OK_BP", I), ("VCC_12V_MOD", O), ("VCC_5V_SBY", O), ("3V3_CC", O), ("3V3_M2", O),
   ("VIN_PWR_OK", O), ("CARRIER_HOT_N", O), ("SUS_S3_N", I), ("SMB", B)]),
 ("IOB high-speed link (J3)", "iob_hs.kicad_sch", [
   "J3: MCIO 124 right-angle (Molex 2173463021 / Amphenol G97R24332HR class), MP62 pinout (TBD), direct cable over the top edge to the IOB",
   "Carries: USB3 x4 (TX/RX), USB2 x4, DDI0/DDI1 (DP/HDMI, AUX, HPD), GBE0 i226 MDI x4 pairs + LEDs, 3V3_SB/5V_SBY sense",
   "USB3 TX AC caps on the module; carrier: ESD at the IOB end; DDI AC caps per COM-HPC (module) - check ccAS UG",
   "Alternative (OD): 2 x MCIO 74 or a flex; cable route around the PSU TBD (M-CC3)"],
  [("USB3_0_3", B), ("USB2_0_3", B), ("DDI0", I), ("DDI1", I), ("GBE0_MDI", B), ("3V3_SB", I)]),
 ("Optional M.2 2280 (J7, back)", "m2.kicad_sch", [
   "J7: M.2 M-key 2280 on the back (PSU side), PCIe x4 on module lanes 8-11 + REFCLK2; DNP/TBD (OD-4)",
   "3V3_M2 from U4; PERST# = PLTRST_N; CLKREQ# to module GPIO (TBD); height limit = gap to the PSU (M-CC3)"],
  [("PCIE8_11_TX", I), ("PCIE8_11_RX", O), ("REFCLK2", I), ("3V3_M2", I), ("PLTRST_N", I)]),
 ("Debug, BIOS, carrier ID, RTC", "debug.kicad_sch", [
   "U3: 24C02 carrier EEPROM at 0x57 'CC ID' on SMB (mandatory for every compute board)",
   "J4: BOOT_SPI header 2x5 1.27 (external flash / recovery, BIOS_SEL strap); J5: eSPI header 2x5 1.27 (POST card / TPM)",
   "J6: JST SH 6P debug: UART1 TX/RX, SMB_CLK/DAT, GND, 3V3_SB; SW1 PWRBTN#, SW2 RSTBTN# (bench)",
   "BT1: CR2032 (back) -> VCC_RTC (ccAS guide recommends a carrier RTC battery); D1-D4 status LEDs"],
  [("SMB", B), ("ESPI", B), ("BOOT_SPI", B), ("UART1", B), ("PWRBTN_N", O), ("RSTBTN_N", O), ("BIOS_SEL", O), ("VCC_RTC", O), ("3V3_SB", I)]),
]
def text(s, x, y, size=1.27):
    s = s.replace('"', "'")
    return f'\t(text "{s}"\n\t\t(exclude_from_sim no)\n\t\t(at {x:.2f} {y:.2f} 0)\n\t\t(effects (font (size {size} {size})) (justify left bottom))\n\t\t(uuid "{U()}")\n\t)\n'

# ---------- sub-sheet stub files ----------
written = set()
for idx, (name, fname, desc, pins) in enumerate(SHEETS):
    if fname in written:
        continue
    written.add(fname)
    s = f'(kicad_sch\n\t{VER}\n\t(uuid "{U()}")\n\t(paper "A4")\n'
    s += f'\t(title_block\n\t\t(title "MP62 CPU carrier: {name}")\n\t\t(date "2026-10-01")\n\t\t(rev "A-bd1")\n\t\t(comment 1 "Block stub: hierarchical labels only, circuit TBD")\n\t)\n\t(lib_symbols)\n'
    y = 30.48
    for (pn, pt) in pins:
        s += f'\t(hierarchical_label "{pn}"\n\t\t(shape {pt})\n\t\t(at 38.1 {y:.2f} 180)\n\t\t{F} (justify right))\n\t\t(uuid "{U()}")\n\t)\n'
        y += 2.54
    s += text("BLOCK STUB (rev A block diagram). Contents planned:", 76.2, 30.48, 1.5)
    for i, d in enumerate(desc):
        s += text("- " + d, 76.2, 35.56 + i * 3.81)
    s += ')\n'
    open(os.path.join(PRJ, fname), "w").write(s)

# ---------- root sheet ----------
s = f'(kicad_sch\n\t{VER}\n\t(uuid "{ROOT_UUID}")\n\t(paper "A2")\n'
s += '\t(title_block\n\t\t(title "MacPro6,2 CPU carrier (CC) - top-level block diagram")\n\t\t(date "2026-10-01")\n\t\t(rev "A-bd1")\n\t\t(company "MacPro6,2 / Aidan Winkler")\n'
s += '\t\t(comment 1 "COM-HPC Client module (P1/P2) -> CPU-LINK 224 fingers (J1) -> BP hub; 12 V lugs -> eFuse -> module VCC; IOB-HS J3")\n\t\t(comment 2 "See macpro62-architecture-spec-v0.2.md sections 3.8 and 6")\n\t)\n\t(lib_symbols)\n'
s += text("MP62 CPU CARRIER rev A - BLOCK DIAGRAM. Sheets are stubs (labels only). Nets with the same label name are connected.", 25.4, 20.32, 2.0)
s += text("Off-board links: J1 CPU-LINK 224 fingers (to BP) | LUG1-4 PSU 12 V bus bars | J3 IOB-HS MCIO 124 | J4 BOOT_SPI | J5 eSPI | J6 DEBUG | J7 M.2 (opt.)", 25.4, 25.4, 1.6)
W = 60.96
cols = [(38.1, 38.1), (165.1, 38.1), (292.1, 38.1), (38.1, 200.66), (165.1, 200.66), (292.1, 200.66), (419.1, 38.1), (419.1, 200.66)]
page = 2
for idx, (name, fname, desc, pins) in enumerate(SHEETS):
    x, y = cols[idx]
    h = g(5.08 + 2.54 * len(pins))
    s += f'\t(sheet\n\t\t(at {x:.2f} {y:.2f})\n\t\t(size {W:.2f} {h:.2f})\n\t\t(exclude_from_sim no)\n\t\t(in_bom yes)\n\t\t(on_board yes)\n\t\t(dnp no)\n\t\t(fields_autoplaced yes)\n'
    s += '\t\t(stroke (width 0.1524) (type solid))\n\t\t(fill (color 0 0 0 0.0000))\n'
    s += f'\t\t(uuid "{U()}")\n'
    s += f'\t\t(property "Sheetname" "{name}"\n\t\t\t(at {x:.2f} {y - 0.71:.2f} 0)\n\t\t\t{F} (justify left bottom))\n\t\t)\n'
    s += f'\t\t(property "Sheetfile" "{fname}"\n\t\t\t(at {x:.2f} {y + h + 0.59:.2f} 0)\n\t\t\t{F} (justify left top))\n\t\t)\n'
    py = y + 2.54
    labels = ""
    for (pn, pt) in pins:
        # inputs on the left edge, everything else on the right edge
        left = (pt == "input")
        px = x if left else x + W
        ang = 180 if left else 0
        just = "left" if left else "right"
        s += f'\t\t(pin "{pn}" {pt}\n\t\t\t(at {px:.2f} {py:.2f} {ang})\n\t\t\t(uuid "{U()}")\n\t\t\t{F} (justify {just}))\n\t\t)\n'
        lx = px - 10.16 if left else px + 10.16
        labels += f'\t(wire\n\t\t(pts (xy {px:.2f} {py:.2f}) (xy {lx:.2f} {py:.2f}))\n\t\t(stroke (width 0) (type default))\n\t\t(uuid "{U()}")\n\t)\n'
        net = pn
        lang = 0 if not left else 180
        ljust = "left" if not left else "right"
        labels += f'\t(label "{net}"\n\t\t(at {lx:.2f} {py:.2f} {lang})\n\t\t(fields_autoplaced yes)\n\t\t{F} (justify {ljust} bottom))\n\t\t(uuid "{U()}")\n\t)\n'
        py += 2.54
    s += f'\t\t(instances\n\t\t\t(project "cpu_carrier"\n\t\t\t\t(path "/{ROOT_UUID}"\n\t\t\t\t\t(page "{page}")\n\t\t\t\t)\n\t\t\t)\n\t\t)\n\t)\n'
    s += labels
    page += 1
s += '\t(sheet_instances\n\t\t(path "/"\n\t\t\t(page "1")\n\t\t)\n\t)\n)\n'
open(os.path.join(PRJ, "cpu_carrier.kicad_sch"), "w").write(s)
print("schematic written")
