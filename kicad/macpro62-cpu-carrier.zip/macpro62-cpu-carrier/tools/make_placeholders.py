#!/usr/bin/env python3
"""Generate MP62 CPU-carrier (CC) placeholder footprints (KiCad 9 S-expression), mm.
Every footprint is a PLACEHOLDER: outer dimensions come from the cited drawings; pad
details are approximate and MUST be re-checked against the chosen part's drawing."""
import csv, os
HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, "..", "MP62_CC_Placeholders.pretty")
PINOUT = os.path.join(HERE, "..", "docs", "cpulink_224_pinout_draft.csv")

def eff(size=1.0, th=0.15):
    return f'(effects (font (size {size} {size}) (thickness {th})))'
def rect(x1, y1, x2, y2, layer, w=0.1):
    return f'  (fp_rect (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (stroke (width {w}) (type solid)) (fill no) (layer "{layer}"))\n'
def line(x1, y1, x2, y2, layer, w=0.1):
    return f'  (fp_line (start {x1:.3f} {y1:.3f}) (end {x2:.3f} {y2:.3f}) (stroke (width {w}) (type solid)) (layer "{layer}"))\n'
def circ(x, y, r, layer, w=0.1):
    return f'  (fp_circle (center {x:.3f} {y:.3f}) (end {x + r:.3f} {y:.3f}) (stroke (width {w}) (type solid)) (fill no) (layer "{layer}"))\n'
def text(s, x, y, layer, size=0.8):
    return f'  (fp_text user "{s}" (at {x:.3f} {y:.3f} 0) (layer "{layer}") {eff(size, size*0.15)})\n'
def smd(name, x, y, w, h, shape="rect", side="F", paste=True):
    lay = f'"{side}.Cu" "{side}.Paste" "{side}.Mask"' if paste else f'"{side}.Cu" "{side}.Mask"'
    return f'  (pad "{name}" smd {shape} (at {x:.3f} {y:.3f}) (size {w:.3f} {h:.3f}) (layers {lay}))\n'
def npth(x, y, d):
    return f'  (pad "" np_thru_hole circle (at {x:.3f} {y:.3f}) (size {d:.3f} {d:.3f}) (drill {d:.3f}) (layers "*.Cu" "*.Mask"))\n'
def pth(name, x, y, d, pad):
    return f'  (pad "{name}" thru_hole circle (at {x:.3f} {y:.3f}) (size {pad:.3f} {pad:.3f}) (drill {d:.3f}) (layers "*.Cu" "*.Mask"))\n'
def fp(name, descr, body, attr="smd", ref_y=-7, val_y=7):
    s = f'(footprint "{name}"\n  (version 20241229)\n  (generator "mp62_cc_make_placeholders")\n  (layer "F.Cu")\n'
    s += f'  (descr "{descr}")\n  (tags "MP62 PLACEHOLDER")\n'
    s += f'  (property "Reference" "REF**" (at 0 {ref_y} 0) (layer "F.SilkS") {eff()})\n'
    s += f'  (property "Value" "{name}" (at 0 {val_y} 0) (layer "F.Fab") {eff(0.8,0.12)})\n'
    s += f'  (attr {attr})\n' if attr else ''
    s += body + ')\n'
    open(os.path.join(LIB, name + ".kicad_mod"), "w").write(s)

# ---------------------------------------------------------------------------------------------
# 1. COM-HPC carrier plug, Samtec ASP-214802-01 (5 mm stack) / ASP-209948-01 (10 mm stack).
#    Samtec marketing prints: body 68.62 x 8.75, 400 positions = 4 rows x 100 at 0.635 pitch
#    (62.865 span), BGA attach; row spacing 2.20 / 2.40 / 2.20 (6.80 outer rows).
#    Row letters: P1 (mates module J1) rows A-D, P2 (mates module J2) rows E-H.
#    Row order / pin-1 end on the carrier: TBD from the COM.0 R1.x connector drawing.
def comhpc(name, rows, stack):
    b = rect(-34.31, -4.375, 34.31, 4.375, "F.Fab")
    b += rect(-34.81, -4.875, 34.81, 4.875, "F.CrtYd", 0.05)
    b += line(-35.2, -4.6, -35.2, -2.6, "F.SilkS", 0.2)
    b += text(f"PLACEHOLDER COM-HPC 400P carrier plug, {stack} mm stack (Samtec ASP-214802-01 / ASP-209948-01)", 0, -0.0, "F.Fab", 0.6)
    ys = [-3.40, -1.20, 1.20, 3.40]
    for r, yy in zip(rows, ys):
        for i in range(100):
            b += smd(f"{r}{i+1}", -31.4325 + i * 0.635, yy, 0.40, 0.40, "circle")
    fp(name, f"PLACEHOLDER COM-HPC carrier plug {stack} mm stack. Samtec ASP-214802-01 (5 mm) / ASP-209948-01 (10 mm): body 68.62 x 8.75, 4x100 BGA at 0.635 pitch, rows 2.20/2.40/2.20. Pad sizes, row order and pin-1 end approximate - use the Samtec footprint and COM.0 R1.x drawing.", b, ref_y=-6, val_y=6)
comhpc("MP62_COMHPC_Carrier_P1_RowsA-D_ASP-214802-01_PLACEHOLDER", "ABCD", 5)
comhpc("MP62_COMHPC_Carrier_P2_RowsE-H_ASP-214802-01_PLACEHOLDER", "EFGH", 5)

# ---------------------------------------------------------------------------------------------
# 2. CPU-LINK gold fingers for the Amphenol Mini Cool Edge 224 (ME1022410103011).
#    Amphenol "Recommended AIC card" (CME102241010301X rev A p.2): 224X pads 0.38 wide, 0.60 pitch;
#    level 1 pads 0.88 -> 3.00 from the tip, level 2 1.28 -> 3.00; finger offsets from datum C (card centre,
#    A-side view, A1 end at the right): A1 +38.96 .. A28 +22.76, A29 +17.85 .. A56 +1.65, A57 -2.36 .. A84 -18.56,
#    A85 -22.575 .. A112 -38.775; B row staggered 0.27 mm toward the A112 end.
#    MP62 orientation: carrier FRONT (F.Cu, module/core side) = card side B (host RX), BACK (B.Cu) = side A
#    (host TX). Seen from the front the A1/B1 end is at -x (local). Footprint origin = card centre on the tip line;
#    local +y points AWAY from the tip (into the board) because the board is drawn tip-down (frame y up) and
#    KiCad y is down: local y = -(distance from tip).
#    Level: GND = level 1 (first mate), signals/power = level 2, CC_PRSNT1#/2# = level 2 + 0.40 setback (last mate).
def offA(n):
    bay = (n - 1) // 28; k = (n - 1) % 28
    start = [38.96, 17.85, -2.36, -22.575][bay]
    return start - 0.6 * k
rows = {r["pin"]: r["signal"] for r in csv.DictReader(open(PINOUT))}
b = ""
tab = []
for n in range(1, 113):
    for side, layer in (("A", "B"), ("B", "F")):
        pin = f"{side}{n}"
        sig = rows[pin]
        x = -offA(n) + (0.27 if side == "B" else 0.0)
        if sig == "GND":
            y0, lvl = 0.88, 1
        elif sig.startswith("CC_PRSNT"):
            y0, lvl = 1.68, 3
        else:
            y0, lvl = 1.28, 2
        y1 = 3.00
        b += smd(pin, x, -(y0 + y1) / 2, 0.38, y1 - y0, "rect", layer, paste=False)
        tab.append((pin, side, "B.Cu" if layer == "B" else "F.Cu", n, x, y0, y1, lvl, sig))
# card outline reference on Fab (the real cut is on Edge.Cuts of the board)
b += rect(-39.945, -11.26, 39.945, 0.0, "F.Fab", 0.08)
b += line(-39.945, -6.0, 39.945, -6.0, "F.Fab", 0.05)
b += text("CPU-LINK 224 card edge: front = side B (host RX), back = side A (host TX); A1/B1 at -x", 0, -8.5, "F.Fab", 0.8)
b += text("shoulder >= 6.00 above tip (here 11.26); slots 7.5 deep; 1.57 +/-0.13 card", 0, -10.0, "F.Fab", 0.6)
fp("MP62_CPULINK_MiniCoolEdge224_CardEdge_Fingers", "CPU-LINK edge fingers for Amphenol Mini Cool Edge 224 (ME1022410103011), per Amphenol recommended AIC card (CME102241010301X rev A). Front F.Cu = side B, back B.Cu = side A. GND level 1, signals level 2, CC_PRSNT setback (proposal). Hard gold, bevel 30 deg.", b, attr="smd", ref_y=-12.5, val_y=-13.8)
with open(os.path.join(HERE, "..", "docs", "cc_tab_fingers.csv"), "w") as f:
    f.write("pin,side,layer,bay,x_local_mm,x_carrier_mm,from_tip_start_mm,from_tip_end_mm,level,signal\n")
    for (pin, side, lay, n, x, y0, y1, lvl, sig) in tab:
        f.write(f"{pin},{side},{lay},{(n-1)//28+1},{x:.3f},{78.0 + x:.3f},{y0:.2f},{y1:.2f},{lvl},{sig}\n")

# ---------------------------------------------------------------------------------------------
# 3. Stock heatsink hole (thermal-core mount) D5.0, plated, 9.0 pad; knurled standoff ~D8.4 on the stock board.
b = pth("1", 0, 0, 5.0, 9.0) + circ(0, 0, 4.2, "F.Fab") + circ(0, 0, 5.0, "F.CrtYd", 0.05)
b += text("CORE MOUNT D5 (stock heatsink hole) - MUST STAY", 0, 6.2, "F.Fab", 0.7)
fp("MP62_CC_CoreMountHole_D5.0_Pad9", "Stock MacPro6,2 CPU-board heatsink/thermal-core mounting hole D5.0 (CAD), plated GND ring 9.0; stock knurled standoff ~D8.4 (scan).", b, attr="", ref_y=-6, val_y=7.4)

# 4. COM-HPC module mounting hole M2.5 (CDG: D2.7, Wuerth 9774050951 5 mm SMT spacer / PEM). Pad 6.0.
b = pth("1", 0, 0, 2.7, 6.0) + circ(0, 0, 3.25, "F.CrtYd", 0.05) + circ(0, 0, 2.55, "F.Fab")
fp("MP62_CC_COMHPC_ModuleHole_M2.5_D2.7_Pad6", "COM-HPC module mounting hole, D2.7 plated, 6.0 pad (GND); 5 mm spacer Wuerth 9774050951 (10 mm: 9774100951) per PICMG CDG rev 2.0.", b, attr="", ref_y=-4.2, val_y=4.2)

# 5. 12 V bus-bar lug landing (stock PSU lug pairs). 8 x 6 mm pad, 2x3 D1.3 PTH (press-fit / solder tab), TBD.
b = smd("1", 0, 0, 8.0, 6.0) + smd("1", 0, 0, 8.0, 6.0, side="B")
for xx in (-2.5, 0, 2.5):
    for yy in (-1.5, 1.5):
        b += pth("1", xx, yy, 1.3, 2.0)
b += rect(-4.3, -3.3, 4.3, 3.3, "F.CrtYd", 0.05)
b += text("12V LUG (stock bus-bar tab) - type/polarity TBD", 0, -4.0, "F.Fab", 0.6)
fp("MP62_CC_BusBarLug_8x6_PLACEHOLDER", "PLACEHOLDER 12 V bus-bar lug landing (stock lug positions from the scan). Lug type, screw size, plating and polarity TBD (measure M-CC7).", b, attr="", ref_y=4.3, val_y=5.6)

# 6. M.2 2280 M-key socket (back side) with card zone and standoff.
b = rect(-2.5, -11.0, 2.5, 11.0, "F.Fab") + rect(2.5, -11.0, 2.5 + 80.0, 11.0, "F.Fab")
b += rect(-3.0, -11.5, 2.5 + 80.0 + 3.0, 11.5, "F.CrtYd", 0.05)
b += rect(-2.65, -11.15, 2.65, 11.15, "F.SilkS", 0.12)
b += text("PLACEHOLDER M.2 M-key 2280 (PCIe x4 lanes 8-11), DNP/TBD (OD-4)", 42, -2, "F.Fab", 0.8)
b += text("card zone 22 x 80: no parts > 1.5 mm under the card", 42, 1, "F.Fab", 0.8)
b += smd("MP", 0, -10.2, 2.0, 1.2) + smd("MP", 0, 10.2, 2.0, 1.2)
for i in range(67):
    b += smd(str(i + 1), -1.2 if i % 2 == 0 else 1.2, -8.25 + i * 0.25, 1.4, 0.2)
b += pth("S", 2.5 + 80.0 - 1.5, 0, 2.2, 5.0)
fp("MP62_CC_M2_2280_MKey_PLACEHOLDER", "PLACEHOLDER M.2 M-key socket + 2280 card zone + standoff. Pads approximate (0.5 pitch interleaved); choose a JLC-stocked socket.", b, ref_y=-13, val_y=13)

# 7. Generic area placeholders (no pads)
def area(name, w, h, lines, descr):
    b = rect(-w/2, -h/2, w/2, h/2, "F.Fab")
    b += rect(-w/2 - 0.25, -h/2 - 0.25, w/2 + 0.25, h/2 + 0.25, "F.CrtYd", 0.05)
    b += rect(-w/2, -h/2, w/2, h/2, "F.SilkS", 0.12)
    for i, s in enumerate(lines):
        b += text(s, 0, -h/2 + 1.6 + i * 1.3, "F.Fab", 0.7)
    fp(name, descr, b, attr="smd allow_missing_courtyard", ref_y=-h/2 - 1.3, val_y=h/2 + 1.3)
area("MP62_CC_AREA_eFuse_TPS25985_14x12_PLACEHOLDER", 14, 12,
     ["12V eFuse TPS259851 (RQP 4.5x5)", "60 A RMS rating, ILIM ~15 A", "OVP 16.7 V fixed, UVLO ~10.8 V", "+ input TVS (SMBJ14A class)", "+ IMON -> carrier ADC/BP", "PG -> VIN_PWR_OK qualifier"],
     "PLACEHOLDER area: TI TPS259851RQPR eFuse (4.5-16 V, 0.59 mOhm, 60 A RMS) + input TVS, ILIM/DVDT/UV resistors, IMON. One per lug pair.")
area("MP62_CC_AREA_Bulk12V_14x8_PLACEHOLDER", 14, 8,
     ["12V_MOD bulk: 4x 470uF 16V polymer", "+ 10x 22uF 25V X5R 1206", "(module has its own input caps)"],
     "PLACEHOLDER area: bulk capacitance on the module 12 V input (after the eFuse).")
area("MP62_CC_AREA_Buck3V3_M2_10x8_PLACEHOLDER", 10, 8,
     ["12V -> 3V3_M2 buck 3 A", "(TPS56637/TPS62933 class)", "EN = SUS_S3# (S0 only)"],
     "PLACEHOLDER area: 12 V -> 3.3 V 3 A buck for the M.2 socket (only if the M.2 is fitted).")
area("MP62_CC_AREA_LDO3V3SB_6x5_PLACEHOLDER", 6, 5,
     ["DNP: 5V_SBY->3V3", "LDO (if BP 3V3_SB", "is not enough)"],
     "PLACEHOLDER DNP area: 5V_SBY -> 3V3 LDO, only if 3V3_SB from the BP is insufficient.")
print("placeholders ok")
