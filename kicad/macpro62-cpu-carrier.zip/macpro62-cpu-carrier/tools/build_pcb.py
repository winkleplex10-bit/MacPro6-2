#!/usr/bin/env python3
"""MacPro6,2 CPU carrier (CC) rev-A first-pass floorplan, KiCad 9 pcbnew API (system python3).
Carrier frame ('CAD frame' of the stock riser, Fusion/scan): origin bottom-left, x right (0..156),
y up from the board bottom (tab tip y=1.722, shoulder y=12.982, top edge y=169.5); FRONT = socket/module
side = thermal-core side. KiCad sheet: X = 60 + x, Y = 240 - y (A3)."""
import json, math, os, sys
import pcbnew, ezdxf
from pcbnew import FromMM, VECTOR2I
from shapely.geometry import Polygon, box, Point
from shapely.ops import unary_union

HERE = os.path.dirname(os.path.abspath(__file__))
PRJ = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(PRJ, "cpu_carrier.kicad_pcb")
SYS = "/usr/share/kicad/footprints"
LOC = os.path.join(PRJ, "MP62_CC_Placeholders.pretty")
DXF = "/workspace/bracket/cpu_board/cpu_board_outline_corrected.dxf"
OX, OY = 60.0, 240.0
def P(x, y): return VECTOR2I(FromMM(float(OX + x)), FromMM(float(OY - y)))

board = pcbnew.NewBoard(OUT)
board.SetCopperLayerCount(8)
ds = board.GetDesignSettings()
ds.SetBoardThickness(FromMM(1.6))
# JLC 8-layer capabilities (conservative std): 0.09/0.09 mm track/space, via 0.15/0.25 (via-in-pad POFV for the 0.635 BGA)
ds.m_TrackMinWidth = FromMM(0.09); ds.m_MinClearance = FromMM(0.09)
ds.m_ViasMinSize = FromMM(0.25); ds.m_MinThroughDrill = FromMM(0.15)
ds.m_CopperEdgeClearance = FromMM(0.5); ds.m_HoleClearance = FromMM(0.2); ds.m_HoleToHoleMin = FromMM(0.5)
ds.m_SilkClearance = FromMM(0.0)
pi = board.GetPageSettings() if hasattr(board, "GetPageSettings") else None
try:
    ps = pcbnew.PAGE_INFO(); ps.SetType("A3"); board.SetPageSettings(ps)
except Exception:
    pass

tb = board.GetTitleBlock()
tb.SetTitle("MacPro6,2 CPU carrier (CC) for COM-HPC Client - rev A floorplan fp1")
tb.SetRevision("A-fp1"); tb.SetDate("2026-10-01"); tb.SetCompany("MacPro6,2 / Aidan Winkler")
tb.SetComment(0, "Edge.Cuts: stock riser outline (cpu_board_outline_corrected.dxf, OUTLINE_CORRECTED) with a NEW Mini Cool Edge 224 tab 79.89 wide at x=78")
tb.SetComment(1, "Stackup: JLC 8L 1.6 mm (JLC08161H-2116 class, confirm): L1 sig/L2 GND/L3 sig/L4 GND/L5 PWR/L6 sig/L7 GND/L8 sig, ENIG + hard-gold fingers")
tb.SetComment(2, "Module: COM-HPC Client Size C (Kontron COMh-ccAS, i5-14500T) drawn at option C1; CPU lands 4.2 mm left of the pedestal centre; overhang + chamfer clash flagged")
tb.SetComment(3, "PLACEHOLDER footprints *_PLACEHOLDER. Module connector/hole/CPU positions from the Kontron ccAS UG photo/figure (+-2 mm): verify vs COM.0 R1.x")

def seg(x1, y1, x2, y2, layer, w=0.1):
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(P(x1, y1)); s.SetEnd(P(x2, y2)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def arc3(p1, pm, p2, layer, w=0.1):
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_ARC)
    s.SetArcGeometry(P(*p1), P(*pm), P(*p2)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def rect(x1, y1, x2, y2, layer, w=0.15):
    for a, b in (((x1, y1), (x2, y1)), ((x2, y1), (x2, y2)), ((x2, y2), (x1, y2)), ((x1, y2), (x1, y1))):
        seg(*a, *b, layer, w)
def circle(x, y, r, layer, w=0.1):
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_CIRCLE)
    s.SetCenter(P(x, y)); s.SetEnd(P(x + r, y)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def txt(s, x, y, layer=pcbnew.Cmts_User, size=1.2, angle=0.0, left=False):
    t = pcbnew.PCB_TEXT(board); t.SetText(s); t.SetPosition(P(x, y)); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size))); t.SetTextThickness(FromMM(size * 0.15))
    t.SetTextAngleDegrees(angle)
    if left: t.SetHorizJustify(pcbnew.GR_TEXT_H_ALIGN_LEFT)
    board.Add(t)

# ---------------- outline: stock DXF minus the stock tab, plus the new 224 tab ----------------
doc = ezdxf.readfile(DXF)
pl = [e for e in doc.modelspace() if e.dxf.layer == "OUTLINE_CORRECTED" and e.dxftype() == "LWPOLYLINE"][0]
V = [(float(round(x, 4)), float(round(y, 4)), float(b)) for x, y, s0, s1, b in pl.get_points("xyseb")]
i0 = [i for i, v in enumerate(V) if abs(v[0] - 136.309) < 0.01 and abs(v[1] - 12.982) < 0.01][0]
i1 = [i for i, v in enumerate(V) if abs(v[0] - 19.691) < 0.01 and abs(v[1] - 12.982) < 0.01][0]
stock = V[i0:i1 + 1]           # right shoulder -> around the top -> left shoulder (keeps every stock bulge)
poly_pts = []                   # for shapely
def bulge_mid(p1, p2, b):
    mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]; L = math.hypot(dx, dy)
    s = b * L / 2.0
    return (mx + s * dy / L, my - s * dx / L)
def arc_pts(p1, pm, p2, n=12):
    # circle through three points, sampled
    (ax, ay), (bx, by), (cx, cy) = p1, pm, p2
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    ux = ((ax*ax + ay*ay) * (by - cy) + (bx*bx + by*by) * (cy - ay) + (cx*cx + cy*cy) * (ay - by)) / d
    uy = ((ax*ax + ay*ay) * (cx - bx) + (bx*bx + by*by) * (ax - cx) + (cx*cx + cy*cy) * (bx - ax)) / d
    r = math.hypot(ax - ux, ay - uy)
    a1, am, a2 = (math.atan2(p[1] - uy, p[0] - ux) for p in (p1, pm, p2))
    def norm(a): return a % (2 * math.pi)
    ccw = norm(am - a1) < norm(a2 - a1)
    sweep = norm(a2 - a1) if ccw else -norm(a1 - a2)
    return [(ux + r * math.cos(a1 + sweep * k / n), uy + r * math.sin(a1 + sweep * k / n)) for k in range(1, n + 1)]
def E_line(p1, p2):
    seg(*p1, *p2, pcbnew.Edge_Cuts, 0.1); poly_pts.append(p2)
def E_arc(p1, pm, p2):
    arc3(p1, pm, p2, pcbnew.Edge_Cuts, 0.1); poly_pts.extend(arc_pts(p1, pm, p2))
poly_pts.append(stock[0][:2])
for k in range(len(stock) - 1):
    p1, p2, b = stock[k][:2], stock[k + 1][:2], stock[k][2]
    if abs(b) > 1e-6: E_arc(p1, bulge_mid(p1, p2, b), p2)
    else: E_line(p1, p2)
# new tab (Amphenol recommended AIC card, CME102241010301X rev A p.2), front view: A1 end at low x
T = 1.722; SH = 12.982; XC = 78.0; HW = 79.89 / 2; CH = 0.75; RIN = 0.30; SLOT_D = 7.5
XL, XR = XC - HW, XC + HW
SLOTS = [(XC - 20.30, 2.40, "KEY F"), (XC + 0.36, 1.85, "slot"), (XC + 20.57, 1.85, "slot")]
c45 = math.cos(math.radians(45))
cur = (19.691, SH)
E_line(cur, (XL - RIN, SH))
E_arc((XL - RIN, SH), (XL - RIN + RIN * c45, SH - RIN + RIN * c45), (XL, SH - RIN))
E_line((XL, SH - RIN), (XL, T + CH))
a = XL
bounds = []
for (sx, w, nm) in SLOTS:
    bounds.append((a, sx - w / 2)); a = sx + w / 2
bounds.append((a, XR))
for k, (a, b) in enumerate(bounds):
    E_line((a, T + CH), (a + CH, T)); E_line((a + CH, T), (b - CH, T)); E_line((b - CH, T), (b, T + CH))
    if k < len(SLOTS):
        sx, w, nm = SLOTS[k]; r = w / 2; yc = T + SLOT_D - r
        E_line((b, T + CH), (b, yc)); E_arc((b, yc), (sx, yc + r), (b + w, yc)); E_line((b + w, yc), (b + w, T + CH))
E_line((XR, T + CH), (XR, SH - RIN))
E_arc((XR, SH - RIN), (XR + RIN - RIN * c45, SH - RIN + RIN * c45), (XR + RIN, SH))
E_line((XR + RIN, SH), (136.309, SH))
BOARD = Polygon(poly_pts).buffer(0)
for (sx, w, nm) in SLOTS:
    txt("%s %.2f w, x=%.2f" % (nm, w, sx), sx, T + SLOT_D + 1.2, pcbnew.Cmts_User, 0.7)
txt("NEW CPU-LINK TAB: Mini Cool Edge 224 card 79.89 +/-0.10 x 1.57, x %.3f-%.3f, tip y 1.722, shoulder y 12.982 (11.26 >= 6.00 MIN)" % (XL, XR), XC, -1.0, pcbnew.Cmts_User, 1.0)
txt("8x 0.75x45 deg tip chamfers, 30 deg bevel, slots 7.5 deep (>= 7.00), R0.30 inside corners; hard gold, no vias y<6", XC, -2.8, pcbnew.Cmts_User, 0.9)
txt("stock tab was x 45.364-111.021 (65.66), key 2.12 @ x 69.03 (front view; 86.97 was the back-view scan) -> removed; shoulder flat 19.69-136.31 and lower chamfers UNCHANGED", XC, -4.6, pcbnew.Cmts_User, 0.9)
# stock tab ghost
for k in range(7):
    p1, p2 = V[k][:2], V[(k + 1)][:2]
    seg(*p1, *p2, pcbnew.Eco2_User, 0.08)

# ---------------- footprint placement helper ----------------
placed = []
def place(ref, lib, name, x, y, rot=0.0, value=None, side="F", center=True):
    libpath = LOC if lib == "MP62_CC_Placeholders" else os.path.join(SYS, lib + ".pretty")
    f = pcbnew.FootprintLoad(libpath, name)
    if f is None: sys.exit("missing footprint %s:%s" % (lib, name))
    f.SetFPID(pcbnew.LIB_ID(lib, name)); f.SetReference(ref); f.SetValue(value or name)
    f.SetPosition(P(x, y)); f.SetOrientationDegrees(rot); board.Add(f)
    if center:
        try:
            cb = f.GetCourtyard(pcbnew.F_CrtYd).BBox()
            cc = cb.GetCenter() if cb.GetWidth() > 0 else f.GetBoundingBox(False).GetCenter()
        except Exception:
            cc = f.GetBoundingBox(False).GetCenter()
        tgt = P(x, y); f.Move(VECTOR2I(tgt.x - cc.x, tgt.y - cc.y))
    if side == "B": f.Flip(f.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    placed.append((ref, f, value or name, side))
    return f

# ---------------- holes ----------------
CORE_HOLES = [(43.25, 46.0), (112.75, 46.0), (43.25, 101.0), (112.75, 101.0)]
for i, (x, y) in enumerate(CORE_HOLES):
    place("H%d" % (i + 1), "MP62_CC_Placeholders", "MP62_CC_CoreMountHole_D5.0_Pad9", x, y, center=False,
          value="CORE D5")
    circle(x, y, 6.0, pcbnew.Cmts_User, 0.1)
txt("4x CORE D5 (69.5 x 55) KEEP - blocked by the module (note 4)", 78.0, 108.0, pcbnew.Cmts_User, 0.9)
# stock ILM holes (dropped) as ghosts
ILM_SCREWS = [(43.0, 57.5), (113.2, 57.6), (42.5, 89.9), (113.4, 90.2)]   # measured, Xeon scan (fp2), +-0.6
for (x, y) in ILM_SCREWS:
    circle(x, y, 2.5, pcbnew.Eco2_User, 0.08); circle(x, y, 5.3, pcbnew.Eco2_User, 0.08)
txt("stock ILM screws (measured 70.6 x 32.5, dropped)", 43.0, 61.2, pcbnew.Eco2_User, 0.7)

# COM-HPC Size C module, option C1: module origin (-2, 13.3) in the carrier frame, top view (= carrier front)
MX, MY = -2.0, 13.3
MOD_HOLES = [(20, 6), (20, 114), (100, 14), (100, 106), (156, 4), (156, 116)]
k = 1
for (u, v) in MOD_HOLES:
    x, y = MX + u, MY + v
    ok_h = BOARD.contains(Point(x, y).buffer(3.25 + 0.5))
    if ok_h:
        place("MH%d" % k, "MP62_CC_Placeholders", "MP62_CC_COMHPC_ModuleHole_M2.5_D2.7_Pad6", x, y, center=False,
              value="MOD M2.5 (%d,%d)" % (u, v)); k += 1
    else:
        circle(x, y, 1.35, pcbnew.Dwgs_User, 0.15); circle(x, y, 3.0, pcbnew.Dwgs_User, 0.1)
        txt("module hole (%d,%d) NOT USABLE (off board)" % (u, v), x - 1.0, y + (4.5 if v > 60 else -4.5), pcbnew.Cmts_User, 0.8, left=False)

# ---------------- COM-HPC connectors ----------------
place("P1", "MP62_CC_Placeholders", "MP62_COMHPC_Carrier_P1_RowsA-D_ASP-214802-01_PLACEHOLDER", MX + 60, MY + 113,
      value="P1 = module J1 (A-D): 12V VCC, PCIe 0-15, USB, eSPI/SPI")
place("P2", "MP62_CC_Placeholders", "MP62_COMHPC_Carrier_P2_RowsE-H_ASP-214802-01_PLACEHOLDER", MX + 60, MY + 7,
      value="P2 = module J2 (E-H): PCIe 16-31 PEG, DDI")

# ---------------- CPU-LINK fingers ----------------
place("J1", "MP62_CC_Placeholders", "MP62_CPULINK_MiniCoolEdge224_CardEdge_Fingers", XC, T, center=False,
      value="J1 CPU-LINK 224 fingers")

# ---------------- top band (front): power, IOB-HS, headers ----------------
LUGS = [("LUG1", 30.5, "GND?"), ("LUG2", 42.2, "12V?"), ("LUG3", 115.7, "12V?"), ("LUG4", 128.2, "GND?")]   # fp2: mirrored to the front view
for ref, x, pol in LUGS:
    place(ref, "MP62_CC_Placeholders", "MP62_CC_BusBarLug_8x6_PLACEHOLDER", x, 159.8, center=False,
          value="%s %s" % (ref, pol))
place("U1", "MP62_CC_Placeholders", "MP62_CC_AREA_eFuse_TPS25985_14x12_PLACEHOLDER", 34.0, 147.5, value="eFuse L")
place("U2", "MP62_CC_Placeholders", "MP62_CC_AREA_eFuse_TPS25985_14x12_PLACEHOLDER", 120.0, 147.5, value="eFuse R")
place("CB1", "MP62_CC_Placeholders", "MP62_CC_AREA_Bulk12V_14x8_PLACEHOLDER", 13.5, 139.0, value="bulk")
place("CB2", "MP62_CC_Placeholders", "MP62_CC_AREA_Bulk12V_14x8_PLACEHOLDER", 142.5, 139.0, value="bulk")
J3 = place("J3", "MP62_CC_Placeholders", "MP62_MCIO_124P_RightAngle_SMT_PLACEHOLDER", XC, 143.0, center=False,
      value="J3 IOB-HS MCIO 124 RA")
place("U5", "MP62_CC_Placeholders", "MP62_CC_AREA_LDO3V3SB_6x5_PLACEHOLDER", 50.5, 150.0, value="DNP")
place("U3", "Package_TO_SOT_SMD", "SOT-23-5", 104.5, 139.5, value="EEPROM 0x57")
place("J4", "Connector_PinHeader_1.27mm", "PinHeader_2x05_P1.27mm_Vertical_SMD", 8.5, 156.0, value="BOOT_SPI")
place("J5", "Connector_PinHeader_1.27mm", "PinHeader_2x05_P1.27mm_Vertical_SMD", 18.0, 156.0, value="eSPI")
place("J6", "Connector_JST", "JST_SH_SM06B-SRSS-TB_1x06-1MP_P1.00mm_Horizontal", 146.0, 157.0, value="DEBUG")
place("SW1", "Button_Switch_SMD", "SW_SPST_PTS810", 139.5, 150.0, value="PWR")
place("SW2", "Button_Switch_SMD", "SW_SPST_PTS810", 146.5, 150.0, value="RST")
for i, (nm, x) in enumerate((("12V_IN", 103.5), ("VCC_PG", 103.5), ("SUS_S3#", 106.5), ("PLTRST#", 106.5))):
    place("D%d" % (i + 1), "LED_SMD", "LED_0603_1608Metric", x, 145.0 + (i % 2) * 3.0, value=nm).Reference().SetVisible(False)

# ---------------- back side ----------------
place("J7", "MP62_CC_Placeholders", "MP62_CC_M2_2280_MKey_PLACEHOLDER", 74.0, 108.0, rot=-90, side="B", center=False,
      value="J7 M.2 2280 (back, DNP/TBD)")
place("U4", "MP62_CC_Placeholders", "MP62_CC_AREA_Buck3V3_M2_10x8_PLACEHOLDER", 92.0, 111.0, side="B", value="3V3_M2 buck")
place("BT1", "Battery", "BatteryHolder_Keystone_3034_1x20mm", 138.0, 75.0, side="B", value="CR2032 RTC (back)")

# ---------------- rule areas ----------------
def rule_area(name, pts, layers, fp=False, vias=False, tracks=False, pads=False, pour=False):
    z = pcbnew.ZONE(board); z.SetIsRuleArea(True)
    z.SetDoNotAllowFootprints(fp); z.SetDoNotAllowVias(vias); z.SetDoNotAllowTracks(tracks)
    z.SetDoNotAllowPads(pads); z.SetDoNotAllowCopperPour(pour); z.SetZoneName(name)
    ls = pcbnew.LSET(); [ls.AddLayer(l) for l in layers]; z.SetLayerSet(ls)
    o = z.Outline(); o.NewOutline()
    for (x, y) in pts:
        p = P(x, y); o.Append(p.x, p.y)
    board.Add(z)
ALLCU = [pcbnew.F_Cu, pcbnew.B_Cu] + [getattr(pcbnew, "In%d_Cu" % i) for i in range(1, 7)]
rule_area("TAB_FINGERS_NO_VIAS", [(XL - 0.5, 0.0), (XR + 0.5, 0.0), (XR + 0.5, 6.0), (XL - 0.5, 6.0)], ALLCU, vias=True, pour=True)
txt("NO VIAS / NO POUR y < 6 (fingers, bevel)", XC, 6.6, pcbnew.Cmts_User, 0.7)
BP_ZONE = (51.75, 38.3, 104.25, 115.3)
x1, y1, x2, y2 = BP_ZONE
rule_area("CPU_BACKPLATE_LOAD_ZONE_F", [(x1, y1), (x2, y1), (x2, y2), (x1, y2)], [pcbnew.F_Cu], fp=True)
rect(x1, y1, x2, y2, pcbnew.Cmts_User, 0.12)
txt("F KEEPOUT: module CPU backplate + load path (note 5)", (x1 + x2) / 2, y1 + 1.6, pcbnew.Cmts_User, 0.8)
for (x, y) in CORE_HOLES:
    n = 32
    rule_area("CORE_BOSS_%d_%d" % (x, y), [(x + 6 * math.cos(2 * math.pi * i / n), y + 6 * math.sin(2 * math.pi * i / n)) for i in range(n)],
              ALLCU, tracks=True, vias=True)

# ---------------- drawings: pedestal, module C1, alternatives, stock features ----------------
D = pcbnew.Dwgs_User
PED = (78.41, 73.25)          # measured (core scan, fp2): 40.6 x 41.1, corner R ~8, flush with the black plate
PW, PH = 40.6, 41.1
rect(PED[0] - PW / 2, PED[1] - PH / 2, PED[0] + PW / 2, PED[1] + PH / 2, D, 0.3)
circle(PED[0], PED[1], 1.0, D, 0.3); seg(PED[0] - 4, PED[1], PED[0] + 4, PED[1], D, 0.2); seg(PED[0], PED[1] - 4, PED[0], PED[1] + 4, D, 0.2)
txt("CORE PEDESTAL 40.6x41.1 MEASURED @ (78.4, 73.25), flush w/ plate", PED[0], PED[1] + PH / 2 + 1.2, D, 0.9)
txt("stock IHS 39.8x39.7 @ (78.3, 73.4)", PED[0], PED[1] - PH / 2 - 1.2, D, 0.7)
PLATE = (16.2, 22.5, 140.4, 164.4)   # measured black plate = contact plane (7.5 +-0.5 above the stock board front)
rect(PLATE[0], PLATE[1], PLATE[2], PLATE[3], pcbnew.Cmts_User, 0.3)
txt("CORE BLACK PLATE 124x142 (blue box, flat, flush w/ pedestal) = FRONT HEIGHT ZONE: parts under it < plate gap - 0.5", 78.0, 134.6, pcbnew.Cmts_User, 0.7)
rect(47.6, 39.4, 108.5, 108.6, pcbnew.Eco2_User, 0.08)
txt("stock ILM frame body (measured)", 78, 107.2, pcbnew.Eco2_User, 0.7)
# module C1
rect(MX, MY, MX + 160, MY + 120, D, 0.4)
txt("COM-HPC SIZE C 160x120 (COMh-ccAS) option C1 (note 1)", MX + 80, MY + 118.3, D, 1.0)
CPU = (MX + 75.8, MY + 60.2)
rect(CPU[0] - 21.3, CPU[1] - 24.85, CPU[0] + 21.3, CPU[1] + 24.85, D, 0.25)
rect(CPU[0] - 18.75, CPU[1] - 22.5, CPU[0] + 18.75, CPU[1] + 22.5, D, 0.15)
circle(CPU[0], CPU[1], 0.8, D, 0.3)
txt("ccAS CPU (%.1f, %.1f): pedestal -4.6 x, +0.25 y" % CPU, CPU[0], CPU[1] - 26.6, D, 0.9)
# module ILM / contact-frame screws (Kontron UG Fig. 6 dots, +-1 mm) and a TG-class contact frame outline (51/54 x 71, <= 6.0 tall)
for (u, v) in ((57.7, 90.0), (93.7, 90.0), (55.7, 30.2), (95.8, 30.2)):
    circle(MX + u, MY + v, 1.8, D, 0.15); circle(MX + u, MY + v, 3.0, pcbnew.Cmts_User, 0.12)
txt("module ILM / contact-frame screws: tips in F keep-out (sec. 6.8)", CPU[0], MY + 30.2 - 4.2, pcbnew.Cmts_User, 0.7)
rect(CPU[0] - 27.0, CPU[1] - 35.5, CPU[0] + 27.0, CPU[1] + 35.5, pcbnew.Eco1_User, 0.15)
txt("contact frame 54x71 (TG/TR class, on module top, <= 6.0 tall)", CPU[0], CPU[1] + 36.6, pcbnew.Eco1_User, 0.7)
rect(MX + 125, MY + 4, MX + 155, MY + 116, D, 0.15)
txt("module SO-DIMMs (top side, 4 / 8 mm)", MX + 140, MY + 60, D, 0.8, angle=90)
clash = Polygon([(MX, MY), (MX + 160, MY), (MX + 160, MY + 120), (MX, MY + 120)]).difference(BOARD)
for g in getattr(clash, "geoms", [clash]):
    if g.area > 0.5:
        cx, cy = g.centroid.x, g.centroid.y
        txt("CLASH %.0f mm2" % g.area, cx, cy, pcbnew.Cmts_User, 0.8)
# alternatives (Eco1)
A_ = pcbnew.Eco1_User
rect(17.1, 22.3, 137.1, 117.3, A_, 0.2); txt("ALT Size A 120x95 (e.g. COMh-caRP, BGA CPU): CPU exactly on pedestal, fits", 77.1, 115.6, A_, 0.8)
rect(-2.0, 28.0, 158.0, 148.0, A_, 0.2); txt("ALT C2 (Size C raised, y 28-148): CPU +14.7 above pedestal", 128.0, 29.6, A_, 0.7)
rect(18.0, 13.5, 138.0, 133.5, A_, 0.12); txt("ALT Size B 120x120 (CPU position vendor-specific)", 78.0, 131.8, A_, 0.7)
# guide posts and lugs
for gx in (28.5, 126.4):   # core-flange guide pins (core scan fp2; old posts 29.05/126.98 were a back view)
    rect(gx - 1.25, -1.5, gx + 1.25, 17.6, D, 0.15); txt("CORE guide pin ~D2.5 (core flange, y -1.5..17.6)", gx, -3.2, D, 0.6)
for ref, x, pol in LUGS:
    txt("%s %s" % (ref, pol), x, 166.0, pcbnew.Cmts_User, 0.8)


NOTES = [
 "MP62 CPU CARRIER (CC) rev A floorplan fp2 - carrier frame: x right, y up from the board bottom, FRONT = module/core side",
 "1  Module: COM-HPC Client Size C (Kontron COMh-ccAS, LGA1700, i5-14500T) at option C1, origin (-2, 13.3), top view.",
 "   160 > 156: overhangs the outline 2 mm each side and clashes with both lower chamfer corners (CLASH areas).",
 "   CPU centre (73.8, 73.5) vs MEASURED pedestal (78.4, 73.25) 40.6x41.1: -4.6 x / +0.25 y; LGA1700 IHS still on the pedestal.",
 "   Usable module holes 4 of 6: (18,19.3) (18,127.3) (98,27.3) (98,119.3); (154,17.3) and (154,129.3) off board.",
 "2  Alternatives (Eco1): Size A 120x95 fits with the CPU exactly on the pedestal (BGA CPUs only);",
 "   Size B 120x120 fits if its CPU is near the module centre; C2 = Size C raised to clear the chamfers (CPU +14.7 mm).",
 "3  Core face (fp2, measured): pedestal FLUSH with a flat 124x142 black plate = contact plane 7.5+-0.5 above the stock board.",
 "   Bare IHS 13.5 (5 mm stack) -> carrier must sit ~6 mm (1 DIMM) / ~8 mm + 2 mm Cu spacer (2 DIMMs) farther from the core.",
 "4  4x CORE D5 holes (stock heatsink, 69.5 x 55) kept as required, but every COM-HPC size covers them:",
 "   proposal = MP62 core adapter plate (HSP replacement) bolted to the core bosses, module + carrier screwed to it.",
 "5  F keep-out under the module CPU: backplate (est. from the ccAS back photo) + pedestal load path.",
 "6  12 V: LUG2/LUG3 (polarity TBD) -> U1/U2 TPS259851 eFuse -> CB1/CB2 bulk -> P1 VCC pins. 5V_SBY/3V3_SB from BP via J1.",
 "7  J1 CPU-LINK fingers: FRONT = side B (host RX), BACK = side A (host TX), A1/B1 at low x; key F x=57.70.",
 "8  TOP BAND y 134-163: J3 MCIO RA, eFuses, headers, EEPROM, LEDs - UNDER THE PLATE up to y 164.4 (x 16-140):",
 "   front height <= 7.5 + offset - 0.5. Guide pins (core) at x 28.5/126.4. BACK: J7 M.2 (DNP/TBD), U4, BT1 (gap M-CC3).",
 "9  Stackup: JLC 8L 1.6 mm (JLC08161H-2116 class, confirm): L1 S / L2 G / L3 S / L4 G / L5 P / L6 S / L7 G / L8 S.",
 "   Placeholders (*_PLACEHOLDER) = real outer dims; pads approximate. Layers: Dwgs = module/pedestal, Eco1 = alternatives,",
 "   Eco2 = stock ghosts (old tab, ILM holes/envelope), Cmts = keep-outs/notes.",
]
for i, n in enumerate(NOTES):
    txt(n, 162.0, 168.0 - i * 3.2, pcbnew.User_1, 1.3 if i == 0 else 1.1, left=True)

# ---------------- fit check report ----------------
rep = []
def fit(name, x0, y0, w, h, cpu=None):
    m = box(x0, y0, x0 + w, y0 + h)
    out = m.difference(BOARD)
    d = out.hausdorff_distance(BOARD) if not out.is_empty else 0.0
    line = "%-38s rect x %.1f..%.1f y %.1f..%.1f  outside-board area %6.1f mm2" % (name, x0, x0 + w, y0, y0 + h, out.area)
    if cpu: line += "  CPU (%.1f, %.1f) -> d=(%+.1f, %+.1f) vs measured pedestal (78.41, 73.25)" % (cpu[0], cpu[1], cpu[0] - PED[0], cpu[1] - PED[1])
    rep.append(line)
fit("Size C C1 (ccAS, origin -2,13.3)", MX, MY, 160, 120, CPU)
fit("Size C on-pedestal (origin 2.2,13.3)", 2.2, 13.3, 160, 120, (78.0, 73.5))
fit("Size C C2 raised (origin -2,28)", -2, 28, 160, 120, (73.8, 88.2))
fit("Size C rot 90 (needs 160 tall)", 18, 13.3, 120, 160, None)
fit("Size A (caRP, CPU on pedestal)", 17.1, 22.3, 120, 95, (78.0, 73.5))
fit("Size B (centred CPU assumed)", 18, 13.5, 120, 120, (78.0, 73.5))
rep.append("fp2 measured pedestal 40.6 x 41.1 @ (78.41, 73.25) (x %.1f-%.1f, y %.1f-%.1f); black plate x 16.2-140.4, y 22.5-164.4" % (
    PED[0] - PW / 2, PED[0] + PW / 2, PED[1] - PH / 2, PED[1] + PH / 2))
PEDB = box(PED[0] - PW / 2, PED[1] - PH / 2, PED[0] + PW / 2, PED[1] + PH / 2); PLB = box(*PLATE)
for nm, c, w, h in (("ccAS C1 LGA1700 IHS ~29x34 (est.)", CPU, 29.0, 34.0), ("ccAS C1 IHS if turned 34x29", CPU, 34.0, 29.0),
                    ("ccAS C1 rotated 180 (82.2, 73.5)", (82.2, 73.5), 29.0, 34.0), ("Size A/B CPU on (78, 73.5), 29x34", (78.0, 73.5), 29.0, 34.0)):
    ib = box(c[0] - w / 2, c[1] - h / 2, c[0] + w / 2, c[1] + h / 2)
    rep.append("  %-36s on pedestal %5.1f %%, min margin %+.1f mm" % (nm, 100 * ib.intersection(PEDB).area / ib.area,
               min(ib.bounds[0] - PEDB.bounds[0], PEDB.bounds[2] - ib.bounds[2], ib.bounds[1] - PEDB.bounds[1], PEDB.bounds[3] - ib.bounds[3])))
for nm, x0, y0, w, h in (("Size C C1", MX, MY, 160, 120), ("Size A", 17.1, 22.3, 120, 95), ("Size B", 18, 13.5, 120, 120),
                         ("C1 SO-DIMM zone x 123-153", MX + 125, MY + 4, 30, 112)):
    m = box(x0, y0, x0 + w, y0 + h)
    rep.append("  %-28s area under the black plate %5.1f %%" % (nm, 100 * m.intersection(PLB).area / m.area))
rep.append("Board polygon area %.0f mm2, bounds %s" % (BOARD.area, tuple(round(v, 2) for v in BOARD.bounds)))
for ref, f, val, side in placed:
    bb = f.GetBoundingBox(False)
    x1 = pcbnew.ToMM(bb.GetLeft()) - OX; x2 = pcbnew.ToMM(bb.GetRight()) - OX
    y2 = OY - pcbnew.ToMM(bb.GetTop()); y1 = OY - pcbnew.ToMM(bb.GetBottom())
    inside = BOARD.buffer(0.01).contains(box(x1, y1, x2, y2)) if not ref.startswith("J1") else True
    rep.append("%-5s %s x %.1f..%.1f y %.1f..%.1f %s  %s" % (ref, side, x1, x2, y1, y2, "in-board" if inside else "OUTSIDE?", val))
open(os.path.join(PRJ, "fitcheck_floorplan.txt"), "w").write("\n".join(rep) + "\n")
print("\n".join(rep))
pcbnew.SaveBoard(OUT, board)
print("saved", OUT)
