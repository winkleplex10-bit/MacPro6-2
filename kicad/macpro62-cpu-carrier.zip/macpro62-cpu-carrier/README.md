# MacPro6,2 CPU carrier (CC): KiCad 9 project, rev A floorplan fp2 (2026-10-01; fp2 = measured core CPU face, ~17:00 ET)

A COM-HPC Client carrier on the **stock CPU-riser outline**: Aidan's corrected trace, `cpu_board_outline_corrected.dxf`, layer OUTLINE_CORRECTED. The stock tab is replaced by a **Mini Cool Edge 224 card edge** (CPU-LINK) that mates the backplane J1 (Amphenol ME1022410103011).

Spec: `/workspace/macpro62-architecture-spec-v0.2.md` §6 (carrier) and §3.8 (CPU-LINK pinout).

**Carrier frame:** origin at the bottom-left of the board, x to the right (0–156), y up from the board bottom (tab tip y = 1.722). FRONT = module side = thermal-core side. On the KiCad sheet: X = 60 + x, Y = 240 − y (A3 sheet).

| File | What |
|---|---|
| `cpu_carrier.kicad_pcb` / `.kicad_pro` | Floorplan: Edge.Cuts with the new tab, 4 × D5 core-mount holes, 4 × M2.5 module holes, placeholders only (not routed). 8 layers. |
| `cpu_carrier.kicad_sch` + 6 sheets | Block-diagram stubs: module, cpu_link, power, iob_hs, m2, debug. These are hierarchical labels only, so ERC reports only dangling-label stubs. |
| `schematic_blockdiagram.pdf` | PDF of the schematic |
| `floorplan.png` / `floorplan_notes.png` | Board render; the same render with the notes legend (layer User.1) |
| `drc_report.txt` | `kicad-cli pcb drc --severity-all`: 0 violations, 0 unconnected |
| `fitcheck_floorplan.txt` | Module-size fit options (area outside the outline, CPU vs pedestal) and the bounding box of every footprint |
| `docs/cc_tab_fingers.csv` | All 224 fingers: side, layer, x on the carrier, pad level and signal |
| `docs/cpulink_224_pinout_draft.csv` | Copy of the shared CPU-LINK pin list (from the BP project) |
| `MP62_CC_Placeholders.pretty/` | Placeholders: COM-HPC plugs ASP-214802-01, the 224 fingers, core/module holes, lugs, M.2 2280, and area blocks |

**What each drawing layer shows:**
- Dwgs.User: the module (Size C at option C1), the CPU socket and package, the module SO-DIMMs, the core pedestal (**measured fp2: 40.6 × 41.1 at (78.41, 73.25), flush with the black plate**), the stock IHS (39.8 × 39.7), and the core-flange guide pins (x 28.5 / 126.4). Dwgs/Cmts also mark the module ILM / contact-frame screw positions (tips fall inside the front keep-out) and Eco1 a 54 × 71 contact-frame outline (spec §6.8). Cmts.User also carries the **black-plate height zone** (x 16.2–140.4, y 22.5–164.4): the plate is flat and flush with the pedestal, so every front part and module part under it must stay below the plate gap.
- Eco1.User: the alternatives (Size A, Size B, Size C raised as C2).
- Eco2.User: ghosts of stock features (old tab, ILM holes, ILM envelope).
- Cmts.User: keep-outs and notes.
- Rule areas:
  - TAB_FINGERS_NO_VIAS (y < 6)
  - CPU_BACKPLATE_LOAD_ZONE_F (no front parts)
  - CORE_BOSS_* (Ø12, no tracks or vias)

Rebuild:
```
python3 tools/make_placeholders.py
rm -f cpu_carrier.kicad_pcb cpu_carrier.kicad_pro cpu_carrier.kicad_prl
python3 tools/build_pcb.py
python3 tools/postprocess.py        # 8L stackup + net classes
kicad-cli pcb drc --severity-all -o drc_report.txt cpu_carrier.kicad_pcb
tools/render.sh cpu_carrier.kicad_pcb floorplan
python3 tools/build_sch.py && kicad-cli sch export pdf -o schematic_blockdiagram.pdf cpu_carrier.kicad_sch
```

**Unverified inputs:**
- The module connector, hole and CPU positions come from the Kontron ccAS user guide photo and figure, accurate to ±2 mm.
- The 8-layer dielectric values are placeholders until JLC's stack is confirmed.
- Pedestal / plate / IHS / ILM come from Aidan's two scans registered on the 4 heatsink bosses (`/workspace/bracket/core_cpu_face/`, rms 0.45 / 0.29 mm). The contact plane is 7.5 ± 0.5 mm above the stock board (Aidan). The lug positions were mirrored to the front view in fp2 (the old scan was the board back). Lug polarity, tab seating height, flange-rail height and guide-pin depth are still unmeasured.
