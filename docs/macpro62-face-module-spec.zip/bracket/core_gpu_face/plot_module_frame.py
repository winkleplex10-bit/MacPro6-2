#!/usr/bin/env python3
"""Plot the traced core GPU face in the MP62-FACE module frame, with the board outline, D5 holes and bracket eyelets."""
import json, os, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle
HERE = os.path.dirname(os.path.abspath(__file__)); d = json.load(open(os.path.join(HERE, "core_gpu_face.json")))
fig, ax = plt.subplots(figsize=(8.5, 12), dpi=150)
ax.add_patch(Polygon([(0, 13), (17, 0), (87, 0), (104, 13), (104, 166), (0, 166)], closed=True, fc="none", ec="b", lw=1.2, label="module outline 104 x 166"))
pl = d["plate"]; ax.add_patch(Rectangle((pl["x0"], pl["y0"]), pl["x1"] - pl["x0"], pl["y1"] - pl["y0"], fc="#222", ec="k", alpha=0.25, label="core black plate"))
for p in d["pads"]:
    ax.add_patch(Polygon(p["poly"], closed=True, fc="#c05621" if p["kind"] == "die" else "#f6ad55", ec="#7b341e", lw=0.8))
    ax.text(*p["centroid"], "%s\n%.1f x %.1f\n%.0f mm2" % (p["kind"], p["length"], p["width"], p["area_mm2"]), ha="center", va="center", fontsize=6)
for b in d["bosses"]:
    ax.add_patch(Circle(b["centre"], 4.5, fc="#555", ec="k", alpha=0.6)); ax.add_patch(Circle(b["centre"], b["hole_ring_d"] / 2, fc="white", ec="k", lw=0.5))
    ax.text(b["centre"][0], b["centre"][1] - 7, "boss (%.1f, %.1f)" % tuple(b["centre"]), ha="center", fontsize=6)
for (x, y) in ((15, 44.5), (89, 44.5), (15, 94.5), (89, 94.5)): ax.add_patch(Circle((x, y), 2.5, fc="none", ec="b", lw=1.0))
for sx in (-1, 1):
    for sy in (-1, 1): ax.add_patch(Circle((52 + sx * 37.15, 69.5 + sy * 24.85), 2.83, fc="none", ec="g", lw=0.8, ls="--"))
for k in ("tab", "rod", "notch"):
    ax.add_patch(Polygon(d["features"][k]["poly"], closed=True, fc="#9ca3af", ec="k", lw=0.6)); ax.text(*d["features"][k]["poly"][1], " " + k, fontsize=6)
for h in d["flange_holes"]: ax.add_patch(Circle(h["mod"], h["d_mm"] / 2, fc="none", ec="k", lw=0.6))
for xx in d["features"]["frame_step_x"]: ax.axvline(xx, color="0.4", lw=0.6, ls="-.")
ax.axhline(d["features"]["frame_edge_y_module_bottom"], color="0.4", lw=0.6, ls=":"); ax.axhline(d["features"]["frame_cutout_edge_y_module_top"], color="0.4", lw=0.6, ls=":")
p = d["boss_pattern"]
ax.set_title("Core GPU face traced from scan -> MP62-FACE module frame (core view)\nscale %.3f px/mm (%.1f dpi), +/-%.2f %%; bosses %.2f/%.2f x %.2f/%.2f mm vs board holes 74.0 x 50.0 (blue) and bracket 74.3 x 49.7 (green)"
             % (d["calibration"]["px_per_mm"], d["calibration"]["dpi_equiv"], d["calibration"]["scale_uncertainty_pct"], *p["x_spacing"], *p["y_spacing"]), fontsize=7.5)
ax.set_xlim(-12, 116); ax.set_ylim(-26, 178); ax.set_aspect("equal"); ax.grid(lw=0.2); ax.legend(fontsize=6, loc="upper left")
ax.text(52, -24, "Orientation [Inference]: scan top = module bottom (frame length matches the 166 mm board only this way). Frame step lines (dash-dot) = pocket edges.", ha="center", fontsize=6)
fig.tight_layout(); fig.savefig(os.path.join(HERE, "core_gpu_face_overlay_module_frame.png")); print("ok")
