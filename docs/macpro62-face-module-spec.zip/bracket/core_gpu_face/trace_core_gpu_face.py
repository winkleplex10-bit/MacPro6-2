#!/usr/bin/env python3
"""Calibrate and trace Aidan's flatbed scan of the GPU face of the thermal core (core_gpu_face_scan.jpeg).
Scale from the cm rulers (tick fit). Registration: the 4 screw-boss centres -> centred on (52, 69.5) of the
MP62-FACE module frame. Orientation: the scan is a true view of the core face from outside; its TOP is the module
BOTTOM (the frame/flange extents only fit the 166 mm board that way), so in the module core-view frame
X_mod = 52 + dx, Y_mod = 69.5 + dy_down (dx, dy_down in mm from the boss centroid, image axes, after de-rotation).
Writes core_gpu_face.json, core_gpu_face_module_frame.dxf, core_gpu_face_scan_frame.dxf, overlay PNGs.
Run with /workspace/cadenv/bin/python (opencv, ezdxf, matplotlib)."""
import json, math, os
import cv2, numpy as np, ezdxf
HERE = os.path.dirname(os.path.abspath(__file__))
IMG = os.path.join(HERE, "core_gpu_face_scan.jpeg")
im = cv2.imread(IMG); g = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(float)
hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV)

# ---------------- scale from rulers ----------------
def peaks(prof, thr, mind=3):
    idx = [i for i in range(1, len(prof) - 1) if prof[i] < thr and prof[i] <= prof[i - 1] and prof[i] <= prof[i + 1]]
    out = []
    for i in idx:
        if out and i - out[-1] < mind:
            if prof[i] < prof[out[-1]]: out[-1] = i
        else: out.append(i)
    return np.array(out, float)
def tickfit(pk, s0=3.95):
    k = np.round((pk - pk[0]) / s0)
    for _ in range(4):
        A = np.vstack([k, np.ones_like(k)]).T; m, c = np.linalg.lstsq(A, pk, rcond=None)[0]; k = np.round((pk - c) / m)
    return m, float(np.abs(pk - (m * k + c)).max()), int(k.max() - k.min())
p = g[976:984, 40:660].mean(axis=0); pk = peaks(p, np.percentile(p, 35)) + 40; pk = pk[(pk > 50) & (pk < 655)]
SX, resx, nx = tickfit(pk)
p = g[130:960, 664:667].mean(axis=1); pk = peaks(p, np.percentile(p, 35)) + 130
SY1, resy1, ny1 = tickfit(pk)
p = g[130:960, 780:783].mean(axis=1); pk = peaks(p, np.percentile(p, 35)) + 130
SY2, resy2, ny2 = tickfit(pk)
SY = (SY1 + SY2) / 2
S = (SX + SY) / 2
cal = dict(px_per_mm_x=round(SX, 4), px_per_mm_y=round(SY, 4), px_per_mm=round(S, 4), dpi_equiv=round(S * 25.4, 1),
           x_ticks=nx, y_ticks=[ny1, ny2], max_tick_residual_px=round(max(resx, resy1, resy2), 2),
           scale_uncertainty_pct=round(100 * abs(SX - SY) / S + 0.2, 2))

# ---------------- bosses (screw-hole rings) ----------------
def fitc(x, y):
    A = np.c_[2 * x, 2 * y, np.ones_like(x)]; c = np.linalg.lstsq(A, x * x + y * y, rcond=None)[0]
    return c[0], c[1], math.sqrt(c[2] + c[0] ** 2 + c[1] ** 2)
gb = cv2.GaussianBlur(cv2.cvtColor(im, cv2.COLOR_BGR2GRAY).astype(float), (3, 3), 0.8)
bosses = []
for (x0, y0) in ((262, 437), (551, 440), (262, 627), (551, 627)):
    t = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)[y0 - 30:y0 + 30, x0 - 30:x0 + 30]
    z = cv2.GaussianBlur(cv2.resize(t, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC), (5, 5), 1.5)
    hc = cv2.HoughCircles(z, cv2.HOUGH_GRADIENT, dp=1, minDist=200, param1=60, param2=12, minRadius=12, maxRadius=40)[0][0]
    cx, cy = x0 - 30 + hc[0] / 4, y0 - 30 + hc[1] / 4
    for _ in range(3):
        xs = np.arange(int(cx) - 9, int(cx) + 10); ys = np.arange(int(cy) - 9, int(cy) + 10)
        X, Y = np.meshgrid(xs, ys); T = gb[Y, X]; m = np.hypot(X - cx, Y - cy) < 8
        sel = m & (np.hypot(X - cx, Y - cy) > 2.5) & (T > np.percentile(T[m], 70))
        cx, cy, r = fitc(X[sel].astype(float), Y[sel].astype(float))
    bosses.append([cx, cy, r])
B = np.array(bosses)       # TL, TR, BL, BR in the image
c0 = B[:, :2].mean(axis=0)
ang = np.mean([math.atan2(B[1, 1] - B[0, 1], B[1, 0] - B[0, 0]), math.atan2(B[3, 1] - B[2, 1], B[3, 0] - B[2, 0]),
               math.atan2(B[0, 0] - B[2, 0], B[2, 1] - B[0, 1]), math.atan2(B[1, 0] - B[3, 0], B[3, 1] - B[1, 1])])
ca, sa = math.cos(-ang), math.sin(-ang)
def to_scan_mm(px, py):        # de-rotated, origin at boss centroid, image axes (x right, y down), mm
    dx, dy = px - c0[0], py - c0[1]
    return ((dx * ca - dy * sa) / SX, (dx * sa + dy * ca) / SY)
def to_mod(px, py):
    dx, dy = to_scan_mm(px, py)
    return (round(float(52.0 + dx), 3), round(float(69.5 + dy), 3))

# ---------------- copper pads ----------------
H, Sat, V = cv2.split(hsv)
cu = ((H < 25) & (Sat > 55) & (V > 80)).astype(np.uint8) * 255
cu = cv2.morphologyEx(cu, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8)); cu = cv2.morphologyEx(cu, cv2.MORPH_CLOSE, np.ones((7, 7), np.uint8))
n, lab, st, cen = cv2.connectedComponentsWithStats(cu)
pads = []
for i in range(1, n):
    if st[i, 4] < 3000: continue
    cnt, _ = cv2.findContours((lab == i).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    c = max(cnt, key=cv2.contourArea)
    poly = cv2.approxPolyDP(c, 1.2, True)[:, 0, :]
    (rx, ry), (rw, rh), ra = cv2.minAreaRect(c)
    area_mm2 = cv2.contourArea(c) / (SX * SY)
    pmod = [to_mod(float(x), float(y)) for x, y in poly]
    cmx, cmy = to_mod(cen[i][0], cen[i][1])
    L, W = max(rw, rh) / S, min(rw, rh) / S
    pads.append(dict(kind="die" if 0.7 < rw / rh < 1.4 else "strip", centroid=(cmx, cmy), length=round(L, 2), width=round(W, 2),
                     rect_angle_img=round(ra, 1), area_mm2=round(area_mm2, 1), poly=pmod, contour_px=c[:, 0, :].tolist()))
# boss clearance radius: fit circles to copper contour points near each boss
for b in bosses:
    pts = []
    for pd in pads:
        cp = np.array(pd["contour_px"], float); d = np.hypot(cp[:, 0] - b[0], cp[:, 1] - b[1])
        pts += cp[(d < 34) & (d > 8)].tolist()
    if len(pts) > 15:
        pts = np.array(pts); _, _, r = fitc(pts[:, 0], pts[:, 1]); b.append(r)
    else: b.append(float("nan"))

# ---------------- plate / frame / features from edge profiles ----------------
def edge(prof, i0, rising):
    d = np.diff(prof); j = int(np.argmax(d) if rising else np.argmin(d)); return i0 + j + 0.5
row = g[550:650, :].mean(axis=0); col = g[:, 300:500].mean(axis=1)
plate_l = edge(row[225:255], 225, False); plate_r = edge(row[585:605], 585, True)
plate_t = edge(col[295:315], 295, False); plate_b = edge(col[852:872], 852, True)
step_l = 150 + np.argmin(row[195:212]) + 45; step_r = 620 + np.argmin(row[620:640])
outer_l = edge(row[170:195], 170, False); outer_r = edge(row[650:665], 650, True)
frame_t = edge(col[270:295], 270, False); frame_cut = edge(col[872:895], 872, True)
plate_px = dict(l=plate_l, r=plate_r, t=plate_t, b=plate_b)
corners = [to_mod(plate_l, plate_t), to_mod(plate_r, plate_t), to_mod(plate_r, plate_b), to_mod(plate_l, plate_b)]
xs = sorted([p[0] for p in corners]); ys = sorted([p[1] for p in corners])
plate = dict(x0=round(xs[1], 2), x1=round(xs[2], 2), y0=round(ys[1], 2), y1=round(ys[2], 2), corner_r_est=8.0)
# flange corner holes (small dark/bright rings at the frame corners)
holes = []
for (x0, y0) in ((192, 278), (645, 282), (185, 945), (640, 948)):
    t = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)[y0 - 20:y0 + 20, x0 - 20:x0 + 20]
    z = cv2.GaussianBlur(cv2.resize(t, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC), (5, 5), 1.5)
    hc = cv2.HoughCircles(z, cv2.HOUGH_GRADIENT, dp=1, minDist=200, param1=50, param2=10, minRadius=6, maxRadius=30)
    if hc is not None:
        hx, hy, hr = hc[0][0]; holes.append(dict(px=(x0 - 20 + hx / 4, y0 - 20 + hy / 4), mod=to_mod(x0 - 20 + hx / 4, y0 - 20 + hy / 4), d_mm=round(2 * hr / 4 / S, 2)))
feat = dict(
    tab=dict(desc="small light tab (lower right of the scan); identity TO MEASURE (bus-bar contact? spring?)",
             poly=[to_mod(x, y) for x, y in ((600, 760), (616, 760), (616, 815), (600, 815))]),
    rod=dict(desc="round rod/pin sticking out past the frame edge toward the base board; identity TO MEASURE",
             poly=[to_mod(x, y) for x, y in ((548, 180), (562, 180), (562, 232), (548, 232))]),
    notch=dict(desc="notch / rib in the black plate rim at the module-bottom end", poly=[to_mod(x, y) for x, y in ((405, 303), (425, 303), (425, 316), (405, 316))]),
    frame_step_x=(to_mod(step_l, 600)[0], to_mod(step_r, 600)[0]),
    frame_outer_x=(to_mod(outer_l, 600)[0], to_mod(outer_r, 600)[0]),
    frame_edge_y_module_bottom=to_mod(400, frame_t)[1],
    frame_cutout_edge_y_module_top=to_mod(400, frame_cut)[1],
)
Bmod = [dict(centre=to_mod(b[0], b[1]), hole_ring_d=round(2 * b[2] / S, 2), pad_cutout_r=round(b[3] / S, 2)) for b in bosses]
bc = [b["centre"] for b in Bmod]
pat = dict(x_spacing=[round(bc[1][0] - bc[0][0], 2), round(bc[3][0] - bc[2][0], 2)],
           y_spacing=[round(bc[2][1] - bc[0][1], 2), round(bc[3][1] - bc[1][1], 2)], rotation_deg_corrected=round(math.degrees(ang), 3))
out = dict(source=os.path.basename(IMG), calibration=cal, frame_note=__doc__.split("Orientation:")[1].split("Writes")[0].strip(),
           bosses=Bmod, boss_pattern=pat, pads=[{k: v for k, v in p.items() if k != "contour_px"} for p in pads],
           plate=plate, flange_holes=holes, features=feat)
json.dump(out, open(os.path.join(HERE, "core_gpu_face.json"), "w"), indent=1, default=float)

# ---------------- DXF (module frame + scan frame) ----------------
def dxf(path, conv, title):
    doc = ezdxf.new("R2010", setup=True); doc.header["$INSUNITS"] = 4; msp = doc.modelspace()
    for n_, c_ in (("CORE_DIE_PAD", 1), ("CORE_STRIP_PADS", 30), ("CORE_BOSSES", 5), ("CORE_BOSS_HOLES", 5), ("CORE_PLATE", 8),
                   ("CORE_FRAME", 9), ("CORE_FEATURES", 2), ("BOARD_REF", 7), ("NOTES", 7)):
        doc.layers.add(n_, color=c_)
    for p_ in pads:
        msp.add_lwpolyline([conv(*q) for q in p_["poly"]], close=True, dxfattribs={"layer": "CORE_DIE_PAD" if p_["kind"] == "die" else "CORE_STRIP_PADS"})
    for b_ in Bmod:
        msp.add_circle(conv(*b_["centre"]), b_["hole_ring_d"] / 2, dxfattribs={"layer": "CORE_BOSS_HOLES"})
        if not math.isnan(b_["pad_cutout_r"]): msp.add_circle(conv(*b_["centre"]), b_["pad_cutout_r"], dxfattribs={"layer": "CORE_BOSSES"})
    pl = plate
    msp.add_lwpolyline([conv(pl["x0"], pl["y0"]), conv(pl["x1"], pl["y0"]), conv(pl["x1"], pl["y1"]), conv(pl["x0"], pl["y1"])], close=True, dxfattribs={"layer": "CORE_PLATE"})
    for h_ in holes: msp.add_circle(conv(*h_["mod"]), h_["d_mm"] / 2, dxfattribs={"layer": "CORE_FRAME"})
    for xx in feat["frame_step_x"]: msp.add_line(conv(xx, 0), conv(xx, 166), dxfattribs={"layer": "CORE_FRAME"})
    for k_ in ("tab", "rod", "notch"): msp.add_lwpolyline([conv(*q) for q in feat[k_]["poly"]], close=True, dxfattribs={"layer": "CORE_FEATURES"})
    for (x_, y_) in ((15, 44.5), (89, 44.5), (15, 94.5), (89, 94.5)): msp.add_circle(conv(x_, y_), 2.5, dxfattribs={"layer": "BOARD_REF"})
    msp.add_lwpolyline([conv(0, 13), conv(17, 0), conv(87, 0), conv(104, 13), conv(104, 166), conv(0, 166)], close=True, dxfattribs={"layer": "BOARD_REF"})
    msp.add_text(title, height=2, dxfattribs={"layer": "NOTES"}).set_placement(conv(0, -8))
    doc.saveas(path)
dxf(os.path.join(HERE, "core_gpu_face_module_frame.dxf"), lambda x, y: (x, y),
    "Core GPU face, traced from scan, MP62-FACE module frame (core view, origin board bottom-left, mm). Scale +/-0.4%, features +/-0.5 mm")
dxf(os.path.join(HERE, "core_gpu_face_scan_frame.dxf"), lambda x, y: (x - 52.0, -(y - 69.5)),
    "Core GPU face, scan frame: origin boss centroid, x right, y up AS SCANNED (scan top = module bottom), mm")

# ---------------- overlay on the scan ----------------
ov = im.copy()
for p_ in pads: cv2.polylines(ov, [np.array(p_["contour_px"], np.int32)], True, (0, 255, 0) if p_["kind"] == "strip" else (0, 0, 255), 2)
for b_ in bosses:
    cv2.circle(ov, (int(round(b_[0])), int(round(b_[1]))), int(round(b_[2])), (255, 255, 0), 1)
    if not math.isnan(b_[3]): cv2.circle(ov, (int(round(b_[0])), int(round(b_[1]))), int(round(b_[3])), (255, 0, 255), 1)
cv2.rectangle(ov, (int(plate_l), int(plate_t)), (int(plate_r), int(plate_b)), (0, 200, 255), 1)
for xx in (step_l, step_r): cv2.line(ov, (int(xx), 270), (int(xx), 950), (255, 128, 0), 1)
for h_ in holes: cv2.circle(ov, tuple(int(v) for v in h_["px"]), 6, (255, 0, 0), 1)
# board outline + holes projected back into the scan
def mod_to_px(X, Y):
    dx, dy = (X - 52.0) * SX, (Y - 69.5) * SY
    return (int(round(c0[0] + dx * math.cos(ang) - dy * math.sin(ang))), int(round(c0[1] + dx * math.sin(ang) + dy * math.cos(ang))))
bo = [mod_to_px(*q) for q in ((0, 13), (17, 0), (87, 0), (104, 13), (104, 166), (0, 166))]
cv2.polylines(ov, [np.array(bo, np.int32)], True, (255, 0, 0), 1)
for (x_, y_) in ((15, 44.5), (89, 44.5), (15, 94.5), (89, 94.5)): cv2.circle(ov, mod_to_px(x_, y_), int(2.5 * S), (255, 0, 0), 1)
cv2.putText(ov, "blue: 104x166 module outline + D5 holes (74x50) registered on the bosses; scan top = module BOTTOM", (20, 30), 0, 0.5, (255, 0, 0), 1)
cv2.putText(ov, "green: strip pads  red: die pad  magenta: pad cut-out arcs around bosses  cyan: boss hole rings", (20, 52), 0, 0.5, (0, 120, 0), 1)
cv2.imwrite(os.path.join(HERE, "core_gpu_face_overlay_scan.png"), ov)
print(json.dumps(dict(cal=cal, bosses=Bmod, pattern=pat, plate=plate, holes=holes,
                      pads=[(p["kind"], p["centroid"], p["length"], p["width"], p["area_mm2"]) for p in pads],
                      frame=dict((k, v) for k, v in feat.items() if not isinstance(v, dict))), indent=1, default=float))
