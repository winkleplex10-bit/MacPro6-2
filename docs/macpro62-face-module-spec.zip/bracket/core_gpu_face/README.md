# Core GPU face: calibrated scan trace

Input: `core_gpu_face_scan.jpeg` (Aidan's flatbed scan of the thermal core's GPU face with rulers, 1133 × 1334 px).

Run: `python trace_core_gpu_face.py` (needs numpy, opencv-python-headless, ezdxf, matplotlib), then `python plot_module_frame.py`.

| Output | Content |
|---|---|
| `core_gpu_face.json` | Calibration, bosses, die pad, strip pads, plate, frame, flange holes, tab/rod/notch, in the scan frame and the MP62 module frame |
| `core_gpu_face_module_frame.dxf` | Traced features in the MP62-FACE module frame (mm, core view) |
| `core_gpu_face_scan_frame.dxf` | Same features in scan millimetres (unrotated) |
| `core_gpu_face_overlay_scan.png` | Trace drawn over the scan (QA) |
| `core_gpu_face_overlay_module_frame.png` | Trace with the module outline, Ø5 holes and bracket eyelets |
| `work/` | Intermediate crops and masks |

- **Calibration:** 3.9504 px/mm in X and 3.943 px/mm in Y, from the rulers (≈ 100 dpi). Scale ±0.4 %, features ±0.5 mm.
- **Orientation [Inference]:** scan top = module bottom. The mapping applies a 0.58° de-rotation, then X_mod = 52 + dx, Y_mod = 69.5 + dy_down, where dx/dy are measured from the boss centroid.
- **Key results:**
  - Boss pattern 75.2 × 50.0 mm, against board holes at 74.0 × 50.0.
  - Die pad 23.6 × 21.7 mm at (51.85, 69.43).
  - 4 strip pads of ≈ 41 × 15 mm at 45°.
  - Plate X 7.5–95.5, Y 8.6–149.5.
- **Measured (Aidan):** standoff height 4.5 ± 0.5 mm.
