#!/usr/bin/env python3
"""Build the MP62-FACE v0.1 KiCad template board (KiCad 9 pcbnew API, system python3).
Geometry comes from tools/face_geom.json (copy of /workspace/macpro62-face/tools/face_geom.json).
MP62-FACE frame: origin bottom-left, +X right, +Y up, viewed from the CORE side = KiCad top (F).
KiCad position = (OX + X, OY - Y). The grid/aux origin is set to the MP62 origin."""
import json, math, os, sys
import pcbnew
from pcbnew import FromMM, VECTOR2I
HERE = os.path.dirname(os.path.abspath(__file__))
PRJ = os.path.abspath(os.path.join(HERE, ".."))
OUT = os.path.join(PRJ, "macpro62-face-template.kicad_pcb")
LIB = os.path.join(PRJ, "MP62_Face.pretty")
g = json.load(open(os.path.join(HERE, "face_geom.json")))
OX, OY = 60.0, 190.0
def P(x, y): return VECTOR2I(FromMM(OX + x), FromMM(OY - y))

board = pcbnew.NewBoard(OUT)
board.SetCopperLayerCount(6)
ds = board.GetDesignSettings()
ds.SetBoardThickness(FromMM(1.6))
ds.m_TrackMinWidth = FromMM(0.127); ds.m_MinClearance = FromMM(0.127)
ds.m_ViasMinSize = FromMM(0.45); ds.m_MinThroughDrill = FromMM(0.3)
ds.m_CopperEdgeClearance = FromMM(0.5); ds.m_HoleClearance = FromMM(0.25); ds.m_HoleToHoleMin = FromMM(0.5)
ds.m_SilkClearance = FromMM(0.0)
ds.SetAuxOrigin(P(0, 0)); ds.SetGridOrigin(P(0, 0))
tb = board.GetTitleBlock()
tb.SetTitle("MP62-FACE Module template - Face Module Spec v0.1")
tb.SetRevision("v0.1-template"); tb.SetDate("2026-10-01"); tb.SetCompany("MacPro6,2 / Aidan Winkler (open spec)")
tb.SetComment(0, "Frame: origin = aux/grid origin = outline bottom-left, viewed from the CORE side (F = core side, B = outer side)")
tb.SetComment(1, "Stackup default JLC06161H-2116 6L 1.6 mm (GPU modules will need 8-10L: change stackup, keep outline/holes/keep-outs)")
tb.SetComment(2, "Connectors on B (outer): J_PCIE MCIO 124 RA, J_DISP MCIO 74 RA, J_AUX GH15 RA, opt. J_12V_ALT PCIe 8-pin. 12V lugs = stock bus bar")
tb.SetComment(3, "PROVISIONAL: keep-outs/heights marked TO MEASURE in the spec (D3, M1, M4, M5)")

def shape_seg(x1, y1, x2, y2, layer, w=0.1):
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_SEGMENT)
    s.SetStart(P(x1, y1)); s.SetEnd(P(x2, y2)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def shape_arc(cx, cy, r, a0, a1, layer, w=0.1):
    if a1 < a0: a1 += 360
    am = (a0 + a1) / 2
    pt = lambda a: P(cx + r * math.cos(math.radians(a)), cy + r * math.sin(math.radians(a)))
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_ARC)
    s.SetArcGeometry(pt(a0), pt(am), pt(a1)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def shape_circle(x, y, r, layer, w=0.1):
    s = pcbnew.PCB_SHAPE(board); s.SetShape(pcbnew.SHAPE_T_CIRCLE)
    s.SetCenter(P(x, y)); s.SetEnd(P(x + r, y)); s.SetLayer(layer); s.SetWidth(FromMM(w)); board.Add(s)
def shape_rect(r, layer, w=0.1):
    x1, y1, x2, y2 = r
    for a, b in (((x1, y1), (x2, y1)), ((x2, y1), (x2, y2)), ((x2, y2), (x1, y2)), ((x1, y2), (x1, y1))):
        shape_seg(*a, *b, layer, w)
def shape_poly(pts, layer, w=0.1):
    for i in range(len(pts)):
        shape_seg(*pts[i], *pts[(i + 1) % len(pts)], layer, w)
def txt(s, x, y, layer=pcbnew.Cmts_User, size=1.0, angle=0.0, mirror=False):
    t = pcbnew.PCB_TEXT(board); t.SetText(s); t.SetPosition(P(x, y)); t.SetLayer(layer)
    t.SetTextSize(VECTOR2I(FromMM(size), FromMM(size))); t.SetTextThickness(FromMM(size * 0.15))
    t.SetTextAngleDegrees(angle); t.SetMirrored(mirror); board.Add(t)

# ---------- Edge.Cuts ----------
for s in g["outline"]:
    if s[0] == "L": shape_seg(s[1], s[2], s[3], s[4], pcbnew.Edge_Cuts, 0.05)
    else: shape_arc(s[1], s[2], s[3], s[4], s[5], pcbnew.Edge_Cuts, 0.05)

# ---------- footprints ----------
nets = {}
def net(name):
    if name not in nets:
        n = pcbnew.NETINFO_ITEM(board, name); board.Add(n); nets[name] = n
    return nets[name]
def place(ref, name, x, y, rot=0.0, side="F", value=None, centre_bbox=False, netmap=None, dnp=False):
    f = pcbnew.FootprintLoad(LIB, name)
    if f is None: sys.exit("missing " + name)
    f.SetFPID(pcbnew.LIB_ID("MP62_Face", name)); f.SetReference(ref); f.SetValue(value or name)
    f.SetPosition(P(x, y)); f.SetOrientationDegrees(rot)
    board.Add(f)
    if side == "B": f.Flip(f.GetPosition(), pcbnew.FLIP_DIRECTION_LEFT_RIGHT)
    if centre_bbox:
        cy = f.GetCourtyard(pcbnew.B_CrtYd if side == "B" else pcbnew.F_CrtYd).BBox()
        c = cy.GetCenter(); t = P(x, y); f.Move(VECTOR2I(t.x - c.x, t.y - c.y))
    if netmap:
        for p in f.Pads():
            if p.GetNumber() in netmap: p.SetNet(net(netmap[p.GetNumber()]))
    if dnp:
        f.SetDNP(True); f.SetExcludedFromBOM(True)
    f.Reference().SetVisible(True)
    f.Reference().SetLayer(pcbnew.B_Fab if side == "B" else pcbnew.F_Fab)
    return f
for i, (x, y) in enumerate(g["holes"]):
    place("H%d" % (i + 1), "MP62_FACE_MountHole_D5.0_Pad9.0", x, y, value="MOUNT D5.0 (bracket screw)")
for (x, y), ref, n, site in zip(g["LUGS"], g["LUG_REFS"], g["LUG_NETS"], g["LUG_SITE"]):
    place(ref, "MP62_FACE_BusBarLug_D3.2_Pad8.8", x, y, value="BUSBAR LUG site %s %s (polarity TO MEASURE)" % (site, n), netmap={"1": n})
# reference parallel connection of lug sites A and B (inner layers; reroute/replace with pours as needed)
def track(pts, layer, w, netname):
    for (x1, y1), (x2, y2) in zip(pts[:-1], pts[1:]):
        t = pcbnew.PCB_TRACK(board); t.SetStart(P(x1, y1)); t.SetEnd(P(x2, y2)); t.SetLayer(layer)
        t.SetWidth(FromMM(w)); t.SetNet(net(netname)); board.Add(t)
(a12, agnd), (b12, bgnd) = g["LUGS_A"], g["LUGS_B"]
track([a12, (a12[0], 140.0), (b12[0], 140.0), b12], pcbnew.In1_Cu, 3.0, "+12V_IN")
track([agnd, (agnd[0], 163.4), (bgnd[0], 163.4), bgnd], pcbnew.In4_Cu, 2.0, "GND")
jp, jd = g["J"]["J_PCIE"], g["J"]["J_DISP"]
fp = place("J1", "MP62_MCIO_124P_RA_SFF-TA-1016", jp["cx"], g["Y_MATE"] + 6.025, rot=180, side="B", value="J_PCIE MCIO124 RA G97R24332HR")
fd = place("J2", "MP62_MCIO_74P_RA_SFF-TA-1016", jd["cx"], g["Y_MATE"] + 6.025, rot=180, side="B", value="J_DISP MCIO74 RA G97R22332HR")
a = g["AUX"]
fa = place("J3", "JST_GH_SM15B-GHS-TB_1x15-1MP_P1.25mm_Horizontal", a["cx"], a["cy"], rot=90, side="B", value="J_AUX GH15 RA SM15B-GHS-TB", centre_bbox=True)
p8 = g["P8"]
f8 = place("J4", "Molex_Mini-Fit_Jr_5569-08A2_2x04_P4.20mm_Horizontal", p8["cx"], p8["cy"], rot=0, side="B", value="J_12V_ALT PCIe8 RA 45586-0005 (DNP)", centre_bbox=True, dnp=True)
# ICD rev 2 / face spec 6.8 (live power target): reference 12 V power monitor in the eFuse zone (X 40-64, Y 125-145), outer
# side. INA228 @0x40 on FACE_SMB (A0 = A1 = GND), ALERT wired-OR onto FACE_SMB_ALERT#; Kelvin shunt between the parallel lug
# sites and the eFuse. Reference placement only (DNP, no nets): every module > 3 W SHALL carry an equivalent monitor.
place("RS1", "R_2512_6332Metric", 46.0, 131.0, rot=0, side="B", value="REF: 12 V shunt 1 mOhm (Face P) / 2 mOhm (<= 5 A) 2512 Kelvin", dnp=True)
place("U5", "VSSOP-10_3x3mm_P0.5mm", 54.0, 131.0, rot=0, side="B", value="REF: INA228 @0x40 FACE_SMB, ALERT -> FACE_SMB_ALERT#", dnp=True)

# orientation checks (board frame)
def bf(v): return (pcbnew.ToMM(v.x) - OX, OY - pcbnew.ToMM(v.y))
def padpos(f, num): return bf([p for p in f.Pads() if p.GetNumber() == num][0].GetPosition())
chk = []
fy = bf(fp.GetPosition())[1]
chk.append(("J_PCIE pad rows above datum (rows away from mating face, mating face toward -Y)", padpos(fp, "A1")[1] > fy and padpos(fp, "B1")[1] > padpos(fp, "A1")[1]))
mp = [bf(p.GetPosition()) for p in fa.Pads() if p.GetNumber() == "MP"]
sig = padpos(fa, "1")
chk.append(("J_AUX opening toward -X (MP pads at the front, signal pads at the back)", all(m[0] < sig[0] for m in mp)))
pins = [bf(p.GetPosition()) for p in f8.Pads() if p.GetNumber() in ("1", "5")]
pegs = [bf(p.GetPosition()) for p in f8.Pads() if p.GetNumber() == ""]
chk.append(("J_12V_ALT opening toward +Y (pegs above pins)", all(pg[1] > max(q[1] for q in pins) for pg in pegs)))
for c, ok in chk: print(("OK  " if ok else "FAIL"), c)

# ---------- rule areas ----------
def rule_area(name, layer, polyset, fp_=True, pads=True, vias=False, tracks=False, pour=False):
    z = pcbnew.ZONE(board); z.SetIsRuleArea(True); z.SetZoneName(name)
    z.SetDoNotAllowFootprints(fp_); z.SetDoNotAllowPads(pads); z.SetDoNotAllowVias(vias)
    z.SetDoNotAllowTracks(tracks); z.SetDoNotAllowCopperPour(pour)
    ls = pcbnew.LSET(); ls.AddLayer(layer); z.SetLayerSet(ls); z.SetOutline(polyset); board.Add(z); return z
def ps_poly(pts):
    s = pcbnew.SHAPE_POLY_SET(); s.NewOutline()
    for x, y in pts:
        v = P(x, y); s.Append(v.x, v.y)
    return s
def ps_circle(x, y, r, n=48): return ps_poly([(x + r * math.cos(2 * math.pi * i / n), y + r * math.sin(2 * math.pi * i / n)) for i in range(n)])
def ps_rect(r): return ps_poly([(r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3])])
bko = ps_poly(g["bracket_ko"])
for (x, y) in g["holes"]: bko.BooleanSubtract(ps_circle(x, y, 6.25))
bko.BooleanSubtract(ps_circle(g["DIE"][0], g["DIE"][1], g["ring_void_d"] / 2))
bko.Simplify()
rule_area("KO-B1_BRACKET_no_parts", pcbnew.B_Cu, bko)
# KO-F3 (MEG-Array bosses) released in v0.1: the core scan shows no bosses there.
keep = []  # keep Python references: ZONE.SetOutline does not take ownership (segfault on save otherwise)
for tag, r in zip(("A", "B"), g["LUG_KOS"]):
    lko = ps_rect(r)
    lko.BooleanIntersection(ps_poly(g["outline_poly"]))
    for (x, y) in g["LUGS"]: lko.BooleanSubtract(ps_circle(x, y, 5.2))
    lko.Simplify(); keep.append(lko)
    rule_area("KO-F2%s_BUSBAR_TONGUE_no_parts" % tag, pcbnew.F_Cu, lko)
for tag, r in (("A", g["TAB_KO"]), ("B", g["TAB_KO_B"])):
    tab_ps = ps_rect(r); keep.append(tab_ps)
    rule_area("KO-F5%s_CORE_TAB_no_parts" % tag, pcbnew.F_Cu, tab_ps)

# ---------- documentation layers ----------
U1, U2, U3 = pcbnew.User_1, pcbnew.User_2, pcbnew.User_3
board.SetLayerName(U1, "User.1"); 
shape_poly(g["DIE_PAD"], U1, 0.15); shape_rect(g["TZ1"], U1, 0.08)
txt("DIE PAD (core copper, scan): die/shim + TIM contact, stack = G - p + 0.05..0.2", 52, 84.5, U1, 0.8)
for sp in g["STRIPS"]: shape_poly(sp, U1, 0.12)
txt("STRIP PADS: VRAM / power stages, top (+spreader) = G - p - t_pad (0.5-2.0)", 52, 112, U1, 0.8)
pl = g["PLATE"]; shape_rect((pl["x0"], pl["y0"], pl["x1"], pl["y1"]), U1, 0.08)
txt("core black plate: outside it F parts <= 1.0 mm (provisional)", 52, pl["y1"] - 2, U1, 0.8)
for (x, y) in g["CORE_BOSSES"]: shape_circle(x, y, g["CORE_BOSS_D"] / 2, U1, 0.08)
txt("F parts <= 3.5 mm (gap G 4.5 +/-0.5 = core standoffs); over pads non-contact parts <= 3.0", 52, 20, U1, 0.8)
txt("hot-spot centroid within R3 of (52.0, 69.5)", 52, 62.5, U1, 0.8)
for a_, b_, h_ in g["HZ"]:
    for x0, x1 in ((52 + a_, 52 + b_), (52 - b_, 52 - a_)):
        shape_seg(x0, 0, x0, 166, U2, 0.05)
        txt("B<=%g" % h_, (x0 + x1) / 2, 163.5 - 3 * (g["HZ"].index([a_, b_, h_]) % 2), U2, 0.9, mirror=False)
txt("User.2: outer-side (B) simplified height zones, mm above outer surface (TO MEASURE M1)", 52, 133, U2, 1.0)
shape_rect(g["CONN_BAND"], U3, 0.1); txt("User.3: outer-side connector band Y 0-26 (cables exit -Y under the bottom edge)", 52, 28.5, U3, 0.9)
shape_circle(g["DIE"][0], g["DIE"][1], g["ring_void_d"] / 2, U3, 0.1); txt("KO-B1v ring interior: B parts <= 1.0 mm TBC", 52, 56, U3, 0.8)
shape_poly(g["bracket_ref"], pcbnew.Dwgs_User, 0.08)
for (x, y) in g["bracket_holes"]: shape_circle(x, y, 5.66 / 2, pcbnew.Dwgs_User, 0.08)
txt("Dwgs.User: stock X-bracket (outer side) + D5.66 eyelets on 74.3 x 49.7", 52, 104, pcbnew.Dwgs_User, 0.9)
notes = ["MP62-FACE v0.1 TEMPLATE. Origin (aux/grid) = outline bottom-left. Viewed from the CORE side.",
         "F = core side: gap G = 4.5 +/- 0.5 (standoffs). Parts <= 3.5 mm; pads per User.1; outside plate <= 1.0. Edge band 1.0 mm.",
         "B = outer side: connectors + bracket. Height envelope h(x) = sqrt(80^2-(x-52)^2) - 57.6 (est., M1).",
         "Rule areas: KO-B1 (bracket), KO-F2A/B (bus-bar tongues), KO-F5A/B (core tab + mirror). Holes: KO-F1 D11 / KO-B2 D12 = H1-H4 courtyards.",
         "Bus-bar lugs: site A J20/J21 (X~97) + mirrored site B J22/J23 (X~7), BOTH fitted, wired in parallel (In1 12V / In4 GND reference tracks).",
         "Stock GPU 2 is mirrored: its bus bar lands on the other site. Polarity per face TO MEASURE (M5). J4 optional PCIe 8-pin: one 12 V source only."]
for i, s in enumerate(notes): txt(s, 52, -6 - 2.2 * i, pcbnew.Cmts_User, 1.0)
txt("MP62-FACE v0.1", 52, 120, pcbnew.F_SilkS, 1.5)
pcbnew.SaveBoard(OUT, board)
print("saved", OUT, "ALL CHECKS OK" if all(ok for _, ok in chk) else "CHECK FAIL")
