# MP62-FACE v0.1 KiCad 9 template

This is the starting board for a MacPro6,2 face module. Spec: `macpro62-face-module-spec-v0.1.md`. Licence (proposal): CERN-OHL-P-2.0.

## Frame
- MP62 module frame: origin at the outline's bottom-left, **viewed from the core side**.
- In KiCad the board is placed at (60, 190), so a spec point (X, Y) sits at KiCad (60 + X, 190 − Y). The aux and grid origins are set at the module origin, so coordinates read relative to the grid origin match the spec directly.
- **F = core side** (toward the thermal core). **B = outer side** (connectors, bracket, enclosure shell).

## Layers
| Layer | Content |
|---|---|
| Edge.Cuts | 104 × 166 outline (chamfers + R10 blends, R5 top corners) |
| F.Cu / B.Cu rule areas | **KO-B1** bracket (B, footprints/pads not allowed); **KO-F2A/KO-F2B** bus-bar tongues at both lug sites (F); **KO-F5A/KO-F5B** core tab and its mirror (F) |
| H1–H4 footprints | Ø5.0 PTH, Ø9 pad. The F courtyard is Ø11 (KO-F1 core boss) and the B courtyard Ø12 (KO-B2 screw/spring) |
| User.1 | Core contact zones from the core scan: die pad + TZ1, 4 strip pads, plate outline, bosses, height notes (G = 4.5 ± 0.5; F parts ≤ 3.5 mm; ≤ 3.0 under strips; ≤ 1.0 outside the plate) |
| User.2 | Outer-side simplified height zones (19/14/10/7/3 mm) |
| User.3 | Connector band Y 0–26 |
| Dwgs.User | Stock X-bracket outline |
| Cmts.User | Notes |

Placeholders on B:
- J1: MCIO 124 RA at X 47.0 (ICD O-10; courtyard sized for the NARROW cable plug, 42.15 mm)
- J2: MCIO 74 RA at X 82.5 (narrow plug 25.95 mm; 0.22 mm courtyard gap to J1, plug bodies 1.3 mm apart)
- J3: GH15 RA
- J4: optional PCIe 8-pin (DNP)
- J20/J21 (site A, X ≈ 97) and J22/J23 (site B, mirror, X ≈ 7): bus-bar lug sites. Both are fitted on every module, because the stock GPU 2 board is mirrored and its bus bar lands on the other side (spec §6.4.1). Nets: J20/J22 = +12V_IN, J21/J23 = GND (polarity TO MEASURE, M5).
- Reference tracks wire the two sites in parallel: In1.Cu 3 mm at Y 140 (+12V_IN) and In4.Cu 2 mm at Y 163.4 (GND). Replace them with ≥ 10 mm pours to the eFuse.

The stackup is JLC06161H-2116 (6 layers, 1.6 mm). Netclasses: PCIE_85R, DISP_100R, REFCLK_85R, USB2_90R, PWR_12V.

## Rebuild
```
python3 tools/make_footprints.py
python3 tools/build_template.py          # needs KiCad 9 pcbnew python
cp <backplane>.kicad_pro macpro62-face-template.kicad_pro   # or keep the shipped .kicad_pro
python3 tools/postprocess.py
kicad-cli pcb drc --severity-all -o drc_report.txt macpro62-face-template.kicad_pcb
```
`tools/face_geom.json` is a copy of `macpro62-face/tools/face_geom.json`, the single geometry source. Re-copy it after any change.

## Status
- **ICD rev 3 / O-10 (2026-10-04 ≈ 09:10 ET, Aidan approved):** J1 X 43.5 → **47.0** (+3.5 mm), J2 X 82.0 → **82.5** (+0.5 mm), narrow plugs (footprint courtyard 124P ±21.6 / 74P ±13.6, was ±23.25 / ±14.5). BP fp6 lands J_PCIE at s = +5.0 = X 47.0, zero cable jog. Only the 6 lug reference tracks are routed (unaffected). DRC 0 violations / 0 unconnected / 0 footprint errors. `template_render.png` regenerated.
- **ICD rev 2 (2026-10-02):** reference **RS1** (2512 Kelvin shunt: 1 mΩ for Face P, 2 mΩ up to 5 A) + **U5 INA228** (VSSOP-10, SMBus 0x40) on the B side at (46, 131) / (54, 131), no nets, DNP-style reference for face spec §6.8 (12 V power monitor mandatory > 3 W). DRC 0/0.
- DRC (2026-10-01, 17:43 ET, after the dual-lug update): 0 violations, 0 unconnected.
- A test showed the KO-F5 and hole courtyards catch misplaced parts.
- The pad-row side of the MCIO footprints is **assumed** (OQ-5). Keep-outs marked TO MEASURE in the spec are provisional.
