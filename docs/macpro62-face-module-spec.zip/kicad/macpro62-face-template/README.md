# MP62-FACE v0.1 KiCad 9 template

This is the starting board for a MacPro6,2 face module. Spec: `macpro62-face-module-spec-v0.1.md`. Licence (proposal): CERN-OHL-P-2.0.

## Frame
- MP62 module frame: origin at the outline's bottom-left, **viewed from the core side**.
- In KiCad the board is placed at (60, 190), so a spec point (X, Y) sits at KiCad (60 + X, 190 − Y). The aux and grid origins are set at the module origin, so coordinates read relative to the grid origin match the spec directly.
- **F = core side** (toward the thermal core). **B = outer side** (connectors, bracket, enclosure shell).

## Layers
| Layer | Content |
|---|---|
| Edge.Cuts | 104 × 166 outline (chamfers + R10 blends, R5 top corners) |
| F.Cu / B.Cu rule areas | **KO-B1** bracket (B, footprints/pads not allowed); **KO-F2** bus-bar tongue (F); **KO-F5** core tab (F) |
| H1–H4 footprints | Ø5.0 PTH, Ø9 pad. The F courtyard is Ø11 (KO-F1 core boss) and the B courtyard Ø12 (KO-B2 screw/spring) |
| User.1 | Core contact zones from the core scan: die pad + TZ1, 4 strip pads, plate outline, bosses, height notes (G = 4.5 ± 0.5; F parts ≤ 3.5 mm; ≤ 3.0 under strips; ≤ 1.0 outside the plate) |
| User.2 | Outer-side simplified height zones (19/14/10/7/3 mm) |
| User.3 | Connector band Y 0–26 |
| Dwgs.User | Stock X-bracket outline |
| Cmts.User | Notes |

Placeholders on B:
- J1: MCIO 124 RA at X 43.5
- J2: MCIO 74 RA at X 82.0
- J3: GH15 RA
- J4: optional PCIe 8-pin (DNP)
- J20/J21: bus-bar lug sites

The stackup is JLC06161H-2116 (6 layers, 1.6 mm). Netclasses: PCIE_85R, DISP_100R, REFCLK_85R, USB2_90R, PWR_12V.

## Rebuild
```
python3 tools/make_footprints.py
python3 tools/build_template.py          # needs KiCad 9 pcbnew python
cp <backplane>.kicad_pro macpro62-face-template.kicad_pro   # or keep the shipped .kicad_pro
python3 tools/postprocess.py
kicad-cli pcb drc --severity-all -o drc_report.txt macpro62-face-template.kicad_pcb
```
`tools/face_geom.json` is a copy of `macpro62-face/tools/face_geom.json`, the single geometry source. Re-copy it after any change.

## Status
- DRC: 0 violations, 0 unconnected.
- A test showed the KO-F5 and hole courtyards catch misplaced parts.
- The pad-row side of the MCIO footprints is **assumed** (OQ-5). Keep-outs marked TO MEASURE in the spec are provisional.
