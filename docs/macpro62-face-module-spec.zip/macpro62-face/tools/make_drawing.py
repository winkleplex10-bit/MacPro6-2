#!/usr/bin/env python3
"""MP62-FACE v0.1 mechanical drawing (PNG). Run with /workspace/cadenv/bin/python."""
import json, math, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Circle, Rectangle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import face_geom as fg

g = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "face_geom.json")))
OUT = sys.argv[1] if len(sys.argv) > 1 else "/workspace/macpro62-face/macpro62-face-v0.1-mech.png"
poly = g["outline_poly"]

def rect(ax, r, **kw):
    ax.add_patch(Rectangle((r[0], r[1]), r[2] - r[0], r[3] - r[1], **kw))

def dim_h(ax, x1, x2, y, text, off=0):
    ax.annotate("", (x1, y), (x2, y), arrowprops=dict(arrowstyle="<->", lw=0.7, color="k"))
    ax.text((x1 + x2) / 2, y + 1.2 + off, text, ha="center", va="bottom", fontsize=6.5)

def dim_v(ax, y1, y2, x, text):
    ax.annotate("", (x, y1), (x, y2), arrowprops=dict(arrowstyle="<->", lw=0.7, color="k"))
    ax.text(x - 1.2, (y1 + y2) / 2, text, ha="right", va="center", fontsize=6.5, rotation=90)

def base(ax, title):
    ax.add_patch(Polygon(poly, closed=True, fc="#f4f1e6", ec="k", lw=1.2, zorder=1))
    for (x, y) in g["holes"]:
        ax.add_patch(Circle((x, y), g["hole_d"] / 2, fc="white", ec="k", lw=0.8, zorder=6))
        ax.plot([x - 4, x + 4], [y, y], color="k", lw=0.3, zorder=7); ax.plot([x, x], [y - 4, y + 4], color="k", lw=0.3, zorder=7)
    dx, dy = g["DIE"]
    ax.plot([dx - 6, dx + 6], [dy, dy], "k-.", lw=0.5, zorder=8); ax.plot([dx, dx], [dy - 6, dy + 6], "k-.", lw=0.5, zorder=8)
    ax.set_xlim(-22, 126); ax.set_ylim(-24, 178); ax.set_aspect("equal")
    ax.set_title(title, fontsize=9, fontweight="bold")
    ax.tick_params(labelsize=6); ax.grid(True, lw=0.2, alpha=0.5)
    ax.set_xticks(range(0, 105, 10)); ax.set_yticks(range(0, 167, 10))

fig = plt.figure(figsize=(16.5, 13.2), dpi=150)
gs = fig.add_gridspec(2, 2, height_ratios=[3.25, 1.0], hspace=0.16, wspace=0.08, left=0.04, right=0.99, top=0.93, bottom=0.05)
fig.suptitle("MP62-FACE Module Spec v0.1 - mechanical outline, holes, keep-outs (MP62-FACE frame: origin bottom-left, viewed from the CORE side = KiCad F/top)\n"
             "Core-side zones traced from Aidan's core GPU-face scan (bracket/core_gpu_face/), gap G = 4.5 +/- 0.5 measured. Items marked TO MEASURE (M1, M4, M5, MF-*) must be verified before fabrication. mm.",
             fontsize=10)

# ---------- (a) core side ----------
ax = fig.add_subplot(gs[0, 0]); base(ax, "(a) CORE SIDE (F.Cu / top) - faces the thermal core")
pl = g["PLATE"]
ax.add_patch(Rectangle((pl["x0"], pl["y0"]), pl["x1"] - pl["x0"], pl["y1"] - pl["y0"], fc="#e5e7eb", ec="#111827", lw=0.8, ls="--", zorder=1.6))
ax.text(pl["x0"] + 1, pl["y1"] - 1.5, "core black plate (scan) X %.1f-%.1f, Y %.1f-%.1f" % (pl["x0"], pl["x1"], pl["y0"], pl["y1"]), fontsize=5.3, va="top", zorder=3)
for sp in g["STRIPS"]:
    ax.add_patch(Polygon(sp, closed=True, fc="#f6ad55", ec="#9c4221", lw=0.8, alpha=0.85, zorder=3))
ax.add_patch(Polygon(g["DIE_PAD"], closed=True, fc="#c05621", ec="#7b341e", lw=1.0, alpha=0.9, zorder=3))
rect(ax, g["TZ1"], fc="none", ec="#c0392b", lw=0.8, ls=":", zorder=4)
ax.add_patch(Circle(g["DIE"], 3.0, fc="none", ec="white", lw=1.0, ls=":", zorder=9))
ax.text(52, 83.5, "DIE PAD (core copper) %.1f x %.1f\ndie/shim + TIM: target G - p + 0.05..0.2" % (g["TZ1"][2] - g["TZ1"][0] - 2, g["TZ1"][3] - g["TZ1"][1] - 2), ha="center", va="bottom", fontsize=5.8, color="#7b341e", zorder=10)
ax.text(28.4, 69.5, "STRIP PADS (4x ~41 x 15, 45 deg)\nVRAM / power stages:\ncomponent (+Cu spreader) top\n= G - p - t_pad,c\nt_pad,c 0.5-2.0 (max 3.5)", ha="center", va="center", fontsize=5.0, color="#7b341e", zorder=10)
for (x, y) in g["CORE_BOSSES"]:
    ax.add_patch(Circle((x, y), g["PAD_CLEAR_R"], fc="none", ec="#9c4221", lw=0.5, ls=":", zorder=4))
    ax.add_patch(Circle((x, y), g["CORE_BOSS_D"] / 2, fc="#374151", ec="k", lw=0.5, alpha=0.5, zorder=5.5))
for (x, y) in g["holes"]:
    ax.add_patch(Circle((x, y), g["STANDOFF_KO_D"] / 2, fc="none", ec="k", lw=0.8, zorder=6))
ax.text(14, 112, "KO-F1 D11 no parts (core boss D9,\n4.5 +/-0.5 tall; bosses 75.2 x 50.0)", ha="left", va="bottom", fontsize=5.3, zorder=12)
ax.add_patch(Polygon(g["TAB"], closed=True, fc="#9ca3af", ec="k", lw=0.6, zorder=5))
rect(ax, g["TAB_KO"], fc="none", ec="#b91c1c", lw=0.8, ls="--", zorder=5)
ax.text(96.5, 130, "KO-F5 core tab\n(no parts)", ha="right", va="center", fontsize=5.3, color="#b91c1c")
ax.add_patch(Polygon(g["ROD"], closed=True, fc="#6b7280", ec="k", lw=0.6, zorder=5))
ax.text(84, -13.5, "core rod (beyond edge)", ha="right", fontsize=5.3)
for xx in g["FRAME_STEP_X"]:
    ax.plot([xx, xx], [0, 166], color="#4b5563", lw=0.6, ls="-.", zorder=2)
rect(ax, g["LUG_KO"], fc="#ffcccc", ec="#c53030", lw=0.8, ls="--", zorder=2)
for (x, y) in g["LUGS"]:
    ax.add_patch(Circle((x, y), g["LUG_PAD_D"] / 2, fc="#e53e3e", ec="k", lw=0.6, zorder=6))
    ax.add_patch(Circle((x, y), g["LUG_DRILL"] / 2, fc="white", ec="k", lw=0.5, zorder=7))
ax.text(87, 152, "KO-F2 bus-bar\ntongue zone\n(no parts)\n12V / GND lugs\npolarity TO MEASURE", ha="right", va="center", fontsize=5.5, color="#9b2c2c")
ax.text(52, 19.5, "Gap G = core standoff height 4.5 +/- 0.5 mm (Aidan). p = pad protrusion (TO MEASURE)\nCore-side parts outside the pads <= G_min - 0.5 = %.1f mm; over a pad, non-contact parts <= 3.0\nOutside the black plate (dashed): <= %.1f mm until the frame height is measured\n1.0 mm edge band: no parts, copper >= 0.5 mm from edge" % (g["H_CORE"], g["H_CORE_OUTSIDE_PLATE"]),
        ha="center", va="center", fontsize=5.6, bbox=dict(fc="white", ec="0.5", lw=0.5), zorder=12)
dim_h(ax, 0, 104, 171, "104.0")
dim_v(ax, 0, 166, -8, "166.0 (board 1.6 thick)")
dim_h(ax, 15, 89, 103, "74.0 (holes 4x D5.0 PTH)")
dim_v(ax, 44.5, 94.5, 6, "50.0")
ax.annotate("die / hole-pattern centre (52.0, 69.5)", (52, 69.5), (60, 108), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
ax.annotate("chamfer 17 x 13, R10 blends (both bottom corners)", (8.5, 6.4), (-20, -14), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
ax.annotate("R5 (top corners)", (102.5, 164.5), (88, 174.5), fontsize=6, arrowprops=dict(arrowstyle="->", lw=0.5))
ax.text(52, -6, "BOTTOM EDGE (toward base board / BP): ~15 mm above BP, ~55 mm from the disc centre [TO MEASURE M1b]", ha="center", fontsize=6.3)
ax.text(52, -12, "+X ->   (core view; outer view is mirrored: x_outer = 104 - x)", ha="center", fontsize=6.3)

# ---------- (b) outer side ----------
ax = fig.add_subplot(gs[0, 1]); base(ax, "(b) OUTER SIDE (B.Cu / bottom) - faces the enclosure shell; drawn SEE-THROUGH in the core-view frame")
cols = ["#e8f5e9", "#fff8e1", "#ffe0b2", "#ffccbc", "#ffab91"]
for i, (a, b, h) in enumerate(g["HZ"]):
    for s in (-1, 1):
        x0, x1 = (52 + a, 52 + b) if s > 0 else (52 - b, 52 - a)
        ax.add_patch(Rectangle((x0, 0), x1 - x0, 166, fc=cols[i], ec="none", alpha=0.55, zorder=1.5))
    ax.text(52 + (a + b) / 2, 168.5, "%g" % h, ha="center", fontsize=6.5, color="#7b341e")
    ax.text(52 - (a + b) / 2, 168.5, "%g" % h, ha="center", fontsize=6.5, color="#7b341e")
ax.text(52, 176, "OUTER HEIGHT, simplified zones (mm above outer surface); exact envelope in (c) - TO MEASURE M1", ha="center", fontsize=6.3, color="#7b341e")
ax.add_patch(Polygon(g["bracket_ko"], closed=True, fc="#b0bec5", ec="#37474f", lw=0.8, alpha=0.85, zorder=3))
ax.add_patch(Circle(g["DIE"], g["ring_void_d"] / 2, fc="#eceff1", ec="#37474f", lw=0.6, zorder=4))
ax.text(52, 69.5 - 1, "KO-B1v ring\ninterior D23.5\nparts <= 1.0\n(TBC M-BRK-1)", ha="center", va="center", fontsize=5.3, zorder=5)
ax.text(52, 100.5, "KO-B1 bracket footprint +1 mm (no parts; tented vias / tracks OK)", ha="center", va="bottom", fontsize=6, color="#263238", zorder=5)
for (x, y) in g["holes"]:
    ax.add_patch(Circle((x, y), g["OUTER_HOLE_KO_D"] / 2, fc="#78909c", ec="k", lw=0.6, alpha=0.8, zorder=4.5))
for (x, y) in g["bracket_holes"]:
    ax.add_patch(Circle((x, y), 5.66 / 2, fc="none", ec="#1a237e", lw=0.5, ls=":", zorder=8))
ax.text(96, 105.5, "KO-B2 D12 screw head /\nspring (bracket eyelet\nD5.66 on 74.3 x 49.7)", ha="right", fontsize=5.3)
rect(ax, g["CONN_BAND"], fc="none", ec="#6b46c1", lw=0.8, ls="--", zorder=4)
for k, v in g["J"].items():
    rect(ax, v["ko"], fc="#d6bcfa", ec="#553c9a", lw=0.6, ls="--", alpha=0.6, zorder=5)
    rect(ax, v["body"], fc="#805ad5", ec="k", lw=0.8, zorder=6)
    ax.text(v["cx"], v["body"][1] + 5, "%s\n%s" % (k, v["part"].split(" (")[0]), ha="center", va="center", fontsize=5.6, color="white", zorder=7)
    ax.text(v["cx"], 6.5, "plug zone -> cable exits -Y\nmated h ~%.1f" % v["h"], ha="center", va="center", fontsize=5.2, zorder=7)
    ax.plot([v["cx"], v["cx"]], [-3, v["body"][3] + 2], color="#553c9a", lw=0.4, ls="-.", zorder=7)
    ax.text(v["cx"], -4.5, "X %.1f" % v["cx"], ha="center", fontsize=6, color="#553c9a")
a = g["AUX"]
rect(ax, a["ko"], fc="#c6f6d5", ec="#276749", lw=0.6, ls="--", zorder=5)
rect(ax, a["body"], fc="#38a169", ec="k", lw=0.8, zorder=6)
ax.text(a["cx"], a["cy"], "J_AUX\nGH15 RA\nopens -X", ha="center", va="center", fontsize=5, color="white", rotation=90, zorder=7)
p = g["P8"]
rect(ax, p["body"], fc="#f6ad55", ec="k", lw=0.8, ls="--", zorder=6)
ax.text(p["cx"], p["cy"], "J_12V_ALT (opt.)\nPCIe 8-pin RA\nopens +Y", ha="center", va="center", fontsize=5.5, zorder=7)
for (x, y) in g["LUGS"]:
    ax.add_patch(Circle((x, y), g["LUG_PAD_D"] / 2, fc="#e53e3e", ec="k", lw=0.6, zorder=6))
    ax.add_patch(Circle((x, y), g["LUG_DRILL"] / 2, fc="white", ec="k", lw=0.5, zorder=7))
ax.text(96, 137, "12V lug sites (screw heads\nthis side, D10 no parts)", ha="right", fontsize=5.5, color="#9b2c2c")
for lbl, x in g["LANDING"].items():
    ax.plot([x], [-1.0], marker="^", color="#2c7a7b", ms=5, zorder=9)
ax.text(52, -10.5, "^ BP cable landing: Face P (J9) X 47.4, Face S (J10) X 56.6 -> see conflict C-5 (proposed BP move to s = +8.5 for both)", ha="center", fontsize=5.8, color="#2c7a7b")
ax.text(52, -16, "Y_mate = %.1f: both MCIO mating faces, opening toward the bottom edge; connector band Y 0-26 (dashed)" % g["Y_MATE"], ha="center", fontsize=5.8, color="#553c9a")
dim_h(ax, g["J"]["J_PCIE"]["ko"][0], g["J"]["J_PCIE"]["ko"][2], 27.5, "46 keep-out")
dim_h(ax, g["J"]["J_DISP"]["ko"][0], g["J"]["J_DISP"]["ko"][2], 27.5, "29")

# ---------- (c) section ----------
ax = fig.add_subplot(gs[1, :])
xs = [i * 0.25 for i in range(0, 417)]
ax.fill_between(xs, [fg.h_outer(x) for x in xs], 0, color="#fde68a", alpha=0.6, label="NORMATIVE v0.1 outer envelope h(x) = sqrt(R_i^2-(x-52)^2) - (55+1.6) - 1 (R_i=80 est., TO MEASURE)")
ax.plot(xs, [fg.h_outer(x) + 1.0 for x in xs], color="#b45309", lw=0.6, ls=":", label="shell (no margin)")
steps_x, steps_y = [], []
for (a_, b_, h_) in g["HZ"]:
    for s in (-1, 1):
        pass
zx = []
for (a_, b_, h_) in sorted(g["HZ"], key=lambda z: -z[0]):
    zx.append((52 - b_, 52 - a_, h_))
for (a_, b_, h_) in g["HZ"]:
    zx.append((52 + a_, 52 + b_, h_))
for (x0, x1, h_) in zx:
    ax.plot([x0, x1], [h_, h_], color="#c2410c", lw=1.4)
ax.plot([], [], color="#c2410c", lw=1.4, label="simplified stepped zones (always safe)")
ax.add_patch(Rectangle((0, -1.6), 104, 1.6, fc="#4a7c59", ec="k", lw=0.6))
ax.add_patch(Rectangle((0, -1.6 - g["Z_C"]), 104, 0.0001, ec="#1e40af", lw=1.2, ls="--"))
ax.plot([0, 104], [-1.6 - g["Z_C"]] * 2, color="#1e40af", lw=1.2, ls="--", label="core plate at G = 4.5 +/- 0.5 below the core-side surface (standoff height, measured)")
ax.plot([0, 104], [-1.6 - g["H_CORE"]] * 2, color="#7c3aed", lw=0.8, ls=":", label="core-side general height limit 3.5 (G_min - 0.5)")
ax.add_patch(Rectangle((g["TZ1"][0] + 1, -1.6 - g["Z_C"]), g["TZ1"][2] - g["TZ1"][0] - 2, g["Z_C"], fc="#fca5a5", ec="#991b1b", lw=0.6, alpha=0.7))
ax.text(52, -1.6 - g["Z_C"] / 2, "die + shim + TIM", ha="center", va="center", fontsize=6)
for k, v in g["J"].items():
    ax.add_patch(Rectangle((v["ko"][0], 0), v["ko"][2] - v["ko"][0], v["h"], fc="#805ad5", ec="k", lw=0.6, alpha=0.75))
    ax.text(v["cx"], v["h"] / 2, "%s + plug %.1f" % (k, v["h"]), ha="center", va="center", fontsize=6, color="white")
ax.add_patch(Rectangle((g["AUX"]["ko"][0], 0), g["AUX"]["ko"][2] - g["AUX"]["ko"][0], g["AUX"]["h"], fc="#38a169", ec="k", lw=0.6, alpha=0.8))
ax.text((g["AUX"]["ko"][0] + g["AUX"]["ko"][2]) / 2, 5.3, "AUX 4.3", ha="center", fontsize=6)
ax.add_patch(Rectangle((g["P8"]["body"][0], 0), g["P8"]["w"], g["P8"]["h"], fc="none", ec="#c05621", lw=0.8, ls="--"))
ax.text(52, 13.3, "opt. 8-pin 12.8 (at Y~154)", ha="center", fontsize=6, color="#c05621")
ax.set_xlim(-2, 106); ax.set_ylim(-8, 25); ax.set_aspect("auto"); ax.grid(True, lw=0.2)
ax.set_xlabel("X (mm, core-view frame)", fontsize=7); ax.set_ylabel("height above outer surface (mm)", fontsize=7)
ax.tick_params(labelsize=6)
ax.set_title("(c) SECTION normal to the board (looking along +Y): outer-side height envelope vs connector heights; core side below the board", fontsize=9, fontweight="bold")
ax.legend(fontsize=6, loc="upper right", ncol=2)
fig.savefig(OUT)
print("wrote", OUT)
