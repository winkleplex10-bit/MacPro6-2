#!/usr/bin/env python3
"""MP62-FACE v0.1 module geometry: single source of truth for the drawing, the DXF and the KiCad template.
Frame (MP62-FACE frame): origin = bottom-left corner of the outline bounding box, +X along the bottom edge,
+Y up toward the fan, VIEWED FROM THE CORE SIDE (= KiCad F/top side). Units mm.
Outer-side features (connectors, bracket) are given in the same frame (see-through).
Writes face_geom.json next to this file. Run with /workspace/cadenv/bin/python (needs ezdxf)."""
import json, math, os
import ezdxf

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = "/workspace"

W, H, T = 104.0, 166.0, 1.6
DIE = (52.0, 69.5)

# ---- outline (Fusion gpu_board_outline.dxf, symmetric about X=52 so no mirror ambiguity) ----
outline = []   # list of ("L", x1,y1,x2,y2) / ("A", cx,cy,r,a0,a1) CCW
src = ezdxf.readfile(os.path.join(ROOT, "macpro62-cad/v2/gpu_board_outline.dxf"))
holes_src = []
for e in src.modelspace():
    t = e.dxftype()
    if t == "LINE":
        outline.append(("L", round(e.dxf.start.x, 3), round(e.dxf.start.y, 3), round(e.dxf.end.x, 3), round(e.dxf.end.y, 3)))
    elif t == "ARC":
        outline.append(("A", round(e.dxf.center.x, 3), round(e.dxf.center.y, 3), round(e.dxf.radius, 3),
                        round(e.dxf.start_angle, 3), round(e.dxf.end_angle, 3)))
    elif t == "CIRCLE":
        holes_src.append((round(e.dxf.center.x, 3), round(e.dxf.center.y, 3), round(2 * e.dxf.radius, 3)))

def outline_points(step_deg=5.0):
    """ordered closed polygon (CCW) approximating the outline"""
    segs = []
    for s in outline:
        if s[0] == "L":
            segs.append([(s[1], s[2]), (s[3], s[4])])
        else:
            cx, cy, r, a0, a1 = s[1:]
            if a1 < a0: a1 += 360
            n = max(2, int(math.ceil((a1 - a0) / step_deg)))
            segs.append([(cx + r * math.cos(math.radians(a0 + (a1 - a0) * i / n)),
                          cy + r * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)])
    # chain segments
    chain = segs.pop(0)
    while segs:
        end = chain[-1]
        for i, s in enumerate(segs):
            if math.dist(s[0], end) < 0.01:
                chain += s[1:]; segs.pop(i); break
            if math.dist(s[-1], end) < 0.01:
                chain += s[::-1][1:]; segs.pop(i); break
        else:
            raise SystemExit("outline does not chain")
    if math.dist(chain[0], chain[-1]) < 0.01: chain.pop()
    a = sum(chain[i][0] * chain[(i + 1) % len(chain)][1] - chain[(i + 1) % len(chain)][0] * chain[i][1] for i in range(len(chain)))
    return chain if a > 0 else chain[::-1]

# ---- mounting holes ----
HOLE_D = 5.0                      # Fusion; bracket eyelet bore 5.66 (float +-0.33)
HOLES = [(15.0, 44.5), (89.0, 44.5), (15.0, 94.5), (89.0, 94.5)]
BRACKET_HOLES = [(DIE[0] + sx * 37.15, DIE[1] + sy * 24.85) for sx in (-1, 1) for sy in (-1, 1)]

# ---- bracket keep-out (outer side) = bracket outline + 1 mm, from bracket/gpu_bracket_keepout.dxf ----
bk = ezdxf.readfile(os.path.join(ROOT, "bracket/gpu_bracket_keepout.dxf"))
bracket_ko, bracket_ref, ring_void_d = None, None, None
for e in bk.modelspace():
    if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == "KEEPOUT":
        bracket_ko = [(round(DIE[0] + x, 3), round(DIE[1] + y, 3)) for x, y in e.get_points("xy")]
    if e.dxftype() == "LWPOLYLINE" and e.dxf.layer == "REFERENCE":
        bracket_ref = [(round(DIE[0] + x, 3), round(DIE[1] + y, 3)) for x, y in e.get_points("xy")]
    if e.dxftype() == "CIRCLE" and e.dxf.layer == "KEEPOUT_VOID":
        ring_void_d = round(2 * e.dxf.radius, 3)

# ---- height model (outer side) [Estimate, TO MEASURE M1] ----
R_I, D_FACE, MARGIN, X_AX = 80.0, 55.0, 1.0, 52.0
def h_outer(x):
    d = abs(x - X_AX)
    v = R_I ** 2 - d ** 2
    return max(0.0, math.sqrt(v) - (D_FACE + T) - MARGIN) if v > 0 else 0.0
HZ = [  # (|x-52| from, to, limit mm) conservative steps = formula at the zone's outer edge, rounded down
    (0, 20, 19.0), (20, 35, 14.0), (35, 42, 10.0), (42, 47, 7.0), (47, 52, 3.0)]
# Core-side gap: Aidan measured the GPU-face standoffs (bosses) at 4.5 +/- 0.5 mm  -> board-to-core-face gap G
Z_C = 4.5          # nominal gap G (core-side PCB surface to core plate) [Sourced: Aidan measurement 2026-10-01]
G_TOL = 0.5
H_CORE = Z_C - G_TOL - 0.5   # 3.5 mm: general core-side height limit (G_min - 0.5 margin)
H_CORE_OUTSIDE_PLATE = 1.0   # provisional limit outside the black plate (frame height TO MEASURE)

# ---- core side zones ----
# ---- core GPU face, traced from Aidan's scan (/workspace/bracket/core_gpu_face/core_gpu_face.json) ----
CORE = json.load(open(os.path.join(ROOT, "bracket/core_gpu_face/core_gpu_face.json")))
DIE_PAD = [p for p in CORE["pads"] if p["kind"] == "die"][0]["poly"]
STRIPS = [p["poly"] for p in CORE["pads"] if p["kind"] == "strip"]
CORE_BOSSES = [tuple(b["centre"]) for b in CORE["bosses"]]
CORE_BOSS_D = 9.0                  # dark raised boss around the screw hole (visual, scan) [Estimate]
PAD_CLEAR_R = 8.7                  # copper-free radius around each boss on the core (mean of fitted arcs)
PLATE = CORE["plate"]              # black plate rectangle (corner radius est.)
TAB = CORE["features"]["tab"]["poly"]; ROD = CORE["features"]["rod"]["poly"]
FRAME_STEP_X = CORE["features"]["frame_step_x"]
TZ1 = (min(x for x, _ in DIE_PAD) - 1, min(y for _, y in DIE_PAD) - 1, max(x for x, _ in DIE_PAD) + 1, max(y for _, y in DIE_PAD) + 1)
TZ2 = (10.0, 40.0, 94.0, 99.0)     # (legacy v0.1 draft) not used for rules any more
STANDOFF_KO_D = 11.0               # core-side keep-out around holes: boss D9 + 1 mm, covers the 0.6 mm boss/hole offset
OUTER_HOLE_KO_D = 12.0             # outer-side screw head / spring / driver
MEG_BOSS = []                      # released: the core scan shows no bosses at the stock MEG-stiffener screw positions
MEG_BOSS_KO_D = 8.0
TAB_KO = (min(x for x, _ in TAB) - 1, min(y for _, y in TAB) - 1, max(x for x, _ in TAB) + 1, max(y for _, y in TAB) + 1)
# mirrored core features for the other face (the core is assumed mirror-symmetric like the GPU boards) [Inference]
TAB_B = [(round(W - x, 3), y) for x, y in TAB][::-1]
TAB_KO_B = (W - TAB_KO[2], TAB_KO[1], W - TAB_KO[0], TAB_KO[3])
# ROD = base-board standoff screw at BP hole G1/G2 (Aidan 2026-10-01, photo bracket/core_photo/); other face: mirror
ROD_B = [(round(W - x, 3), y) for x, y in ROD][::-1]

# ---- 12 V bus-bar lug sites [Inference, TO MEASURE M5] ----
# Site A: stock STANDOFF_1/2 of the scanned GPU board, mirrored into core view (X ~ 97).
# Site B: mirror image about X = 52 (X ~ 7). Aidan (2026-10-01): the stock GPU 2 board is mirrored relative to
# GPU 1 in where its 12 V bus-bar screws sit, so the two faces have their lugs on opposite sides.
# v0.1 rule: every module carries BOTH sites, wired in parallel (same Y order = same net) -> any module fits either face.
def mx(x): return round(W - x, 2)
LUGS_A = [(round(104 - 6.74, 2), 147.44), (round(104 - 6.94, 2), 159.13)]
LUGS_B = [(mx(x), y) for x, y in LUGS_A]
LUGS = LUGS_A + LUGS_B
LUG_REFS = ["J20", "J21", "J22", "J23"]
LUG_NETS = ["+12V_IN", "GND", "+12V_IN", "GND"]   # by Y order; per-face polarity TO MEASURE (M5)
LUG_SITE = ["A", "A", "B", "B"]
LUG_PAD_D, LUG_DRILL = 8.8, 3.2
LUG_KO = (88.0, 139.0, 104.0, 166.0)        # KO-F2A core-side bus-bar tongue zone (no parts) [TO MEASURE]
LUG_KO_B = (W - LUG_KO[2], LUG_KO[1], W - LUG_KO[0], LUG_KO[3])   # KO-F2B mirror
LUG_KOS = [LUG_KO, LUG_KO_B]

# ---- connectors (outer side, B) ----
Y_MATE = 14.5                       # mating face of both MCIO receptacles, opening toward -Y
J = {
    "J_PCIE": dict(part="MCIO 124P RA (Amphenol G97R24332HR)", cx=43.5, w_body=42.2, w_ko=46.0, depth=10.07,
                   plug=13.1, h=8.2, peg=40.645),
    "J_DISP": dict(part="MCIO 74P RA (Amphenol G97R22332HR)", cx=82.0, w_body=25.8, w_ko=29.0, depth=10.07,
                   plug=13.1, h=8.2, peg=24.445),
}
for k, v in J.items():
    v["ko"] = (v["cx"] - v["w_ko"] / 2, Y_MATE - v["plug"], v["cx"] + v["w_ko"] / 2, Y_MATE + v["depth"] + 0.5)
    v["body"] = (v["cx"] - v["w_body"] / 2, Y_MATE, v["cx"] + v["w_body"] / 2, Y_MATE + v["depth"])
# JST GH15 RA, rotated: pin row along Y, opening toward -X
AUX = dict(part="JST SM15B-GHS-TB (GH 1.25, 15P RA)", cx=16.5, cy=26.5, len=22.0, depth=6.0, plug=6.0, h=4.3)
AUX["body"] = (AUX["cx"] - AUX["depth"] / 2, AUX["cy"] - AUX["len"] / 2, AUX["cx"] + AUX["depth"] / 2, AUX["cy"] + AUX["len"] / 2)
AUX["ko"] = (AUX["body"][0] - AUX["plug"], AUX["body"][1] - 0.5, AUX["body"][2] + 0.5, AUX["body"][3] + 0.5)
# optional PCIe 8-pin (Molex 45586-0005 class), opening toward +Y
P8 = dict(part="Molex 45586-0005 / 5569-08A2 class, PCIe 8-pin RA (optional, DNP)", cx=52.0, cy=154.0, w=18.0, depth=13.0, h=12.8)
P8["body"] = (P8["cx"] - P8["w"] / 2, P8["cy"] - P8["depth"] / 2, P8["cx"] + P8["w"] / 2, P8["cy"] + P8["depth"] / 2)
CONN_BAND = (0.0, 0.0, 104.0, 26.0)  # bottom connector band, outer side

# BP landing points of the cable (lateral, module X) from BP J9/J10 (s = +4.6 / -4.6 along each face's t axis)
LANDING = {"Face P (BP J9, s=+4.6)": 52.0 - 4.6, "Face S (BP J10, s=-4.6)": 52.0 + 4.6}

def h_core_note():
    return "core side: parts outside TZ1 <= Z_c - 0.5 = %.1f mm (Z_c TO MEASURE)" % H_CORE

if __name__ == "__main__":
    pts = outline_points()
    g = dict(W=W, H=H, T=T, DIE=DIE, outline=outline, outline_poly=[(round(x, 4), round(y, 4)) for x, y in pts],
             hole_d=HOLE_D, holes=HOLES, bracket_holes=BRACKET_HOLES, bracket_ko=bracket_ko, bracket_ref=bracket_ref,
             ring_void_d=ring_void_d, R_I=R_I, D_FACE=D_FACE, MARGIN=MARGIN, X_AX=X_AX, HZ=HZ, Z_C=Z_C, H_CORE=H_CORE,
             TZ1=TZ1, TZ2=TZ2, G_TOL=G_TOL, H_CORE_OUTSIDE_PLATE=H_CORE_OUTSIDE_PLATE, DIE_PAD=DIE_PAD, STRIPS=STRIPS,
             CORE_BOSSES=CORE_BOSSES, CORE_BOSS_D=CORE_BOSS_D, PAD_CLEAR_R=PAD_CLEAR_R, PLATE=PLATE, TAB=TAB, ROD=ROD, TAB_B=TAB_B, TAB_KO_B=TAB_KO_B, ROD_B=ROD_B,
             TAB_KO=TAB_KO, FRAME_STEP_X=FRAME_STEP_X, STANDOFF_KO_D=STANDOFF_KO_D, OUTER_HOLE_KO_D=OUTER_HOLE_KO_D, MEG_BOSS=MEG_BOSS,
             MEG_BOSS_KO_D=MEG_BOSS_KO_D, LUGS=LUGS, LUGS_A=LUGS_A, LUGS_B=LUGS_B, LUG_REFS=LUG_REFS, LUG_NETS=LUG_NETS, LUG_SITE=LUG_SITE,
             LUG_PAD_D=LUG_PAD_D, LUG_DRILL=LUG_DRILL, LUG_KO=LUG_KO, LUG_KO_B=LUG_KO_B, LUG_KOS=LUG_KOS,
             Y_MATE=Y_MATE, J=J, AUX=AUX, P8=P8, CONN_BAND=CONN_BAND, LANDING=LANDING)
    json.dump(g, open(os.path.join(HERE, "face_geom.json"), "w"), indent=1)
    print("outline pts", len(pts), "bracket_ko pts", len(bracket_ko), "ring void", ring_void_d)
    for k, v in J.items(): print(k, v["ko"], "h_outer at ends %.1f / %.1f" % (h_outer(v["ko"][0]), h_outer(v["ko"][2])))
    print("AUX ko", AUX["ko"], "h_outer %.1f" % h_outer(AUX["ko"][0]))
    print("P8", P8["body"], "h_outer %.1f" % min(h_outer(P8["body"][0]), h_outer(P8["body"][2])))
    print("lugs", LUGS, "h_outer %.1f / %.1f" % (h_outer(LUGS_A[0][0]), h_outer(LUGS_B[0][0])))
    for d in (0, 20, 35, 42, 45, 47, 50, 52): print("d=%d h=%.2f" % (d, h_outer(52 + d)))
