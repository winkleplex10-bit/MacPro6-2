#!/usr/bin/env python3
"""Assemble the MP62-FACE spec: concatenates src/spec_part*.md and fills {{...}} placeholders from snippets.SNIP."""
import glob, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from snippets import SNIP
parts = sorted(glob.glob(os.path.join(HERE, "..", "src", "spec_part*.md")))
txt = "\n".join(open(p).read().rstrip("\n") + "\n" for p in parts)
txt = re.sub(r"\{\{(\w+)\}\}", lambda m: SNIP[m.group(1)].rstrip("\n"), txt)
left = re.findall(r"\{\{\w+\}\}", txt); assert not left, left
out = sys.argv[1] if len(sys.argv) > 1 else "/workspace/macpro62-face-module-spec-v0.1.md"
open(out, "w").write(txt); print("wrote", out, len(txt.splitlines()), "lines")
