#!/usr/bin/env python3
"""Generate markdown table snippets from the pinout CSVs and the EEPROM field list (used by build_spec.py)."""
import csv, os, io, contextlib
HERE = os.path.dirname(os.path.abspath(__file__)); PO = os.path.join(HERE, "..", "pinouts")
import mp62_eeprom
from make_pinouts import LANE_POS
def rd(n): return list(csv.DictReader(open(os.path.join(PO, n))))
def pcie_lanes():
    s = "| Lane | Host TX -> module RX (module row A) | Module TX -> host RX (module row B, AC caps on module) | Used by |\n|---|---|---|---|\n"
    for n, (p, q) in enumerate(LANE_POS):
        use = "x1/x4/x8/x16" if n == 0 else "x4/x8/x16" if n < 4 else "x8/x16" if n < 8 else "x16"
        s += "| %d | A%d PETp%d / A%d PETn%d | B%d PERp%d / B%d PERn%d | %s |\n" % (n, p, n, q, n, p, n, q, n, use)
    return s
def sb(name, contacts):
    rows = {r["contact"]: r for r in rd(name)}
    s = "| Contact (module end) | Signal | Dir (module view) | Notes |\n|---|---|---|---|\n"
    for c in contacts:
        r = rows[c]; s += "| %s | %s | %s | %s |\n" % (c, r["signal"], r["dir_module_view"] or "-", r["notes"] or "")
    return s
SB = ["A8", "A9", "A10", "A11", "A12", "B8", "B9", "B10", "B11", "B12", "A26", "A27", "A28", "A29", "A30", "B26", "B27", "B28", "B29", "B30"]
def disp_main():
    rows = {r["contact"]: r for r in rd("mp62-face-v0.1_mcio74_displaylink_module-end.csv")}
    s = "| Pair | Module row B contacts | Signal | Module row A contacts | Signal |\n|---|---|---|---|---|\n"
    for i, (p, q) in enumerate(LANE_POS[:8]):
        s += "| %d | B%d / B%d | %s / %s | A%d / A%d | %s / %s |\n" % (i, p, q, rows["B%d" % p]["signal"], rows["B%d" % q]["signal"], p, q, rows["A%d" % p]["signal"], rows["A%d" % q]["signal"])
    return s
def aux():
    s = "| Pin | Signal | Dir (module view) | Notes |\n|---|---|---|---|\n"
    for r in rd("mp62-face-v0.1_aux_gh15.csv"): s += "| %s | %s | %s | %s |\n" % (r["pin"], r["signal"], r["dir_module_view"] or "-", r["notes"])
    return s
def eeprom():
    f = io.StringIO()
    with contextlib.redirect_stdout(f): mp62_eeprom.table()
    return f.getvalue()
SNIP = {"PCIE_LANES": pcie_lanes(), "PCIE_SB": sb("mp62-face-v0.1_mcio124_pcie_module-end.csv", SB),
        "DISP_MAIN": disp_main(), "DISP_SB": sb("mp62-face-v0.1_mcio74_displaylink_module-end.csv", SB),
        "AUX_TABLE": aux(), "EEPROM_TABLE": eeprom()}
