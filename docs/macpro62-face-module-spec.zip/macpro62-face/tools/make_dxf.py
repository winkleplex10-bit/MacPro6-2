#!/usr/bin/env python3
"""MP62-FACE v0.1 DXF (R2010, mm). Run with /workspace/cadenv/bin/python."""
import json, os, sys
import ezdxf
from ezdxf import units
HERE = os.path.dirname(os.path.abspath(__file__))
g = json.load(open(os.path.join(HERE, "face_geom.json")))
OUT = sys.argv[1] if len(sys.argv) > 1 else "/workspace/macpro62-face/macpro62-face-v0.1-outline.dxf"
doc = ezdxf.new("R2010", setup=True); doc.units = units.MM
doc.header["$INSUNITS"] = 4; doc.header["$MEASUREMENT"] = 1
msp = doc.modelspace()
L = {  # layer: (colour, description)
 "OUTLINE": (7, "Board outline 104x166 (Edge.Cuts)"), "HOLES": (7, "4x D5.0 mounting holes on 74x50"),
 "DIE_CENTRE": (1, "die / hole-pattern centre (52,69.5)"), "BRACKET_REF": (5, "stock X-bracket outline + eyelets (reference)"),
 "KO_B_BRACKET": (8, "outer side: bracket footprint +1 mm, no parts"), "KO_B_RING_VOID": (9, "outer side: ring interior D23.5, parts <= 1.0 TBC"),
 "KO_B_SCREW": (8, "outer side: D12 screw head/spring"), "KO_F_STANDOFF": (8, "core side: D10 standoff, no parts"),
 "KO_F_MEGBOSS": (2, "core side provisional D8 (possible core bosses)"), "KO_F_BUSBAR": (1, "core side bus-bar tongue zones KO-F2A (X 88-104) and KO-F2B (mirror, X 0-16)"),
 "TZ1_DIE_CONTACT": (1, "die contact zone = core die pad + 1 mm"),
 "LUG_12V": (1, "12V/GND bus-bar lug pads D8.8, drill 3.2: site A J20/J21 and mirrored site B J22/J23, both fitted"), "CONN_BAND_B": (6, "outer side connector band Y0-26"),
 "CONN_J_PCIE": (6, "MCIO 124P RA body"), "CONN_J_PCIE_PLUG": (6, "MCIO 124P plug zone"),
 "CONN_J_DISP": (6, "MCIO 74P RA body"), "CONN_J_DISP_PLUG": (6, "MCIO 74P plug zone"),
 "CONN_J_AUX": (3, "GH15 RA body + plug zone"), "CONN_J_12V_ALT": (30, "optional PCIe 8-pin RA"),
 "HZ_OUTER": (30, "outer-side simplified height zones"), "NOTES": (7, "notes"),
 "CORE_DIE_PAD": (1, "core copper die pad (scan trace): die/shim+TIM contact"), "CORE_STRIP_PADS": (30, "core copper strip pads (scan): VRAM/power stages via thermal pads"),
 "CORE_BOSSES": (5, "core standoff bosses D9, 4.5 +/-0.5 tall (scan + measurement)"), "CORE_PLATE": (8, "core black plate outline; outside it core-side parts <= 1.0 mm (provisional)"),
 "KO_F_TAB": (1, "core-side keep-out around the core tab KO-F5A and its mirror KO-F5B"), "CORE_FRAME": (9, "core frame pocket step lines / base-board standoff screw (rod) and its mirror"),
}
for n, (c, d) in L.items():
    doc.layers.add(n, color=c).description = d
def rect(r, layer):
    msp.add_lwpolyline([(r[0], r[1]), (r[2], r[1]), (r[2], r[3]), (r[0], r[3])], close=True, dxfattribs={"layer": layer})
for s in g["outline"]:
    if s[0] == "L": msp.add_line((s[1], s[2]), (s[3], s[4]), dxfattribs={"layer": "OUTLINE"})
    else: msp.add_arc((s[1], s[2]), s[3], s[4], s[5], dxfattribs={"layer": "OUTLINE"})
for x, y in g["holes"]:
    msp.add_circle((x, y), g["hole_d"] / 2, dxfattribs={"layer": "HOLES"})
    msp.add_circle((x, y), g["STANDOFF_KO_D"] / 2, dxfattribs={"layer": "KO_F_STANDOFF"})
    msp.add_circle((x, y), g["OUTER_HOLE_KO_D"] / 2, dxfattribs={"layer": "KO_B_SCREW"})
for x, y in g["bracket_holes"]:
    msp.add_circle((x, y), 5.66 / 2, dxfattribs={"layer": "BRACKET_REF"}); msp.add_circle((x, y), 8.92 / 2, dxfattribs={"layer": "BRACKET_REF"})
msp.add_lwpolyline(g["bracket_ref"], close=True, dxfattribs={"layer": "BRACKET_REF"})
msp.add_lwpolyline(g["bracket_ko"], close=True, dxfattribs={"layer": "KO_B_BRACKET"})
msp.add_circle(g["DIE"], g["ring_void_d"] / 2, dxfattribs={"layer": "KO_B_RING_VOID"})
dx, dy = g["DIE"]
msp.add_line((dx - 5, dy), (dx + 5, dy), dxfattribs={"layer": "DIE_CENTRE"}); msp.add_line((dx, dy - 5), (dx, dy + 5), dxfattribs={"layer": "DIE_CENTRE"})
msp.add_circle(g["DIE"], 3.0, dxfattribs={"layer": "DIE_CENTRE"})
for x, y in g["MEG_BOSS"]: msp.add_circle((x, y), g["MEG_BOSS_KO_D"] / 2, dxfattribs={"layer": "KO_F_MEGBOSS"})
[rect(r, "KO_F_BUSBAR") for r in g["LUG_KOS"]]; rect(g["TZ1"], "TZ1_DIE_CONTACT")
msp.add_lwpolyline(g["DIE_PAD"], close=True, dxfattribs={"layer": "CORE_DIE_PAD"})
for sp in g["STRIPS"]: msp.add_lwpolyline(sp, close=True, dxfattribs={"layer": "CORE_STRIP_PADS"})
for (x, y) in g["CORE_BOSSES"]:
    msp.add_circle((x, y), g["CORE_BOSS_D"] / 2, dxfattribs={"layer": "CORE_BOSSES"}); msp.add_circle((x, y), g["PAD_CLEAR_R"], dxfattribs={"layer": "CORE_BOSSES"})
pl = g["PLATE"]; rect((pl["x0"], pl["y0"], pl["x1"], pl["y1"]), "CORE_PLATE")
msp.add_lwpolyline(g["TAB"], close=True, dxfattribs={"layer": "KO_F_TAB"}); rect(g["TAB_KO"], "KO_F_TAB")
msp.add_lwpolyline(g["TAB_B"], close=True, dxfattribs={"layer": "KO_F_TAB"}); rect(g["TAB_KO_B"], "KO_F_TAB")
msp.add_lwpolyline(g["ROD"], close=True, dxfattribs={"layer": "CORE_FRAME"}); msp.add_lwpolyline(g["ROD_B"], close=True, dxfattribs={"layer": "CORE_FRAME"})
for xx in g["FRAME_STEP_X"]: msp.add_line((xx, 0), (xx, 166), dxfattribs={"layer": "CORE_FRAME"})
for (x, y), ref, net in zip(g["LUGS"], g["LUG_REFS"], g["LUG_NETS"]):
    msp.add_circle((x, y), g["LUG_PAD_D"] / 2, dxfattribs={"layer": "LUG_12V"}); msp.add_circle((x, y), g["LUG_DRILL"] / 2, dxfattribs={"layer": "LUG_12V"})
    msp.add_text("%s %s" % (ref, net), height=1.2, dxfattribs={"layer": "LUG_12V"}).set_placement((x + (-5.5 if x > 52 else 5.5), y), align=ezdxf.enums.TextEntityAlignment.MIDDLE_RIGHT if x > 52 else ezdxf.enums.TextEntityAlignment.MIDDLE_LEFT)
rect(g["CONN_BAND"], "CONN_BAND_B")
for k in ("J_PCIE", "J_DISP"):
    v = g["J"][k]; rect(v["body"], "CONN_" + k); rect((v["ko"][0], v["ko"][1], v["ko"][2], g["Y_MATE"]), "CONN_%s_PLUG" % k)
rect(g["AUX"]["body"], "CONN_J_AUX"); rect(g["AUX"]["ko"], "CONN_J_AUX"); rect(g["P8"]["body"], "CONN_J_12V_ALT")
for a, b, h in g["HZ"]:
    for x0, x1 in ((52 + a, 52 + b), (52 - b, 52 - a)):
        rect((x0, 0, x1, 166), "HZ_OUTER")
        msp.add_text("H<=%g" % h, height=1.5, dxfattribs={"layer": "HZ_OUTER"}).set_placement(((x0 + x1) / 2, 168), align=ezdxf.enums.TextEntityAlignment.BOTTOM_CENTER)
notes = ["MP62-FACE Module Spec v0.1 - outline/holes/keep-outs. Frame: origin bottom-left, viewed from CORE side (KiCad top). mm.",
         "Outer-side (B) features drawn see-through. x_outer_view = 104 - x. Provisional: TO MEASURE items D3, M1, M4, M5.",
         "Bus-bar lugs: site A (X~97) + mirrored site B (X~7) on every module, in parallel (stock GPU 2 is mirrored). Polarity per face TO MEASURE M5.",
         "Core side: gap G = 4.5 +/-0.5 (standoffs, measured). Parts outside pads <= 3.5; outside plate <= 1.0 (prov.). Outer: h(x)=sqrt(80^2-(x-52)^2)-57.6 (est)."]
for i, t in enumerate(notes):
    msp.add_text(t, height=1.6, dxfattribs={"layer": "NOTES"}).set_placement((0, -8 - 3 * i))
doc.saveas(OUT)
print("wrote", OUT, len(msp), "entities")
