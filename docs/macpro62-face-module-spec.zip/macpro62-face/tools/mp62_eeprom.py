#!/usr/bin/env python3
"""MP62-FACE v0.1 ID EEPROM descriptor: field table, encoder, validator, example images.
Usage:  python3 mp62_eeprom.py            -> writes example images + prints the markdown field table
        python3 mp62_eeprom.py check FILE -> validates an image (magic, length, CRC, ranges)
Layout: MP62 Module Descriptor v1 at EEPROM offset 0x0000, little-endian, CRC-16/CCITT-FALSE in the last 2 bytes."""
import struct, sys, os

FIELDS = [  # (offset, size, name, fmt, description)
 (0x00, 4, "magic", "4s", 'ASCII "MP62" (4D 50 36 32)'),
 (0x04, 1, "desc_ver", "B", "Descriptor format version = 0x01"),
 (0x05, 1, "spec_ver", "B", "MP62-FACE spec version, BCD major.minor (0x01 = v0.1)"),
 (0x06, 2, "length", "H", "Total descriptor length L in bytes, including the CRC (<= 512)"),
 (0x08, 2, "mech_rev", "H", "MP62-FACE-MECH revision the module complies with (0x0001 = v0.1 outline/keep-outs)"),
 (0x0A, 1, "vid_space", "B", "Vendor-ID namespace: 0 = development/unassigned, 1 = PCI-SIG VID, 2 = MP62 community registry"),
 (0x0B, 1, "rsvd0", "B", "Reserved, 0"),
 (0x0C, 2, "vendor_id", "H", "Vendor ID in that namespace"),
 (0x0E, 2, "product_id", "H", "Product ID (vendor assigned)"),
 (0x10, 1, "hw_rev", "B", "Hardware revision (vendor assigned)"),
 (0x11, 1, "module_type", "B", "1 GPU, 2 storage, 3 NIC, 4 accelerator/FPGA, 5 capture, 6 adapter/bench, 7 thermal test, 0xFE other (0 invalid)"),
 (0x12, 1, "slot_mask", "B", "bit0 Face P allowed, bit1 Face S allowed"),
 (0x13, 1, "pcie_width_max", "B", "Max link width: 1/2/4/8/16"),
 (0x14, 1, "pcie_width_min", "B", "Min width at which the module is still functional (usually 1)"),
 (0x15, 1, "pcie_gen_max", "B", "Max PCIe generation: 3/4/5"),
 (0x16, 1, "bifurcation", "B", "0 single link, 1 x8x8 (uses sideband set B), 2 x8x4x4, 3 x4x4x4x4 (rev-A hosts: 0 only)"),
 (0x17, 1, "clk_flags", "B", "bit0 needs REFCLK0, bit1 needs REFCLK1, bit2 drives CLKREQ#, bit3 SRIS capable, bit4 drives WAKE#"),
 (0x18, 1, "power_class", "B", "Power class 0-3 (section 6.2)"),
 (0x19, 1, "v12_src_mask", "B", "12 V inputs fitted: bit0 bus-bar lugs, bit1 PCIe 8-pin, bit2 PCIe 6-pin"),
 (0x1A, 2, "p_sustained_w", "H", "Sustained 12 V input power, W"),
 (0x1C, 2, "p_peak_w", "H", "Peak 12 V input power (<= 10 ms), W"),
 (0x1E, 2, "aux_s0_ma", "H", "Max 3V3_AUX current in S0, mA (<= 1000)"),
 (0x20, 2, "aux_s5_mw", "H", "Max 3V3_AUX power in S5, mW (<= 50)"),
 (0x22, 1, "t_pg_ms", "B", "Max FACE_PWR_EN -> FACE_PWR_GOOD time, ms (<= 150)"),
 (0x23, 1, "inrush_da", "B", "Peak 12 V inrush after FACE_PWR_EN, units of 0.1 A"),
 (0x24, 1, "t_target_c", "b", "Fan-curve knee temperature, deg C (sensor reading)"),
 (0x25, 1, "t_warn_c", "b", "Warning temperature (module asserts THERM_ALERT#), deg C"),
 (0x26, 1, "t_crit_c", "b", "Critical temperature (module asserts THERM_TRIP#), deg C"),
 (0x27, 1, "sensor_addr", "B", "7-bit address of the LM75-compatible sensor (0x48)"),
 (0x28, 1, "hotspot_dx", "b", "Hot-spot centroid offset from (52.0, 69.5), X, units 0.5 mm (|value| <= 6)"),
 (0x29, 1, "hotspot_dy", "b", "Hot-spot centroid offset, Y, units 0.5 mm (|value| <= 6)"),
 (0x2A, 1, "plane_offset", "B", "Module PCB plane offset outward from the stock plane, units 0.1 mm (0 = stock; MXM carriers > 0)"),
 (0x2B, 1, "h_outer_max", "B", "Tallest outer-side part used, units 0.1 mm"),
 (0x2C, 1, "h_core_max", "B", "Tallest core-side part outside the die/strip contact stacks, units 0.1 mm (<= G_min + plane_offset - 0.5 = 3.5 mm for plane_offset 0)"),
 (0x2D, 1, "disp_count", "B", "Number of display links on DISPLAY-LINK (0-5)"),
 (0x2E, 1, "disp_flags", "B", "bit0 DISPLAY-LINK connector fitted, bit1 link3 is 4-lane (link4 absent), bit2 UEFI GOP boot display, bit3 HDMI FRL capable"),
 (0x2F, 1, "led_caps", "B", "bit0 drives MOD_LED#, bit1 activity blink on MOD_LED#, bit2 SMBus identify register"),
 (0x30, 1, "flags", "B", "bit0 uses USB2 (AUX), bit1 requires THERM_ALERT# host support, bit2 pre-production/dev, bit3 EEPROM WP strapped, bit4 uses PCIe 2-wire bus"),
 (0x31, 3, "rsvd1", "3s", "Reserved, 0"),
 (0x34, 20, "disp_links", "20s", "5 x 4-byte display-link descriptors (link 0..4): type, lanes, max rate, flags (section 9.4)"),
 (0x48, 1, "n_pci_ids", "B", "Number N of PCI VID:DID entries (0-8)"),
 (0x49, 3, "rsvd2", "3s", "Reserved, 0"),
]
FIXED_END = 0x4C
DISP_TYPE = {"none": 0, "DP": 1, "DP++": 2, "HDMI_TMDS": 3, "HDMI_FRL": 4, "DP_ALT": 5}
DP_RATE = {"RBR": 1, "HBR": 2, "HBR2": 3, "HBR3": 4, "UHBR10": 5, "UHBR13.5": 6, "UHBR20": 7,
           "TMDS_3G4": 0x10, "TMDS_6G": 0x11, "FRL_3x3": 0x12, "FRL_3x6": 0x13, "FRL_4x6": 0x14, "FRL_4x8": 0x15, "FRL_4x10": 0x16, "FRL_4x12": 0x17}

def crc16_ccitt_false(data: bytes) -> int:
    c = 0xFFFF
    for b in data:
        c ^= b << 8
        for _ in range(8):
            c = ((c << 1) ^ 0x1021) & 0xFFFF if c & 0x8000 else (c << 1) & 0xFFFF
    return c

def encode(d, links, pci_ids, strings):
    body = bytearray(FIXED_END)
    d = dict(d); d["magic"] = b"MP62"; d.setdefault("desc_ver", 1); d.setdefault("spec_ver", 0x01)
    d["n_pci_ids"] = len(pci_ids)
    dl = b""
    for i in range(5):
        if i < len(links):
            t, lanes, rate, fl = links[i]; dl += bytes([DISP_TYPE[t], lanes, DP_RATE[rate], fl])
        else: dl += bytes(4)
    d["disp_links"] = dl
    for off, size, name, fmt, _ in FIELDS:
        if name == "length": continue
        v = d.get(name, b"\0" * size if fmt.endswith("s") else 0)
        struct.pack_into("<" + fmt, body, off, v)
    for vid, did in pci_ids: body += struct.pack("<HH", vid, did)
    for s in strings:   # vendor, product, part number, serial, build date; each: u8 length + ASCII
        b = s.encode("ascii"); body += bytes([len(b)]) + b
    L = len(body) + 2
    struct.pack_into("<H", body, 0x06, L)
    return bytes(body) + struct.pack("<H", crc16_ccitt_false(bytes(body)))

def check(img: bytes):
    errs = []
    if img[:4] != b"MP62": errs.append("bad magic")
    L = struct.unpack_from("<H", img, 6)[0]
    if not (FIXED_END + 2 <= L <= 512): errs.append("bad length %d" % L)
    else:
        crc = struct.unpack_from("<H", img, L - 2)[0]
        if crc != crc16_ccitt_false(img[:L - 2]): errs.append("CRC mismatch")
    v = {name: struct.unpack_from("<" + fmt, img, off)[0] for off, size, name, fmt, _ in FIELDS}
    if v["pcie_width_max"] not in (1, 2, 4, 8, 16): errs.append("width")
    if v["pcie_gen_max"] not in (3, 4, 5): errs.append("gen")
    if v["aux_s5_mw"] > 50: errs.append("S5 aux > 50 mW")
    if v["aux_s0_ma"] > 1000: errs.append("S0 aux > 1000 mA")
    if v["t_pg_ms"] > 150: errs.append("t_pg > 150 ms")
    if abs(v["hotspot_dx"]) > 6 or abs(v["hotspot_dy"]) > 6: errs.append("hot-spot outside R3")
    if v["h_core_max"] > 35 + v["plane_offset"]: errs.append("h_core_max above G_min + plane_offset - 0.5 mm")
    cls_max = {0: 3, 1: 40, 2: 75, 3: 150}
    if v["power_class"] not in cls_max or v["p_sustained_w"] > cls_max[v["power_class"]]: errs.append("power above class")
    if v["slot_mask"] & 2 and v["p_sustained_w"] > 40: errs.append("Face S allowed but > 40 W (rev-A Face S budget)")
    return errs, v

def table():
    print("| Offset | Size | Field | Meaning |\n|---|---|---|---|")
    for off, size, name, fmt, desc in FIELDS:
        print("| 0x%02X | %d | `%s` | %s |" % (off, size, name, desc))
    print("| 0x4C | 4 x N | PCI IDs | N x (u16 VID, u16 DID), little-endian |")
    print("| ... | var | strings | 5 strings, each u8 length + ASCII: vendor name (<= 32), product name (<= 32), part number (<= 24), serial (<= 24), build date YYYYMMDD |")
    print("| L-2 | 2 | `crc16` | CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF, no reflection, xorout 0) over bytes 0 .. L-3 |")

if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "check":
        e, v = check(open(sys.argv[2], "rb").read()); print("OK" if not e else "ERRORS: " + ", ".join(e)); sys.exit(1 if e else 0)
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "eeprom_examples")
    os.makedirs(out, exist_ok=True)
    gpu = dict(mech_rev=1, vid_space=0, vendor_id=0x0000, product_id=0x0001, hw_rev=1, module_type=1, slot_mask=1,
               pcie_width_max=8, pcie_width_min=1, pcie_gen_max=4, bifurcation=0, clk_flags=0b00001, power_class=3,
               v12_src_mask=0b001, p_sustained_w=110, p_peak_w=143, aux_s0_ma=150, aux_s5_mw=20, t_pg_ms=60, inrush_da=30,
               t_target_c=70, t_warn_c=90, t_crit_c=100, sensor_addr=0x48, hotspot_dx=0, hotspot_dy=0, plane_offset=50,
               h_outer_max=82, h_core_max=20, disp_count=4, disp_flags=0b0101, led_caps=0b001, flags=0b01101)
    gl = [("DP", 4, "HBR3", 3), ("DP", 4, "HBR3", 3), ("HDMI_TMDS", 4, "TMDS_6G", 3), ("DP_ALT", 2, "HBR3", 3)]
    img = encode(gpu, gl, [(0x1002, 0x73FF)], ["MP62 community (dev)", "MXM carrier RX 6600 (X-VSION)", "MP62-FP-MXM-A", "DEV0001", "20261001"])
    open(os.path.join(out, "example_mxm_rx6600.bin"), "wb").write(img)
    sto = dict(mech_rev=1, vid_space=0, vendor_id=0x0000, product_id=0x0003, hw_rev=1, module_type=2, slot_mask=3,
               pcie_width_max=8, pcie_width_min=1, pcie_gen_max=3, bifurcation=0, clk_flags=0b00001, power_class=1,
               v12_src_mask=0b001, p_sustained_w=40, p_peak_w=52, aux_s0_ma=100, aux_s5_mw=20, t_pg_ms=40, inrush_da=10,
               t_target_c=55, t_warn_c=70, t_crit_c=85, sensor_addr=0x48, plane_offset=0, h_outer_max=40, h_core_max=20,
               disp_count=0, disp_flags=0, led_caps=0b011, flags=0b01100)
    img2 = encode(sto, [], [(0x1B21, 0x2824)], ["MP62 community (dev)", "ASM2824 4x M.2 storage", "MP62-FS-NVME4-A", "DEV0002", "20261001"])
    open(os.path.join(out, "example_storage_asm2824.bin"), "wb").write(img2)
    for n, im in (("example_mxm_rx6600.bin", img), ("example_storage_asm2824.bin", img2)):
        e, v = check(im); print(n, len(im), "bytes", "OK" if not e else e)
    table()
