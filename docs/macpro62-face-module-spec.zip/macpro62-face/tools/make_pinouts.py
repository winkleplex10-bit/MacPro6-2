#!/usr/bin/env python3
"""MP62-FACE v0.1 pinouts -> CSV + markdown. Module-end contact numbering per SFF-TA-1016 (rows A/B, positions 1..62 / 1..37).
The SFF-TA-1016 cable crosses rows (P1 B-n <-> P2 A-n), so the host (BP / IOB) end is the same table with A and B swapped."""
import csv, os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "pinouts")
LANE_POS = [(2, 3), (5, 6), (14, 15), (17, 18), (20, 21), (23, 24), (32, 33), (35, 36),
            (39, 40), (42, 43), (45, 46), (48, 49), (51, 52), (54, 55), (57, 58), (60, 61)]
# ---------------- MCIO 124 PCIe (module end) ----------------
def pcie_rows():
    sig = {}
    for n, (p, q) in enumerate(LANE_POS):
        sig[("A", p)] = ("PETp%d" % n, "In", "Host TX lane %d -> module RX (host places AC caps)" % n)
        sig[("A", q)] = ("PETn%d" % n, "In", "")
        sig[("B", p)] = ("PERp%d" % n, "Out", "Module TX lane %d -> host RX; 220 nF AC cap on the module" % n)
        sig[("B", q)] = ("PERn%d" % n, "Out", "")
    sb = {  # module end (row-swapped vs SFF-9402 host end)
        ("B", 8): ("CLKREQ0#", "Out (OD)", "SFF-9402 BP_TYPEA position. Optional; host pull-up, BP rev A ignores it (REFCLK free-running)"),
        ("B", 9): ("WAKE0#", "Out (OD)", "SFF-9402 CWAKEA#. Optional; host pull-up to 3V3_SB-side"),
        ("B", 10): ("GND", "", "sideband ground"),
        ("B", 11): ("REFCLK0+", "In", "100 MHz HCSL, common clock, always on in S0"),
        ("B", 12): ("REFCLK0-", "In", ""),
        ("A", 8): ("PCIE_SMCLK", "Bi (OD)", "SFF-9402 2W-CLKA. Optional PCIe SMBus (device telemetry); NC on BP rev A; never the ID EEPROM"),
        ("A", 9): ("PCIE_SMDAT", "Bi (OD)", "SFF-9402 2W-DATAA. As above"),
        ("A", 10): ("GND", "", "sideband ground"),
        ("A", 11): ("PERST0#", "In", "3.3 V; = PLTRST# AND FACE_RDY from the BP"),
        ("A", 12): ("MCIO_PRSNT0#", "Out", "SFF-9402 CPRSNTA#. Module ties to GND (link/cable present)"),
        ("B", 26): ("CLKREQ1#", "Out (OD)", "Set B, x8x8 modules only; otherwise NC"),
        ("B", 27): ("WAKE1#", "Out (OD)", "Set B; NC unless bifurcated"),
        ("B", 28): ("GND", "", ""),
        ("B", 29): ("REFCLK1+", "In", "Set B: second link (x8x8). Not driven by BP rev A"),
        ("B", 30): ("REFCLK1-", "In", ""),
        ("A", 26): ("RSVD_2WCLK1", "-", "Set B 2-wire: reserved, NC"),
        ("A", 27): ("RSVD_2WDAT1", "-", "Set B 2-wire: reserved, NC"),
        ("A", 28): ("GND", "", ""),
        ("A", 29): ("PERST1#", "In", "Set B: second link reset (x8x8). Not driven by BP rev A"),
        ("A", 30): ("MCIO_PRSNT1#", "Out", "Module ties to GND only if it uses set B"),
    }
    sig.update(sb)
    rows = []
    for pos in range(1, 63):
        for r in ("A", "B"):
            s, d, note = sig.get((r, pos), ("GND", "", ""))
            rows.append((r + str(pos), s, d, note))
    return rows
def disp_rows():
    sig = {}
    B = ["ML0_0", "ML0_1", "ML0_2", "ML0_3", "ML1_0", "ML1_1", "ML1_2", "ML1_3"]
    A = ["ML2_0", "ML2_1", "ML2_2", "ML2_3", "ML3_0", "ML3_1", "ML4_0", "ML4_1"]
    note = {"ML0": "Link 0: DP 1.4 lane %s (rear DP #1)", "ML1": "Link 1: DP 1.4 lane %s (rear DP #2)",
            "ML2": "Link 2: HDMI 2.1 (TMDS D%s / FRL lane) or DP++; IOB carries the HDMI retimer",
            "ML3": "Link 3: DP alt-mode lane %s (USB-C #1 via IOB mux); 4-lane alt: ML4 pairs become ML3_2/3",
            "ML4": "Link 4: DP alt-mode lane %s (USB-C #2 via IOB mux)"}
    for row, names in (("B", B), ("A", A)):
        for (p, q), nm in zip(LANE_POS[:8], names):
            k, ln = nm.split("_")
            sig[(row, p)] = ("%sp_%s" % (k, ln), "Out", (note[k] % ln) if "%s" in note[k] else note[k])
            sig[(row, q)] = ("%sn_%s" % (k, ln), "Out", "AC-coupled on the module (DP 75-200 nF)")
    sb = {("B", 8): ("AUX0+", "Bi", "DP AUX link 0 (100 nF AC + source bias on module)"), ("B", 9): ("AUX0-", "Bi", ""),
          ("B", 10): ("GND", "", ""), ("B", 11): ("AUX1+", "Bi", "DP AUX link 1"), ("B", 12): ("AUX1-", "Bi", ""),
          ("A", 8): ("AUX2+/DDC_SCL", "Bi", "Link 2: DP AUX+, or HDMI DDC SCL (DP++ convention)"), ("A", 9): ("AUX2-/DDC_SDA", "Bi", "Link 2: DP AUX-, or HDMI DDC SDA"),
          ("A", 10): ("GND", "", ""), ("A", 11): ("HPD0", "In", "3.3 V hot-plug detect from IOB (IOB buffers 5 V-tolerant)"), ("A", 12): ("HPD1", "In", ""),
          ("B", 26): ("AUX3+", "Bi", "DP AUX link 3 (to IOB PD/alt-mode controller path)"), ("B", 27): ("AUX3-", "Bi", ""),
          ("B", 28): ("GND", "", ""), ("B", 29): ("AUX4+", "Bi", "DP AUX link 4"), ("B", 30): ("AUX4-", "Bi", ""),
          ("A", 26): ("HPD2", "In", ""), ("A", 27): ("HPD3", "In", ""), ("A", 28): ("GND", "", ""),
          ("A", 29): ("HPD4", "In", ""), ("A", 30): ("DLINK_PRSNT#", "Out", "Module ties to GND; IOB detects the display cable")}
    sig.update(sb)
    rows = []
    for pos in range(1, 38):
        for r in ("A", "B"):
            s, d, n = sig.get((r, pos), ("GND", "", ""))
            rows.append((r + str(pos), s, d, n))
    return rows
AUX = [(1, "3V3_AUX", "In (power)", "From BP. <= 1.0 A per face in S0, <= 15 mA (50 mW) in S5; 2 pins x 1 A GH rating"),
       (2, "3V3_AUX", "In (power)", ""), (3, "GND", "", ""),
       (4, "FACE_PRSNT#", "Out", "Module ties to GND"),
       (5, "FACE_PWR_EN", "In", "3.3 V push-pull from BP; high = module may enable its 12 V eFuse; module pull-down 100k"),
       (6, "FACE_PWR_GOOD", "Out (OD)", "Released (high) when all module rails are good; host pull-up to 3V3_AUX"),
       (7, "GND", "", ""),
       (8, "FACE_SMB_CLK", "In (OD)", "Management SMBus, 3.3 V, 100 kHz (400 kHz optional); host 2.2k pull-ups"),
       (9, "FACE_SMB_DAT", "Bi (OD)", "ID EEPROM 0x50, sensor 0x48, optional 0x40-0x47 / 0x20-0x27 / 0x60-0x6F"),
       (10, "FACE_SMB_ALERT#", "Out (OD)", "SMBus alert (sensor ALERT, power monitor)"),
       (11, "THERM_ALERT#", "Bi (OD)", "Host -> module: reduce power within 100 ms; module -> host: above T_warn"),
       (12, "THERM_TRIP#", "Out (OD)", "Module -> host at T_crit, hardware only; latches the PSU off"),
       (13, "USB2_D+", "Bi", "Primary USB2 path for the face (module MCU / firmware update). Optional for modules"),
       (14, "USB2_D-", "Bi", "90 ohm; host provides the USB2 port (BP hub)"),
       (15, "MOD_LED#", "Out (OD)", "Module status/activity, active low, <= 5 mA sink; BP mirrors it to the face LED")]
PWR = [("J20 lug (site A, X 97.26 Y 147.44)", "+12V_IN (polarity TO MEASURE per face)", "Stock bus bar, T8 923-0716 screw", ">= 15 A design, 12.5 A at 150 W"),
       ("J21 lug (site A, X 97.06 Y 159.13)", "GND", "Stock bus bar", "same"),
       ("J22 lug (site B mirror, X 6.74 Y 147.44)", "+12V_IN (parallel to J20)", "Stock bus bar of the mirrored face", "same; idle site is live"),
       ("J23 lug (site B mirror, X 6.94 Y 159.13)", "GND (parallel to J21)", "Stock bus bar of the mirrored face", "same"),
       ("J4 PCIe 8-pin pins 1-3", "+12V_IN", "Molex 45586-0005 (opt., DNP)", "3 x 9 A Mini-Fit Jr; PCIe CEM 150 W"),
       ("J4 PCIe 8-pin pins 4,6 (SENSE1, SENSE0)", "SENSE", "", "module may read to detect 6- vs 8-pin cable"),
       ("J4 PCIe 8-pin pins 5,7,8", "GND", "", "")]
def write(name, hdr, rows):
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.writer(f); w.writerow(hdr); w.writerows(rows)
    print("wrote", name, len(rows))
os.makedirs(OUT, exist_ok=True)
write("mp62-face-v0.1_mcio124_pcie_module-end.csv", ["contact", "signal", "dir_module_view", "notes"], pcie_rows())
write("mp62-face-v0.1_mcio74_displaylink_module-end.csv", ["contact", "signal", "dir_module_view", "notes"], disp_rows())
write("mp62-face-v0.1_aux_gh15.csv", ["pin", "signal", "dir_module_view", "notes"], AUX)
write("mp62-face-v0.1_power.csv", ["contact", "net", "part", "rating"], PWR)
