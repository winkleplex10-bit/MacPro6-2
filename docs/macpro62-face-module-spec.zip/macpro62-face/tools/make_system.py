#!/usr/bin/env python3
"""MP62-FACE v0.1 system diagram: links, power path, display path + power sequencing timing. matplotlib."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
OUT = "/workspace/macpro62-face/macpro62-face-v0.1-system.png"
fig = plt.figure(figsize=(16, 12.5), dpi=150)
ax = fig.add_axes([0.02, 0.40, 0.96, 0.55]); ax.set_xlim(0, 172); ax.set_ylim(0, 80); ax.axis("off")
fig.suptitle("MP62-FACE Module Spec v0.1 - system links, power path, display path, and power sequencing", fontsize=12, fontweight="bold")
def box(x, y, w, h, t, fc, fs=8):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4", fc=fc, ec="k", lw=1.0))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs)
def arrow(x1, y1, x2, y2, c, t="", lw=2.0, ls="-", off=(0, 1.2), both=False, fs=7):
    ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="<->" if both else "->", color=c, lw=lw, ls=ls, shrinkA=0, shrinkB=0))
    if t: ax.text((x1 + x2) / 2 + off[0], (y1 + y2) / 2 + off[1], t, ha="center", va="bottom", fontsize=fs, color=c)
box(2, 58, 26, 14, "PSU (stock 450 W)\n12.1 V / 37.2 A main\n11 V / 5 W standby", "#fde68a")
box(48, 30, 40, 18, "BP (round base board, 6L)\nPCIe hub: J9 x16 -> Face P, J10 x4 -> Face S\nMCU: EEPROM read, budget check,\nFACE_PWR_EN, PERST# = PLTRST# AND FACE_RDY\nREFCLK fanout, 3V3_AUX per face", "#dbeafe")
box(48, 4, 40, 14, "CPU board (COM-HPC / i5-14500T)\nCPU-LINK -> BP: x16 + x4 Gen4", "#e9d5ff")
box(112, 56, 44, 18, "FACE P module (e.g. Navi 23 GPU)\nJ_PCIE MCIO 124 RA (x16)\nJ_DISP MCIO 74 RA (5 display links)\nJ_AUX GH15 | 12 V lugs | eFuse | ID EEPROM", "#fecaca")
box(112, 30, 44, 18, "FACE S module (e.g. ASM2824 + 4x M.2)\nJ_PCIE MCIO 124 RA (x4 rev A, x8 later)\nJ_AUX GH15 | 12 V lugs | eFuse | ID EEPROM\n(no display)", "#fecaca")
box(112, 4, 44, 16, "IOB (rear I/O board)\n2x DP 1.4 + HDMI 2.1 (FRL)\n4x USB-C (2 with DP alt-mode via mux)\nreceives DISPLAY-LINK on MCIO 74", "#d1fae5")
arrow(68, 18, 68, 30, "#6b21a8", "CPU-LINK (Mini Cool Edge 224)", off=(14, -1))
arrow(88, 44, 112, 62, "#7c3aed", "MCIO 124 16i twinax: x16 + SFF-9402 sideband\n(REFCLK0, PERST0#, CPRSNT#, CWAKE#, CLKREQ#)", off=(-4, 1), both=True)
arrow(88, 38, 112, 38, "#7c3aed", "MCIO 124 16i: x4 (x8 later)", off=(0, 0.6), both=True)
arrow(88, 47, 112, 70, "#059669", "", lw=1.2, ls="--", both=True)
arrow(88, 32, 112, 33, "#059669", "", lw=1.2, ls="--", both=True)
ax.text(97, 25.5, "J3/J4 -> J_AUX: GH15 management cables (dashed green)\n3V3_AUX, PRSNT#, PWR_EN, PWR_GOOD, SMBus, ALERT#, THERM, LED, USB2", fontsize=6.8, color="#059669", ha="center")
ax.plot([156.5, 160, 160], [64, 64, 12], color="#dc2626", lw=2.5); arrow(160, 12, 156.6, 12, "#dc2626", "", lw=2.5)
ax.text(161, 38, "DISPLAY-LINK\nMCIO 74 (8i)\ntwinax cable\nFace P -> IOB\n(bypasses BP)", fontsize=7, color="#dc2626", va="center")
arrow(28, 70, 112, 70, "#b45309", "12 V main: stock bus bar A (2 x T8 lugs) -> Face P  (<= 150 W, 12.5 A)", off=(0, 0.6), lw=2.5)
ax.plot([24, 24, 106], [58, 52, 52], color="#b45309", lw=2.5); arrow(106, 52, 112, 42, "#b45309", "", lw=2.5)
ax.text(66, 52.8, "12 V main: stock bus bar B -> Face S (<= 40 W rev A)", fontsize=7, color="#b45309", ha="center")
arrow(15, 58, 48, 40, "#92400e", "J2 harness: 12 V <= 5 A,\n11 V SB, PS_ON#, PWR_OK", lw=1.2, off=(-8, -2))
ax.plot([10, 10, 48], [58, 11, 11], color="#b45309", lw=2.5); ax.text(12, 12.2, "12 V main -> CPU board (bus bars)", fontsize=7, color="#b45309")
ax.text(80, 77, "NOT through the BP: face 12 V, display. NOT through CPU-LINK: any 12 V.", ha="center", fontsize=8, color="#7f1d1d", fontweight="bold")
# ---------- timing ----------
tx = fig.add_axes([0.06, 0.04, 0.9, 0.32]); tx.set_xlim(-5, 125); tx.set_ylim(-0.5, 9.5); tx.set_yticks([])
tx.set_title("Power sequencing (not to scale; times in ms unless noted). Modules never see the power button.", fontsize=9, fontweight="bold")
rows = [("3V3_AUX (BP -> module)", [(0, 0), (2, 1), (125, 1)]),
        ("EEPROM read / class check (BP MCU)", [(0, 0), (5, 0), (5, 1), (15, 1), (15, 0), (125, 0)]),
        ("12 V main at lugs (PSU on)", [(0, 0), (25, 0), (30, 1), (110, 1), (125, 1)]),
        ("FACE_PWR_EN (BP -> module)", [(0, 0), (35, 0), (35, 1), (100, 1), (100, 0), (125, 0)]),
        ("module rails (eFuse soft-start)", [(0, 0), (36, 0), (50, 1), (101, 1), (108, 0), (125, 0)]),
        ("FACE_PWR_GOOD (module, OD)", [(0, 0), (55, 0), (55, 1), (100.5, 1), (100.5, 0), (125, 0)]),
        ("REFCLK0 (BP)", [(0, 0), (52, 0), (52, 1), (98, 1), (98, 0), (125, 0)]),
        ("PERST0# deasserted (high)", [(0, 0), (75, 0), (75, 1), (95, 1), (95, 0), (125, 0)])]
for i, (n, pts) in enumerate(rows):
    y0 = 8.4 - i * 1.15
    xs = [p[0] for p in pts]; ys = [y0 + 0.75 * p[1] for p in pts]
    tx.plot(xs, ys, color="k", lw=1.3)
    tx.text(-4.5, y0 + 0.3, n, ha="left", va="center", fontsize=7, bbox=dict(fc="white", ec="none", pad=0.5))
for x, t, yy, ha in ((35, "EN", -0.35, "left"), (55, "PG <= 150 ms after EN", -0.35, "left"), (75, "T_PVPERL >= 100 ms", -0.35, "left"), (95, "shutdown: PERST# first ", -0.35, "right"), (100, " EN low -> PG low,\n rails off <= 10 ms", -0.35, "left")):
    tx.axvline(x, color="#2563eb", lw=0.6, ls=":")
    tx.text(x, yy, t, fontsize=6.3, color="#1d4ed8", va="bottom", ha=ha)
tx.text(53, 1.75 + 0.0, "", fontsize=6)
tx.text(58, 8.4 - 6 * 1.15 + 0.95, "REFCLK stable >= 100 us before PERST# release", fontsize=6.3, color="#1d4ed8")
tx.set_xticks([])
fig.savefig(OUT); print("wrote", OUT)
