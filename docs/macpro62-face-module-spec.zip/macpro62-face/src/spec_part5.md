
## 13. Conflicts with spec v0.2 and host change requests [v0.1]

| ID | Conflict | Resolution in v0.1 | Action |
|---|---|---|---|
| **C-1** | v0.2 calls J_PCIE "124-pin (8i)". In SFF-TA-1016 the 124-position MCIO is the **16i** (2 × 62 contacts). v0.2's TE 1-2381578-9 is a 16i **vertical** part, which is too tall for a module (h ≈ 15–20 mm, and a vertical cable exit has no route). | One **MCIO 124 RA (16i)** per face (§4.1). | Fix v0.2 wording. |
| **C-2** | BP J9/J10 cable landings sit at ±4.6 mm from the face centreline, which is module X 47.4 (Face P) and X 56.6 (Face S), against J_PCIE at X 43.5. The BP placeholder footprint rows (3.4 / 5.2 mm) also differ from SFF Table A-2 (0.575 / 3.525). | Module position fixed at X 43.5. | **CR-2:** move both BP receptacles to s = +8.5 mm (rotational symmetry), and replace the BP footprint with the SFF one. |
| **C-3** | v0.2's OCP FLEXIO logical map does not match commodity MCIO cables. | **SFF-9402** sideband positions. USB2 moves to AUX; PWRBRK# dropped (§4, §7). | Update the BP schematic. |
| **C-4** | v0.2 AUX = GH14. | **GH15** (adds MOD_LED#). | BP J3/J4 and the `face_aux` schematic → SM15B-GHS-TB. |
| **C-5** | v0.2 power classes and limits (Face P 130 W / Face S 35 W). | Classes renumbered; **Class 3 = 150 W**; Face S 40 W (§6.2). | Update the architecture spec §5. |
| **C-6** | v0.2 total budget 325–335 W. | **350–360 W** sustained, still ≤ 405 W (90 % of 450 W) (§6.3). | Measure PSU OCP (MF-11). |
| **C-7** | v0.2 puts the face centre ≈ 24.5 mm off-axis. That cannot fit inside an R 80 shell at 55 mm from the axis. | X_AX = 52 assumed; tolerance ±6 mm (core side) / ±4.5 mm (outer side). | MF-3. |
| **C-8** | LCSC stock: MCIO 124 RA G97R24332HR has 0; MCIO 74 RA G97R22332HR has 4. | Keep the parts and allow JPC/Molex/TE equivalents. | Order early, or consign parts to JLC. |
| **C-9** | The cable length needed is ≈ 30–60 mm; commodity MCIO cables are ≥ 150 mm. | Custom-length cables (OQ-1). | M4. |
| **C-10** | v0.2 allowed ≤ 4 DP streams. | **5 links** on DISPLAY-LINK (Navi 23 has 5 PHYs). | IOB spec. |
| **C-11** | v0.2 used an IPMI FRU as the ID format. | Raw MP62 descriptor at 0x0000; FRU optional at 0x0100 (§8). | BP/EC firmware. |
| **C-12** | v0.2 gives the peak window as both 10 s and 10 ms. | **10 ms** (§6.2). | Fix v0.2. |
| **C-13** | Core boss pattern from the scan is **75.2 × 50.0 mm**, but the board holes are 74.0 × 50.0 and the bracket 74.3 × 49.7. | Keep Ø5.0 holes on 74.0 × 50.0. M3 float of 1.0 mm radial absorbs the +0.6 mm per side. | **Calipers** on the bosses and stock board holes. |
| **C-14** | The v0.2-era estimate Z_c ≈ 2.6 mm (core-side clearance) and TZ1 40 × 40 / TZ2 84 × 59. | Replaced by the **measured G = 4.5 ± 0.5 mm** and the traced die/strip pads (§3.3). Consequences: core-side parts ≤ 3.5 mm; a Navi 23 needs a ≈ 1.9 mm Cu die shim; VRAM and power stages need spreaders or thick pads. The bus-bar lug sites lie outside the black plate. | Measure G to ±0.05 mm and p (D3). |
| **C-15** | KO-F3 (mirrored MEG-Array bosses) was provisional. | **Released**: the scan shows no bosses there. New KO-F5 (core tab). **Rod resolved (Aidan, 2026-10-01):** it is one of the two long standoff screws at the core's bottom end that carry the base board at its gold holes G1/G2 (±49 mm). The photo's local scale matches the 98.25 mm hole pitch, and the other symmetric hole pair (S1/S6, 105.4 mm) does not fit. Scan orientation (scan top = module bottom) remains an inference. | Aidan to confirm the orientation and identify the tab. |
| **C-16** | M1 (Aidan: GPU-board bottom edges ≈ 15 mm above the BP) vs the standoff geometry. If the BP seats on the standoff tips, the scan puts the tip, and so the BP top, at module Y ≈ −23.5, i.e. the board edge ≈ 23.5 mm above the BP. The photo gives ≈ 18.4 ± 1.5 mm from the core end face to the tip. | Normative v0.1 keeps **≥ 15 mm** (worst case for the cable bend). Cable lengths (C-9, OQ-1) shall be checked at both 15 and 23.5 mm. | Calipers: standoff protrusion and the GPU-board edge → BP top on the assembled machine (M1c). |
| **C-17** | v0.1 draft and v0.2 put the bus-bar lugs at one position (X ≈ 97). Aidan: the stock GPU 2 board is mirrored, so the faces have their lugs on opposite sides. | **Both sites on every module** (site A + mirror site B, in parallel, §6.4.1). KO-F2B, KO-F5B and the mirrored rod added; template J22/J23 and rule areas added. | M5b: which face (P/S) uses which site; polarity per face (M5). |
| **C-18** | BP J9/J10 assume face normals at 30° / 150° from the hole axis. The stock base board's GPU connector fields run tangentially at ±46.6° (r ≈ 48, polar 42° / 138°; arch spec v0.2 §3.13), which hints that the normals are ≈ 42° / 138°. | No module change: the module frame is face-relative. The J_PCIE cable length window (C-9) shall cover a ±12° rotation of J9/J10. | M2c: GPU-board plane angle per face (arch spec §11.3). |

## 14. Open questions and measurements [v0.1]

### 14.1 Open questions

| ID | Question |
|---|---|
| OQ-1 | Custom-length MCIO 16i cable (30–60 mm): which vendor, MOQ, cost; or move Y_mate up in MECH 0x0002? |
| OQ-3 | Which sidebands do the commodity MCIO cables actually wire (per vendor and per part number)? |
| OQ-5 | MCIO RA footprint: confirm which side of datum Y the pad rows lie (Amphenol drawing), before fabrication. |
| OD-6 | Face P assignment: which physical face is P (the PSU-side face or the other)? This affects the bus-bar polarity and the cable runs. It no longer affects the lug layout (both sites are fitted, §6.4.1). |
| OQ-7 | Face S x8: which host revision provides x8, and from where (CPU or switch)? |
| OQ-8 | HDMI 2.1 retimer part for the IOB (TDP2004-class [Unverified]) and its FRL 12G support. |
| OQ-9 | MP62 community vendor-ID registry (`vid_space` 2): who runs it? |
| OQ-10 | Does the stock bus bar need a threaded insert on the module, and what is its ampacity? |

### 14.2 TO MEASURE

| ID | What | Why |
|---|---|---|
| **G** | Standoff height per core to **±0.05 mm** (now 4.5 ± 0.5) | Die shim and pad stack |
| **D3** | Pad protrusion **p** of the die and strip pads above the black plate; flatness | Contact heights (§3.3) |
| **MF-1** | Height of the frame/rim around the plate relative to the plate | H-CORE-OUT limit (provisional 1.0 mm) |
| Scan | Orientation of the core scan (top = module bottom?) | All core-side zones |
| Calipers | Boss pattern (75.2 × 50.0 from the scan) and boss OD; board holes on a stock board | C-13, KO-F1 |
| Tab | Identity and height of the tab (X 98–102, Y 122–138); is it mirrored on the other face? | KO-F5A/B |
| **M1c** | Base-board standoff screws: protrusion beyond the core end (photo ≈ 18.4), shaft/collar Ø, thread; GPU-board bottom edge → BP top on the assembled machine | C-16; cable bend room |
| **M1 / M1b** | Shell inner radius R_i, plane distance from the axis, base ring/fillet | Outer envelope h(x) |
| **MF-3** | Lateral offset X_AX of the face centreline from the axis | Envelope; J_DISP margin 0.7 mm |
| **M4** | BP → module cable path, bend radius, length | OQ-1 |
| **M5** | Lug positions, polarity **per face**, thread, ampacity | §6.4, KO-F2A/B |
| **M5b** | Which face (P or S, and the scanned one) has its bus bar at site A (X ≈ 97) vs site B (X ≈ 7) | §6.4.1; single-site modules (MECH 0x0002) |
| **M2c** | Face-normal angle of each GPU board from the base-board hole axis (stock connector fields suggest ≈ 42° / 138°) | C-18; BP J9/J10 placement and cable length |
| **M9** | Display cable path from the module to the IOB | §9 |
| **MF-4** | Bracket height; does the ring touch the board? | KO-B1v |
| **MF-5** | Screw thread, length, shoulder; boss OD | §3.2 |
| **MF-8** | Clearance above the module top edge to the fan/duct | J_12V_ALT |
| **MF-11** | PSU OCP and transient response | §6.3 |
| **MF-12** | Stock board thickness | Screw/spring stack |
| MXM | Die position on the chosen MXM card, and GOP/output routing | §11.1 |
| ~~MF-2~~ | ~~Core flatness at MEG positions~~ | **Resolved by the core scan** (KO-F3 released) |

## 15. Parts and prices (LCSC, checked 2026-10-01) [v0.1]

| Function | Part | LCSC | Price | Stock |
|---|---|---|---|---|
| J_PCIE MCIO 124 RA | Amphenol G97R24332HR | C4867471 | $9.59 @1 / $9.37 @10 | **0** |
| J_DISP MCIO 74 RA | Amphenol G97R22332HR | C5433520 | $7.94 @1 / $6.88 @10 | 4 |
| J_AUX GH15 RA | JST SM15B-GHS-TB(LF)(SN) | C265027 | $0.87 | 1,130 |
| 12 V eFuse | TI TPS259824ONRGER (LNR variant C2155879, $4.34) | C2155766 | $5.90 | 1,916 |
| Temp sensor | TI TMP1075DSGR | C2870250 | $0.50 | — |
| ID EEPROM | BL24C64A-SFRC | C111004 | $0.19 | — |
| J_12V_ALT (optional) | Molex 45586-0005 PCIe 8-pin | not stocked | — | — |
| (6-pin alternative) | Molex 45558-0003 | C7545781 | $1.07 | — |
| Lug insert (if needed) | Würth REDCUBE 7466003R | not stocked | — | — |
| Cable, PCIe | MCIO 16i, custom length | — | ≈ $60–80 | — |
| Cable, display | MCIO 8i straight 0.5 m | — | ≈ $46–52 | — |

**Interface kit** (connectors + eFuse + EEPROM + sensor, no cables): ≈ **$24 for a GPU module**, ≈ **$17 for a storage module**.

## 16. Sources [v0.1]

- SFF-TA-1016 Rev 1.3 (MCIO connector, cable, Annex A footprints, Tables 5-4/6-3/A-1/A-2).
- SFF-9402 Rev 1.1 (multi-protocol internal cable pinouts for SFF-TA-1016).
- JPC MCIO RA drawing; Amphenol G97R24332HR / G97R22332HR product pages (LCSC).
- `macpro62-architecture-spec-v0.2.md` §4, §5, §7 (the superseded face spec), REF-S1 (Apple service references: screws 923-0708, 923-0716, standoffs 923-0690).
- BP KiCad project `kicad/macpro62-backplane/` (J9/J10 positions, footprints, stackup).
- Fusion export `gpu_board_outline.dxf`; `bracket/gpu_board/summary.md`; `bracket/summary.md`; `bracket/gpu_bracket_keepout.dxf`.
- **Core GPU-face scan** (Aidan, 2026-10-01), traced in `bracket/core_gpu_face/` (script, JSON, DXF, overlays).
- **Aidan's measurement:** core standoff height 4.5 ± 0.5 mm (2026-10-01).
- **Aidan's information (2026-10-01):** the base board mounts on long standoff screws at the core's bottom end (photo `bracket/core_photo/core_flat_photo.jpg`, the scan's "rod"); the stock GPU 2 board is mirrored relative to GPU 1 at its 12 V bus-bar screws.
- Linux amdgpu DCN 3.0.2 (Navi 23 display controller: 5 PHYs).
- TI TPS25982, TMP1075; BL24C64A; JST GH datasheets.
