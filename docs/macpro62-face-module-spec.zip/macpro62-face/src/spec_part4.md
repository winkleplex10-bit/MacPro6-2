
## 8. ID EEPROM and thermal sensor [v0.1]

### 8.1 Hardware

| Item | Rule | Part (LCSC) | Status |
|---|---|---|---|
| EEPROM | **24C64 class** (≥ 24C32; **16-bit word addressing is required**, so a 24C02/24C16 is not allowed) at **7-bit address 0x50** on the AUX SMBus (3V3_AUX domain). Readable in S5. | **BL24C64A-SFRC**, C111004, ≈ $0.19 | [Proposal] |
| Write protect | WP **shall** be strapped high (protected) on production modules, with a 0 Ω/jumper to unprotect for programming. `flags.bit3` declares it. | — | [Proposal] |
| Temperature sensor | LM75/TMP75 register-compatible at **0x48** (`sensor_addr`), placed at the hot zone (within 10 mm of the die-pad footprint or the hottest strip-pad part). ALERT output in comparator mode drives **THERM_ALERT#** (AUX). | **TMP1075DSGR**, C2870250, ≈ $0.50 | [Proposal] |
| Other SMBus devices | Allowed at 0x51–0x57 and 0x49–0x4F only. 0x50 and 0x48 are reserved for the items above. | — | [Proposal] |

### 8.2 Memory map

| EEPROM offset | Content |
|---|---|
| **0x0000** | **MP62 Module Descriptor v1** (§8.3), ≤ 512 B, CRC-protected. **Required.** |
| 0x0100 | Optional IPMI FRU (Platform Management FRU v1.0), for tools that expect one. It is informative only; the host uses the MP62 descriptor. (A descriptor longer than 256 B moves this to 0x0200.) |
| 0x0400 – end | Vendor area (calibration, VBIOS settings, logs). |

### 8.3 MP62 Module Descriptor v1 (little-endian)

{{EEPROM_TABLE}}

### 8.4 Host behaviour and validation

1. The host reads the descriptor in S5 (from 3V3_AUX), **before** asserting FACE_PWR_EN.
2. The host **shall refuse power** (it keeps FACE_PWR_EN low and blinks the slot LED) if any of these hold:
   - bad magic, length or CRC
   - `mech_rev` unknown
   - the slot bit is not set in `slot_mask`
   - `p_sustained_w` is above the slot budget (§6.2: Face P 150 W, or 130 W until P3 thermal validation; Face S 40 W)
   - `v12_src_mask` is 0
   - `aux_s5_mw` > 50 or `aux_s0_ma` > 1000
   - `t_pg_ms` > 150
   - `hotspot_dx/dy` outside R3
   - `h_core_max` > 35 + `plane_offset` (in 0.1 mm units: G_min + offset − 0.5)
3. A missing or blank EEPROM gives **Class 0 only** (3V3_AUX, no 12 V).
4. Reference implementation: `macpro62-face/tools/mp62_eeprom.py` (encoder, `check` validator, CRC-16/CCITT-FALSE). Examples are in `eeprom_examples/`:
   - `example_mxm_rx6600.bin`: 164 B, GPU, Face P, x8 Gen4, 110 W, 4 display links, plane_offset 5.0 mm.
   - `example_storage_asm2824.bin`: 159 B, storage, Face P or S, 40 W.
   Both pass `check`.
5. **Vendor IDs:** `vid_space` 0 is for development. A community registry (`vid_space` 2) is an open question (§14).

## 9. Display path (DISPLAY-LINK) [v0.1]

### 9.1 Decision [Proposal]

**DISPLAY-LINK is a second right-angle MCIO receptacle on the module, the 74-pin (8i) size: Amphenol G97R22332HR (LCSC C5433520, $7.94 @1 / $6.88 @10, stock 4).** A commodity **MCIO 8i twinax cable** (straight, 0.3–0.5 m; ≈ $46–52 retail for 0.5 m) runs straight from the module to the IOB. Display signals never pass through the BP.

Why this option:
- The connector family and 85/100 Ω twinax are already used for PCIe, so there is one footprint family, one cable vendor, and one assembly process.
- 16 differential pairs at ≥ 16 Gb/s (MCIO is rated to PCIe Gen5/6), which is enough for HBR3 and HDMI 2.1 FRL 12G.
- Plenty of sideband pins for AUX/HPD of 5 links.
- JLC can assemble it, and the low-profile RA part fits the outer envelope (8.2 mm mated; h(96.5) = 8.9).

### 9.2 Alternatives considered

| Option | For | Against | Verdict |
|---|---|---|---|
| **MCIO 74 RA + MCIO 8i cable (chosen)** | Same family as J_PCIE. Commodity cables. 16 pairs + sidebands. | LCSC stock is low (4). Cables cost ≈ $46–52. | **Chosen** |
| SlimSAS 8i (SFF-8654) RA, e.g. Amphenol U10A474240T | Cheaper cables (≈ $20); very common | Not at LCSC. Lower rated speed (12 Gb/s SAS). Taller. | Allowed as a v0.2 option |
| Custom flex / FPC | Thin and cheap at volume | Needs a custom design per path. 100 Ω control over 0.3–0.5 m is marginal at HBR3/FRL. Fragile. | Rejected |
| eDP-style micro-coax (I-PEX 40-pin class) | Thin, laptop-proven | ≤ 4 lanes per cable, so 2–3 cables are needed. Hand-terminated. | Rejected |
| Through the BP (spare MCIO pairs) | No extra cable | Puts display on the PCIe cable. Long path BP → CPU board → IOB. Needs BP changes and redrivers. | Rejected (non-goal, §1) |

### 9.3 Pinout (module end; IOB end row-swapped by the straight cable)

Main pairs (100 Ω, AC-coupled **on the module**):

{{DISP_MAIN}}

Sideband (AUX ±, HPD, presence):

{{DISP_SB}}

- **Link 0** = DP 1.4 4-lane (rear DP #1). **Link 1** = DP 1.4 4-lane (rear DP #2).
- **Link 2** = HDMI 2.1 / DP++ 4-lane (rear HDMI, through the IOB retimer). Its AUX pins carry DDC under the DP++ convention.
- **Link 3** and **Link 4** = DP alt-mode 2-lane each (USB-C #1/#2, through the IOB mux). If `disp_flags.bit1` is set, Link 3 is 4-lane and Link 4 is absent.
- **DLINK_PRSNT#** (A30): the module ties it to GND, so the IOB can detect the cable.
- Full contact list: `pinouts/mp62-face-v0.1_mcio74_displaylink_module-end.csv`.
- Navi 23 has 5 display PHYs (DCN 3.0.2), so all 5 links can be driven [Sourced: Linux amdgpu `dcn302`]. Many MXM cards route fewer (`disp_count`).

### 9.4 Display-link descriptor (EEPROM 0x34, 5 × 4 bytes)

| Byte | Meaning | Codes |
|---|---|---|
| 0 | type | 0 none, 1 DP, 2 DP++ (dual-mode), 3 HDMI TMDS, 4 HDMI FRL, 5 DP alt-mode (USB-C) |
| 1 | lanes | 1, 2, 4 |
| 2 | max rate | DP: 1 RBR, 2 HBR, 3 HBR2, 4 HBR3, 5 UHBR10, 6 UHBR13.5, 7 UHBR20. HDMI: 0x10 TMDS 3.4G, 0x11 TMDS 6G, 0x12 FRL 3×3, 0x13 FRL 3×6, 0x14 FRL 4×6, 0x15 FRL 4×8, 0x16 FRL 4×10, 0x17 FRL 4×12 |
| 3 | flags | bit0 HPD wired, bit1 AUX/DDC wired, bit2 lane-polarity swap used, bit3 boot (GOP) display candidate |

### 9.5 Electrical rules

- 100 Ω ±10 % differential. AC caps (DP 75–200 nF) on the module, within 10 mm of the connector or the source.
- Module routing from the GPU to J_DISP **≤ 100 mm** [Estimate], with intra-pair skew ≤ 0.15 mm.
- AUX: 100 nF series caps and the source bias (DP 1.4) on the module.
- HPD: an input to the module at 3.3 V; the IOB level-shifts and buffers from 5 V-tolerant connectors.
- **No DP_PWR, no 5 V** on the cable; the IOB generates DP_PWR and HDMI 5 V.

### 9.6 IOB side (informative, host-side spec)

- HDMI 2.1 retimer on Link 2 (TI TDP2004-class [Unverified]); ESD on every port.
- DP_PWR and HDMI 5 V with current limit.
- USB-C: a DP alt-mode mux (TUSB1046-class) + PD controller, which takes Link 3/4 and the USB data.
- **Source selection** between the iGPU and the face GPU (architecture spec OD-2) stays an open host decision. DISPLAY-LINK does not depend on it.
- The IOB connector footprint is the same MCIO 74 RA. Row A on the module meets row B on the IOB (straight cable, SFF-9402 convention). Lay out the IOB from the row-swapped CSV.

## 10. Thermal [v0.1]

| Item | Rule | Status |
|---|---|---|
| Heat path | All module heat goes into the core through the **die pad** (main source) and the **4 strip pads** (secondary, §3.3). No module fans (§1). | [Sourced: scan]; [Proposal] |
| Hot spot | Centroid within **R3 of (52.0, 69.5)**. That is the die-pad centre (scan: 51.85, 69.43) and the bracket ring/spring load point. Declared as `hotspot_dx/dy`. | [Proposal] |
| TIM | Die pad: grease or phase-change, bondline 0.05–0.15 mm, preload from interference δ = 0.05–0.2 mm (§3.3.2). Strip pads: soft thermal pads ≥ 6 W/m·K, compressed thickness 0.5–2.0 mm. | [Proposal] |
| Dissipation rule | Every part dissipating > 2 W sits under a pad (§3.3.3). **Exception (C-20):** removable, self-throttling devices in standard sockets on the outer side (M.2 NVMe SSDs) may be air-cooled in the board-to-shell gap, optionally with heatsinks within h(x); airflow there is TO MEASURE (MF-14). | [Proposal] |
| Sensor | TMP1075 at 0x48, at the hot zone. The host reads it every ≤ 1 s and maps it onto the fan curve with the `t_target_c` knee. | [Proposal] |
| Limits | `t_target_c` (fan knee), `t_warn_c` (module asserts THERM_ALERT#), `t_crit_c` (module asserts THERM_TRIP#, the host drops FACE_PWR_EN within 100 ms). Defaults for a GPU: 70 / 90 / 100 °C. Storage: 55 / 70 / 85 °C. | [Proposal] |
| Throttle | When THERM_ALERT# is asserted, the module **shall** cut its own power by ≥ 25 % within **100 ms** (GPU power cap, or NVMe power state). The host raises the fan to 100 %. **Storage modules without a management MCU (C-21):** the host OS/firmware applies the NVMe power-state limit (and the SSDs throttle themselves); the module only reports through THERM_ALERT#/THERM_TRIP#. | [Proposal] |
| Power cap | Face P is capped at **130 W** until the P3 thermal test passes; then **150 W**. Face S: 40 W. | [Proposal] |
| P3 thermal test module | A module_type 7 board: resistive heaters on the die-pad footprint (≈ 24 × 22 mm) and on the four strip footprints, 0–150 W programmable, with 6 thermistors. Measures the core ΔT/W and the pad stack, and checks the pressure paper. Gate for raising the 130 W cap. | [Proposal] |

## 11. Reference modules (informative) [v0.1]

### 11.1 MXM 3.1 carrier (Face P): X-VSION RX 6600 (Navi 23) MXM

- The carrier PCB holds J_PCIE, J_DISP, J_AUX, the lug sites, eFuse, EEPROM and sensor. The MXM 3.1 Type-B card sits on the **core side** of the carrier, die facing the core.
- `plane_offset` ≈ 4–6 mm [Estimate], so that G_eff = 4.5 + plane_offset suits the MXM connector stack plus the card's die height. The die stack must then reach the die pad with a shim, using the §3.3.2 formula with G_eff.
- **The MXM die position is TO CHECK.** The MXM die must sit within R3 of (52, 69.5) with the card placed on the carrier. If it cannot, the carrier must shift the card (MXM 82 × 105 mm fits inside the plate area).
- Clamp path: the bracket clamps the carrier; the die load goes through the MXM card's own heatsink holes, with spacers to the carrier. Strips cool the MXM VRAM/VRM through pads if their positions line up; otherwise they need a Cu spreader.
- Lanes: x8 Gen4 (Navi 23 limit). Display: up to 4 links routed out of MXM (outputs and GOP TBD per card). Power: ≈ 100–110 W class 3.
- EEPROM example: `example_mxm_rx6600.bin`.

### 11.2 Native Navi 23 module (Face P)

- Layout as on a stock D-series board: the GPU at the centre of the die pad, GDDR6 and power stages under the strips (§3.3.3), and the Cu die shim ≈ 1.9 mm (from the measured G).
- 8–10 layers. Inductors either ≤ 3.0 mm on the core side or placed on the outer side within h(x).
- Lanes x8 Gen4. 5 display links. 130/150 W.

### 11.3 Storage module (Face S or P): SM-1, ASM2824 + 4 × M.2 [update 3]

Full design: `macpro62-storage-board-plan.md` and `kicad/macpro62-storage-face/` (rev A0 floorplan, DRC 0/0; schematic ERC 0/0; routing not started).

- **Why a switch:** Face S is CPU PEG60 Gen4 x4, which cannot bifurcate, so 4 SSDs need a switch. The **ASMedia ASM2824** (Gen3, x8 up / 4 × x4 down, internal downstream clock buffer, SRIS) is the only cheap, JLC-assemblable choice (JLC C9900092023; price TBD, ≈ $15–40 [Unverified]). Gen4 switches (PM40028, PEX88024) cost $164–323, are NDA, and have no stock. The upstream x8 is wired to J_PCIE lanes 0–7, so a future x8 host doubles throughput with no module change. Bandwidth today: Gen3 x4 ≈ 3.5 GB/s shared.
- **Core side:** the ASM2824 sits centred on the die pad with a **3.0 mm soft gap pad** (≈ 1.1 K/W, ≈ 5 K at 4 W), with no Cu block and no preload. Switch support parts (core buck, crystal, SPI flash, PERST# buffers, TMP1075 0x48) are all ≤ 2 mm tall.
- **Outer side:**
  - 3 × 2280 columns at X 26.5 / 52 / 77.5 (sockets at Y 108.5–115, cards toward −Y to Y 28.5) plus 1 × 2280 across the top (Y 115–137).
  - Sockets are LOTES APCI0107-P001A (H4.2, C841661), with SMT M2 standoffs at 2280 (2230/2242/2260 pads DNP).
  - Under-card host parts are ≤ 1.6 mm.
  - Standard M.2 sockets cannot go on the core side (≈ 4.65 mm > 3.5).
- **Bracketless (C-19, approved 2026-10-01):** 4 × 2280 fit only without the X-bracket. With the bracket, ≈ 2 × 2280 + 1 × 2260. SM-1 is held by 4 low-head screws (wafer / ultra-thin head, head + washer ≤ 1.6 mm) straight into the bosses, so the edges of SSD0/SSD2 clear the heads with any 2280 SSD. The part number follows MF-13 (thread, length).
- **J_AUX** moved to **(16.5, 20.5)**. That is the "should" position minus 6 mm in Y, to clear SSD0.
- **Power:**
  - lugs (both sites) → LM74700 + N-FET reverse block → TPS259824 (I_LIM ≈ 5 A, inrush ≤ 1 A) → TPS56C215 12 A buck → 3V3_SSD (4 × 2.5 A)
  - VDD_CORE from a 3 A buck; voltage per the ASM2824 datasheet (NDA)
  - Budget: ≈ 35.6 W worst sustained, ≈ 41.5 W 10 ms peak (≤ 52 W); declared **40 W, Class 1**.
- **Thermal sensors:** TMP1075 0x48 drives THERM_ALERT#. A second TMP1075 at **0x49** drives THERM_TRIP# from its power-on default (80 °C comparator), so it needs no software.
- **RAID:**
  - **No driverless, bootable hardware RAID chip is orderable.** The Marvell 88NR2241 presents one inbox-driver NVMe drive (HPE NS204i-p, Dell BOSS-N1, HighPoint SSD6202A), but it is NDA-only, has no distribution, and macOS is unverified.
  - Broadcom tri-mode and HighPoint parts need drivers that macOS lacks or that cannot boot.
  - macOS cannot boot AppleRAID/SoftRAID volumes (Big Sur and later).
  - **Reference configuration:** boot from one SSD; AppleRAID/SoftRAID across the others as data volumes. Each SSD behind the switch is individually bootable (native NVMe; Sonnet M.2 4x4 precedent).
  - A future 88NR2241 variant (SM-1R) keeps the outline, sockets and power band.
- J_DISP not fitted. EEPROM example: `example_storage_asm2824.bin`.

## 12. Compliance checklist [v0.1]

| # | Requirement | Section |
|---|---|---|
| 1 | Outline 104 × 166 mm, chamfers and blends as in the DXF; ±0.2 mm | 3.1 |
| 2 | 4 × Ø5.0 holes on 74.0 × 50.0 at (52, 69.5); not smaller than Ø5.0 (core bosses at 75.2) | 3.2 |
| 3 | Edge band 1.0 mm free of parts; copper ≥ 0.5 mm from the edge | 3.1 |
| 4 | Core side: parts ≤ 3.5 mm over the plate, ≤ 3.0 mm under strips (non-contact), ≤ 1.0 mm outside the plate | 3.3 |
| 5 | Die stack = G − p + δ (δ 0.05–0.2), checked against the measured G of the target core | 3.3 |
| 6 | Strip-contact parts: top = G − p − t_pad, t_pad 0.5–2.0 mm | 3.3 |
| 7 | KO-F1 Ø11, KO-F2A/B, KO-F5A/B free of parts | 3.3 |
| 8 | Outer side: KO-B1, KO-B2, KO-B1v rules | 3.4 |
| 9 | Outer height ≤ h(x) (or the simplified zones) | 3.4 |
| 10 | J_PCIE at X 43.5, mating face Y 14.5, opening −Y, ±0.5 mm | 3.5 |
| 11 | J_DISP (if fitted) at X 82.0, Y 14.5, opening −Y | 3.5 |
| 12 | J_AUX GH15 at (16.5, 26.5), opening −X | 3.5 |
| 13 | **Both** lug sites (A: J20/J21; B mirror: J22/J23) fitted, Ø3.2 / Ø8.8, wired in parallel, ≥ 15 A per path | 6.4.1 |
| 14 | PCIe lane and sideband map per SFF-9402 (§4 tables); AC caps on the module TX | 4 |
| 15 | Works at x1 minimum; trains at the width declared in the EEPROM | 4 |
| 16 | AUX pinout GH15 per §5; USB2 optional (`flags.bit0`) | 5 |
| 17 | Sustained/peak power within the class and the slot budget | 6.2 |
| 18 | 12 V eFuse (TPS25982-class), inrush ≤ the declared value, PG within 150 ms | 6.5 |
| 19 | 3V3_AUX: ≤ 1 A in S0, ≤ 50 mW in S5 | 6.6 |
| 20 | Power sequencing per §6.7; outputs high-Z when unpowered | 6.7 |
| 21 | EEPROM at 0x50 with a valid MP62 descriptor (passes `mp62_eeprom.py check`), WP strapped | 8 |
| 22 | Sensor at 0x48 at the hot zone; THERM_ALERT#/THERM_TRIP# behaviour | 8, 10 |
| 23 | Hot-spot centroid within R3 of (52, 69.5) | 3.2, 10 |
| 24 | Throttle ≥ 25 % within 100 ms of THERM_ALERT# | 10 |
| 25 | DISPLAY-LINK per §9 (pinout, 100 Ω, AC caps, DLINK_PRSNT#), declared in the descriptor | 9 |
| 26 | No fans; no 5 V or DP_PWR on DISPLAY-LINK | 1, 9 |
| 27 | Offset modules declare `plane_offset`, and keep within the reduced envelope | 3.7 |
