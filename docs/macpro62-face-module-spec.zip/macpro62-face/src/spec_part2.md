
## 3. Mechanical (MP62-FACE-MECH 0x0001) [v0.1]

### 3.1 Outline

| Item | Value | Status |
|---|---|---|
| Size | **104.0 × 166.0 mm**, 1.6 mm reference thickness | [Sourced: Fusion `gpu_board_outline.dxf`; `bracket/gpu_board/summary.md`] |
| Bottom corners | Chamfer 17.0 (X) × 13.0 (Y), with **R10 blends** at both ends of each chamfer. Line from (3.925, 9.998) to (14.311, 2.056); flat bottom edge X 20.385–83.615 | [Sourced: Fusion DXF] |
| Top corners | R5 | [Sourced] |
| Thickness | 1.6 mm nominal (range 1.42–2.0 mm). The MCIO SMT receptacle needs ≥ 1.42 mm [v0.2 N41]. The stock board thickness is TO MEASURE (MF-12), because the screw/spring stack depends on it | [Proposal] |
| Edge band | 1.0 mm from the outline: **no components** either side. Copper ≥ 0.5 mm from the edge (template DRC) | [Proposal] |
| Outline tolerance | ±0.2 mm (JLC routing) | [Proposal] |

The outline is symmetric about X = 52, so whether the Fusion export was drawn from the core side or the outer side does not matter.

### 3.2 Mounting holes and retention

| Item | Value | Status |
|---|---|---|
| Holes | **4 × Ø5.0 mm** at **(15.0, 44.5), (89.0, 44.5), (15.0, 94.5), (89.0, 94.5)**: a 74.0 × 50.0 mm pattern centred on **(52.0, 69.5)** | [Sourced: Fusion DXF] |
| Plating | Should be plated (Ø9.0 pad both sides) and bonded to module GND, for chassis bonding through the core. May be NPTH if the module isolates GND (declare it in the documentation). | [Proposal] |
| Stock bracket | X-shaped spring bracket on the **outer side**. Eyelets **Ø5.66** at **(±37.15, ±24.85)** about the ring centre (74.3 × 49.7), eyelet OD 8.92. Centre ring ID 25.52 / OD 34.21. Arms 4.5 mm wide at ±33.8°. Envelope 83.48 × 58.89 | [Sourced: `bracket/summary.md`, scan fit] |
| Screws | Stock 4 × T10 (923-0708, 1.2 N·m) into core standoffs 923-0690, through the bracket eyelets [Sourced: v0.2 REF-S1 p.342]. Thread, length and shoulder diameter TO MEASURE (MF-5). | |
| Fit check | The board holes are 74.0 × 50.0 and the bracket holes 74.3 × 49.7. The ±0.15 mm differences are absorbed by the Ø5.66 eyelet versus the screw (≥ 0.3 mm float, assuming an M3-class shank) [Inference]. | |
| **Core standoff bosses** | 4 raised bosses on the core GPU face, **height 4.5 ± 0.5 mm** above the copper/plate surface, OD ≈ 9 mm, screw hole ≈ Ø3.3–3.5 (M3 class?). Traced positions (module frame): (14.40, 44.66), (89.67, 44.34), (14.44, 94.45), (89.49, 94.56). That is a **75.2 × 50.0 mm** pattern, against 74.0 × 50.0 for the board holes (+1.2 mm in X, ≈ 0.6 mm per side). An M3 shank in a Ø5.0 hole has 1.0 mm radial float, so the board still fits, but the board holes **shall not** be made smaller than Ø5.0. Confirm with calipers (conflict C-13). | Height [Sourced: Aidan, measured]; positions [Sourced: core scan `bracket/core_gpu_face/`, ±0.5 mm, scale ±0.4 %] |
| Hot-spot location | The module's **hot-spot centroid shall lie within a Ø6 mm circle (R3) around (52.0, 69.5)**. That is the centre of the bracket ring, which is the spring load point, and of the core contact area. Declared in the EEPROM (`hotspot_dx/dy`). | [Proposal] |

### 3.3 Core side (F): gap, contact zones, keep-outs and height

The core GPU face was traced from Aidan's flatbed scan (`bracket/core_gpu_face/`: calibrated against the rulers at 3.95 px/mm ≈ 100 dpi, scale ±0.4 %, features ±0.5 mm). It has a black plate carrying one **die pad** and four **45° strip pads**, plus four standoff bosses. Drawing panel (a) and the DXF layers `CORE_*` show them in the module frame.

> **Orientation [Inference, confirm with Aidan]:** the scan's top edge is the module's **bottom** edge (the BP end). Only in that orientation do the frame and flange extents match the 166 mm board, with the board sitting in the frame pocket at 1.4–2.1 mm lateral clearance. After rotation (0.58°) and registration of the boss centroid to (52.0, 69.5), the die pad centroid lands at (51.85, 69.43), within 0.2 mm of the bracket ring centre. That agreement supports the inference.

> **Mirrored faces [Sourced: Aidan, 2026-10-01; geometry Inference]:** the stock GPU 2 board is a mirror image of GPU 1 at its 12 V bus-bar screws, so the two faces have their lugs on opposite sides. The scan shows one face. Every asymmetric core-side zone traced from it (lug tongue KO-F2, core tab KO-F5, standoff rod) is therefore reserved **at both its traced position and its mirror about X = 52**. Which physical face (P or S) is the scanned one is TO MEASURE (M5b).

#### 3.3.1 Gap datum G

| Item | Value | Status |
|---|---|---|
| **G** (core-side PCB surface → core plate surface, with the board seated on the bosses) | **4.5 ± 0.5 mm** (G_min 4.0, G_max 5.0) | [Sourced: Aidan, standoff height measured] |
| **p**: protrusion of the copper pads above the black plate | Assumed **0 … 0.5 mm** until measured. Contact heights below use G − p. | **TO MEASURE D3** |
| G per core, to ±0.05 mm | Required before a die shim is machined (the shim tolerance stack is tighter than ±0.5) | **TO MEASURE** |
| Offset modules (§3.7) | Effective gap **G_eff = G + plane_offset** | [Proposal] |

#### 3.3.2 Core-side zones and rules

| ID | Zone (MP62 frame) | Rule | Status |
|---|---|---|---|
| **TZ1 / die pad** | Core die pad **23.6 × 21.7 mm**, centroid (51.85, 69.43); TZ1 = pad bbox + 1 mm = **X 39.1–64.7, Y 57.6–81.2** | **The module's main heat source (die, lid or spreader) contacts the die pad.** Stack: die/package (+ Cu shim) + TIM bondline must equal **G − p + δ**, with δ = **0.05–0.2 mm** interference so the bracket ring (behind the die, outer side) preloads the die before the board seats on the bosses. TIM: grease or phase-change, bondline 0.05–0.15 mm. Contact face flat to ≤ 0.05 mm. | [Sourced: scan]; δ [Proposal]; verify with pressure paper (Fuji Prescale LW) on P3 |
| **TZ3 / strip pads** | 4 strips, each ≈ **41 × 15 mm** at 45° (≈ 550 mm² each), centroids (28.5, 48.9), (75.2, 49.0), (28.4, 90.2), (75.1, 90.5). Ends are cut away around the bosses (copper-free radius ≈ 8.7 mm). Polygons in DXF layer `CORE_STRIP_PADS`. | **Secondary heat sources (VRAM, power stages, a bridge chip) couple to the strips through thermal pads.** Component top (+ optional Cu spreader) = **G − p − t_pad**, with compressed pad thickness t_pad **0.5–2.0 mm recommended**, 3.5 mm maximum. That puts the component/spreader top at **2.5–4.0 mm** above the PCB. Non-contact parts under a strip: **≤ 3.0 mm**. | [Sourced: scan]; t_pad [Proposal] |
| **H-CORE**: general height | Over the black plate, outside the die and strip pads | Parts **≤ 3.5 mm** (= G_min 4.0 − 0.5 mm margin). The EEPROM declares the module's actual maximum (`h_core_max`). | [Sourced: G]; margin [Proposal] |
| **H-CORE-OUT**: outside the plate | Board area outside the black plate X 7.5–95.5, Y 8.6–149.5 (the bottom strip Y 0–8.6, the side bands X 0–7.5 and 95.5–104, and the top Y 149.5–166) | Parts **≤ 1.0 mm** (provisional). The frame around the plate may stand higher than the plate. | **TO MEASURE MF-1** (frame/rim height relative to the plate) |
| **KO-F1** | **Ø11** around each mounting hole (boss OD ≈ 9 + 1 mm) | **No parts.** Plated-hole copper may touch the boss (GND bond, §3.2). Enforced by the F courtyard of the hole footprint. | [Sourced: scan]; boss OD TO MEASURE MF-5 |
| **KO-F2A / KO-F2B** | **A:** X 88–104, Y 139–166. **B (mirror):** X 0–16, Y 139–166. Each minus its two lug pads. | **Bus-bar tongue zones: no parts, on both sides of the board.** The stock bus bar comes through the core and lands on the core side of its lug site [Inference]. Face 1 uses site A and the other face uses site B (the stock GPU boards are mirrored, §6.4.1). Every module keeps **both** zones free. The lug centres lie **outside** the black plate (X 7.52–95.45); the Ø8.8 pads overlap the plate's top corners by ≤ 3.6 mm (X 92.9–95.5 at site A, X 7.5–11.1 at site B, Y 143–149.5). That is flat copper only, no height. Template rule areas. | TO MEASURE M5 / M5b |
| **KO-F5A / KO-F5B** | **A:** X 97.5–103.7, Y 122.4–138.4. **B (mirror):** X 0.3–6.5, same Y. | **No parts.** An unidentified raised tab on the scanned core face (X 98–102, Y 122.4–138.4), on the same side as lug site A: possibly a bus-bar contact or a grounding finger. The other face is presumed mirrored like the GPU boards, so the mirror zone is reserved too [Inference]. Template rule areas. | **TO MEASURE** (identity, height; is the other face mirrored?) |
| ~~KO-F3~~ | Former Ø8 at (26.4, 2.6) and (76.8, 2.5) | **Released.** The scan shows no bosses at the mirrored MEG-Array positions. Those points now fall in H-CORE-OUT (≤ 1.0 mm). | [Sourced: scan] |
| **Rod = base-board standoff screw** (outside the board) | Scanned face: X 83.9–87.5 (centre 85.7), tip at Y ≈ −23.5; visible Y −10.3…−23.5. The other face sees the mirror (X 16.5–20.1). | **Identified (Aidan, 2026-10-01; photo `bracket/core_photo/`):** one of the two long standoff screws that stick out of the core's bottom end and carry the base board at its gold holes G1/G2 (±49 mm). From the photo: shaft Ø ≈ 4.6 ± 0.6, a collar Ø ≈ 5.7 × 1.4 at the tip, and **≈ 18.4 ± 1.5 mm protrusion** beyond the core's end face. Not on the module. It sits in the J_DISP cable corridor (X 67.5–96.5) on one face and beside J_AUX on the other; route cables ≥ 3 mm clear. | [Sourced: Aidan]; dimensions [Estimate, photo]; C-15, C-16 |
| Plate notch | Rim notch at X 48.6–53.7, Y 8.1–11.5 | Inside H-CORE-OUT; no effect on v0.1. | [Sourced: scan] |

#### 3.3.3 Target heights: worked examples [Estimate]

Nominal G = 4.5 and p = 0 are used here. Recompute every stack with the measured G and p of the target core.

| Part | Typical height above PCB | Gap to the pad surface | Recommended stack |
|---|---|---|---|
| Navi 23 FCBGA, bare die (stock-type GPU module) | ≈ 2.5–2.8 mm (balls + substrate + die) | 4.5 − 2.6 + δ 0.1 = 2.0 | **Cu shim ≈ 1.9 mm** (1.4–2.4 over G 4.0–5.0) soldered or bonded to the die, with grease (0.05–0.15) on the core side. Alternatively a vapour-chamber "lid" at the same height. |
| ASM2824 / bridge-chip FCBGA (storage module) | ≈ 1.2–2.0 mm | ≈ 2.5–3.3 | Cu block of 2.0–2.5 mm plus grease, or a 1.0–1.5 mm pad directly on a 2.0 mm block |
| GDDR6 BGA (14 × 12 mm) | ≈ 1.1–1.2 mm | ≈ 3.3–3.4 to a strip | **2.0 mm Cu spreader + 1.0–1.5 mm pad** (≈ 1 K/W per package at 6 W/m·K), or a single 3.3 mm soft pad (≈ 3.3 K/W: acceptable below about 2 W per package) |
| DrMOS / SPS (5 × 6 mm, ≈ 1.0 mm) | ≈ 1.0 mm | ≈ 3.5 to a strip | **Shared Cu bar** over the row of stages (0.3–0.5 mm pad below, 0.5–1.0 mm pad above). A 3.5 mm pad alone gives ≈ 19 K/W per stage: too high. |
| Molded power inductors | 4.0–5.0 mm (common) | — | **Too tall for the core side.** Use ≤ 3.0 mm low-profile parts, or move them to the outer side. |
| Polymer caps (7343 D-case) | ≤ 2.8 mm | — | OK anywhere in H-CORE (≤ 3.5) |

**Rules**

- Every part that dissipates **> 2 W** shall sit under the die pad or a strip pad, and shall be thermally coupled to it.
- A module shall declare `hotspot_dx/dy` (§3.2) and `h_core_max` (§8). The value of `h_core_max` shall not exceed G_min + plane_offset − 0.5 mm.
- The thermal pads shall be soft enough that the full pad stack at G_min still lets the board seat on the bosses without exceeding the die preload. Recommend ≤ 30 Shore 00 at ≥ 6 W/m·K. Final values come from the P3 thermal test (§10).

### 3.4 Outer side (B): keep-outs and height

| ID | Zone | Rule | Status |
|---|---|---|---|
| **KO-B1** | Stock bracket outline **+1 mm**: polygon from `bracket/gpu_bracket_keepout.dxf` translated to (52, 69.5). Extent X 9.3–94.7, Y 39.25–100.1 | **No components.** Tented vias, tracks and silkscreen are allowed. Template rule area (footprints and pads disallowed on B.Cu). | [Sourced: bracket scan]; bracket height TO MEASURE (MF-4) |
| KO-B1 release (bracketless modules) | Whole KO-B1 | A module that does **not** fit the stock X-bracket (screws with washers straight into the bosses, no preload needed on its die-pad part, e.g. a gap pad) **may** use KO-B1 for parts within the envelope. It shall keep KO-B2 (the screw head and driver access) and state "bracketless" in its documentation. Anything that passes over a KO-B2 circle (e.g. an M.2 card) shall clear the screw head (MF-13). See C-19 | [Proposal, update 3] |
| **KO-B1v** | Ring interior Ø23.5 at (52, 69.5) | Parts **≤ 1.0 mm** (decoupling behind the die is allowed) | TBC MF-4: does the ring sit on the board, or above it? |
| **KO-B2** | Ø12 around each mounting hole | No parts: screw head, spring and driver access | [Proposal] |
| Lug screw heads | Ø10 around **each** lug site (sites A and B) | No parts | [Proposal] |
| **Connector band** | Y 0–26 across the full width | Reserved for J_PCIE, J_DISP, J_AUX and their plugs and cables (§3.5). Other parts only outside the connector keep-outs. | [Proposal] |
| **Height envelope (normative v0.1)** | Whole outer side | A part at lateral position x shall not exceed **h(x) = √(R_i² − (x − X_AX)²) − (55 + t) − 1.0 mm**, with R_i = 80 (shell inner radius) [Estimate], X_AX = 52 [Inference], t = PCB thickness. For t = 1.6 mm: **22.4 at the centre, 19.9 at x = 32/72, 14.3 at 17/87, 10.5 at 10/94, 8.5 at 7/97, 4.9 at 2/102, 3.2 at the edge.** | **TO MEASURE M1 (R_i, plane distance, X_AX)** |
| Simplified zones (always safe) | By \|x − 52\|: ≤ 20 → **19 mm**; 20–35 → **14 mm**; 35–42 → **10 mm**; 42–47 → **7 mm**; 47–52 → **3 mm** | A module that meets the zones meets the envelope. Both are shown in the drawing. | TO MEASURE |

> The envelope is a function of x only, because the shell is a straight cylinder over the module's height. Near the bottom edge the base ring/fillet (M1b) and the cable bends (§3.6) may reduce it further. Near the top, check clearance to the fan duct (MF-8).

### 3.5 Connector placement (outer side) [Proposal]

| Ref | Part | Position (MP62 frame) | Orientation | Keep-out (incl. plug) | Mated height | Envelope at the worst x |
|---|---|---|---|---|---|---|
| **J_PCIE** | MCIO 124 RA receptacle, Amphenol **G97R24332HR** (or JPC / Molex 2173463021 / TE equivalent) | Centre **X 43.5**. Mating face **Y 14.5**. Locating-peg line (footprint origin) Y 20.525 | Opening toward **−Y** (bottom edge) | X 20.5–66.5, Y 1.4–25.1 (46 wide: plug front 44.80, rear flanges 47.8 max) | **≈ 8.2 mm** (plug body 7.86 + latch 0.3; plug bottom flush with the PCB, because card centreline 3.05 = datum A to plug bottom 3.10) [Sourced: SFF-TA-1016 Table 5-4/6-3] | h(20.5) = 15.9 ✓ |
| **J_DISP** (GPU only) | MCIO 74 RA receptacle, Amphenol **G97R22332HR** (or JPC P947B0743313) | Centre **X 82.0**, mating face Y 14.5 | Opening −Y | X 67.5–96.5, Y 1.4–25.1 | ≈ 8.2 mm | h(96.5) = 8.9 ✓ (only 0.7 mm spare; MF-3) |
| **J_AUX** | JST **SM15B-GHS-TB(LF)(SN)** GH 1.25 mm 15-pin RA | Centre **(16.5, 26.5)**, pin row along Y | Opening toward **−X**; cable turns down beside the J_PCIE plug | X 7.5–20.0, Y 15.0–38.0 | ≈ 4.3 mm | h(7.5) = 8.9 ✓ |
| **J20 / J21** (site A) and **J22 / J23** (site B, mirror) | 12 V bus-bar lug sites (§6.4.1), **both fitted**, in parallel | A: **(97.26, 147.44)**, **(97.06, 159.13)**. B: **(6.74, 147.44)**, **(6.94, 159.13)** | Through-hole, screw from the outer side (only into the site in use) | Ø10 both sides plus KO-F2A/B | screw head ≈ 2–3 mm | h(97.3) = h(6.7) = 8.4 ✓ |
| **J_12V_ALT** (optional, DNP) | PCIe 8-pin RA, Molex **45586-0005** class (KiCad footprint `Molex_Mini-Fit_Jr_5569-08A2`) | Centre (52, 154), body X 43–61, Y 147.5–160.5 | Opening toward **+Y** (top edge) | body plus plug above the top edge | 12.8 mm | h(43) = 21.9 ✓; clearance above the top edge TO MEASURE MF-8 |

**Rules**

- J_PCIE and J_DISP **shall** use the positions above (±0.5 mm), because host cables are cut to fit them. J_AUX **should** use its position. A module without a display leaves J_DISP unpopulated, and its keep-out may be used for other parts within the envelope.
- **Footprints:** the SFF-TA-1016 Annex A recommended RA footprints (Table A-2, 124P: pads 0.35 × 1.40 at 0.60 pitch; rows A/B 0.575 / 3.525 behind datum Y; NPTH Ø1.10 locating holes 40.645 apart; 0.60 × 1.50 solder-pin slots 41.70 apart, at 1.775 and 4.325 from datum Y; A1/B1 18.90 from datum X; A38/B38 4.50 from datum X. Table A-1, 74P: 37 pins over 21.60, holes 24.445, slots 25.50). These are in the template library `MP62_Face.pretty`. **The side of datum Y the pad rows lie on is assumed; verify it against the Amphenol drawing before fabrication (OQ-5).**
- **BP cable landing [Sourced: BP]:** J9 sits 4.6 mm lateral from Face P's centreline and J10 −4.6 mm from Face S's (mirror placement). In the module frame the cables arrive at **X 47.4 (Face P)** and **X 56.6 (Face S)**, against J_PCIE at X 43.5: a lateral jog of 3.9 mm and 13.1 mm. The BP should move both to s = +8.5 mm (rotationally symmetric) so each cable runs straight (change request CR-2).

### 3.6 Cable routing (both MCIO cables) [Inference]

- Path: BP J9/J10 plug (exits radially outward, plug rear at r ≈ 50 mm) → passes under the module's bottom edge (≥ 15 mm gap per M1; the standoff geometry suggests ≈ 23 mm, C-16) → turns 90° upward on the outer side → enters the J_PCIE plug travelling +Y.
- **Length between plug rears is only ≈ 30–60 mm.** Commodity MCIO cables are ≥ 150 mm (typically 0.5 m), and there is no room to stow slack under the face. **Custom-length cables are needed** (or a later MECH revision moves Y_mate up, to at most 28.5 before the bracket keep-out). TO MEASURE M4; open question OQ-1.
- Bend radius of flat MCIO twinax: TBD from the cable vendor. Assume ≥ 10 mm inside radius → the cable needs ≈ 10–12 mm of outer-side clearance at the bottom edge. The envelope gives ≥ 15.9 mm across J_PCIE.
- **J_DISP cable** to the IOB: 0.3–0.5 m, routed along the outer side. Path and length TO MEASURE M9.
- **Mating cycles:** MCIO is rated 250 cycles [Sourced: Amphenol]. That is fine for a module that is changed occasionally.

### 3.7 Offset modules (MXM carriers and similar)

- A module may sit its PCB **outward from the stock plane** by a declared `plane_offset` (EEPROM, 0.1 mm units), using spacers on top of the 4.5 mm core bosses and longer screws. Its outer envelope then shrinks by the same amount, and the core-side gap grows to G_eff = G + plane_offset.
- Example: an MXM 3.1 carrier with the MXM card on the core side. The carrier plane moves out by the MXM stack (≈ 4–6 mm [Estimate]). Outer envelope at the centre ≈ 16–18 mm.
- The bracket still clamps the carrier. The heat path is MXM die → core; the clamp force path must go through the MXM's own heatsink holes and spacers (§11.1).

### 3.8 Stackup and fabrication

- Template default: **JLC06161H-2116**, 6 layers, 1.6 mm, ENIG, the same stack as the BP.
- GPU modules (Navi 23 BGA, GDDR6) will need **8–10 layers** with via-in-pad. Keep the outline, holes and keep-outs, and change only the stackup.
- PCIe 85 Ω and display 100 Ω start values are in the template netclasses. Confirm them with the JLC impedance calculator.
