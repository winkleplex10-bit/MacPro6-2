# MacPro6,2 Face Module Specification, v0.1 ("MP62-FACE v0.1")

**An open, Framework-16-style module standard for the two non-CPU faces of the Mac Pro Late 2013 thermal core**

| Item | Value |
|---|---|
| Document | MP62-FACE Module Spec **v0.1** (draft for review) |
| Date | 2026-10-01 |
| Owner | Aidan Winkler (MacPro6,2 project) |
| Supersedes | §7 "OPEN FACE MODULE SPECIFICATION, v0.2" of `macpro62-architecture-spec-v0.2.md` for everything module-side. Host-side items (BP, CPU board) stay in the architecture spec; changes needed there are listed as change requests in §13. |
| Mechanical revision | **MP62-FACE-MECH 0x0001** (this document, §3). Written into every module EEPROM (§8). |
| Status | **Provisional.** Every dimension tagged **TO MEASURE** must be checked on a real core/enclosure before anyone fabricates a module. |
| Licence (proposal) | CC-BY-4.0 for this text and drawings; CERN-OHL-P-2.0 for the KiCad template. |

**Tags** (as in spec v0.2): **[Sourced]** = from a document, datasheet or CAD file named in §16 · **[Proposal]** = a decision made here · **[Estimate]** = a number derived from estimates · **[Inference]** = reasoning, not verified · **TBD** / **TO MEASURE** = open.
**Normative words:** *shall* = required for compliance, *should* = recommended, *may* = allowed.
**Numbering:** sections are versioned. A heading tagged `[v0.1]` was written or rewritten for this release; later releases will tag the sections they change.

**Deliverables in this package**

| File | What it is |
|---|---|
| `macpro62-face-module-spec-v0.1.md` | This document |
| `macpro62-face/macpro62-face-v0.1-mech.png` | Mechanical drawing: outline, holes, keep-outs on both sides, connector zones, outer height zones, section |
| `macpro62-face/macpro62-face-v0.1-system.png` | Link / power / display path diagram and power sequencing timing |
| `macpro62-face/macpro62-face-v0.1-outline.dxf` | DXF R2010, mm, layered: outline, holes, keep-outs, connector zones, height zones, core die/strip pads, bosses, plate, tab |
| `macpro62-face/pinouts/*.csv` | Full contact-level pinouts: MCIO 124 PCIe, MCIO 74 DISPLAY-LINK, AUX GH15, power |
| `macpro62-face/tools/` | Generators (single geometry source `face_geom.py`), EEPROM encoder/validator `mp62_eeprom.py` |
| `macpro62-face/eeprom_examples/*.bin` | Example ID EEPROM images (MXM RX 6600 carrier, ASM2824 storage) |
| `kicad/macpro62-face-template/` | KiCad 9 template: Edge.Cuts, 4 mounting holes, rule-area keep-outs (bracket, both bus-bar tongue zones KO-F2A/B, core tab KO-F5A/B), both lug sites wired in parallel (reference tracks), core contact zones on User.1, connector placeholders, JLC 6-layer stackup, netclasses. `kicad-cli pcb drc`: **0 violations, 0 unconnected** |
| `kicad/macpro62-storage-face/` + `macpro62-storage-board-plan.md` | Storage reference module SM-1 rev A0 (§11.3): floorplan PCB (DRC 0/0), schematic (ERC 0/0), plan with BOM, cost and RAID analysis |
| `bracket/core_gpu_face/` | Core GPU-face scan, calibrated and traced: `trace_core_gpu_face.py`, `core_gpu_face.json`, DXF in the module frame and in the scan frame, overlay PNGs (on the scan, and in the module frame) |

![MP62-FACE v0.1 mechanical drawing](macpro62-face/macpro62-face-v0.1-mech.png)

---

## 0. Revision history

| Version | Date | Changes |
|---|---|---|
| v0.1 (sections in the architecture spec) | 2026-09 | Card-edge (SFF-TA-1002) concept, withdrawn in v0.2 |
| v0.2 (§7 of the architecture spec) | 2026-10-01 | MCIO 124 + GH14 AUX + bus-bar lugs; OCP FLEXIO logical map; IPMI FRU EEPROM; display TBD (OD-2) |
| **MP62-FACE v0.1 (this standalone spec)** | 2026-10-01 | First standalone release. Mechanical frame, outline, holes and keep-outs defined (§3), including core contact zones traced from the core scan and the measured 4.5 mm core gap. MCIO 124 confirmed as **one 16i connector per face**, SFF-9402 sideband positions (§4). AUX moves to **GH15** (adds MOD_LED#; USB2 primary) (§5). Power budget **Face P 150 W / Face S 40 W**, new classes, eFuse and sequencing rules (§6). Binary MP62 descriptor EEPROM (§8). **DISPLAY-LINK = second MCIO (74-pin, 8i) on the module with a twinax cable to the IOB** (§9). KiCad template, DXF and drawings. |
| MP62-FACE v0.1 update 1 | 2026-10-01 (≈ 17:45 ET) | **Mirrored bus-bar lugs (C-17):** both lug sites (A at X ≈ 97, B at X ≈ 7) on every module, wired in parallel; KO-F2B, KO-F5B and the mirrored rod added (§3.3, §6.4.1). **Rod identified (C-15)** as the base-board standoff screw; core-bottom spacing conflict with M1 logged (C-16). Drawing, DXF, KiCad template (J22/J23, rule areas, reference tracks; DRC 0/0) and power pinout updated. |
| MP62-FACE v0.1 update 2 | 2026-10-01 (≈ 18:30 ET) | Base-board scan: stock GPU connector axes ±46.6° → face-angle conflict **C-18** and measurement M2c logged (no module geometry change). Standoff screws confirmed at the base-board holes (pitch 98.25). |
| MP62-FACE v0.1 update 3 | 2026-10-01 (≈ 20:20 ET) | **Storage reference module SM-1** designed (plan `macpro62-storage-board-plan.md`, KiCad `kicad/macpro62-storage-face/`): §11.3 rewritten (ASM2824 on the die pad with a gap pad, 4 × 2280 on the outer side, bracketless). New conflicts **C-19** (bracketless modules / KO-B1), **C-20** (>2 W rule vs outer-side M.2 SSDs), **C-21** (THERM_ALERT# throttle for storage). New measurements MF-13, MF-14. Storage parts added to §15. RAID finding: no driverless bootable hardware RAID is orderable (§11.3). |
| MP62-FACE v0.1 update 3a | 2026-10-01 (≈ 20:30 ET) | Aidan approved bracketless SM-1 (C-19): 4 × 2280, module held by low-head screws (head + washer ≤ 1.6 mm); MF-13 redefined (thread/length for the screw part number). |
| MP62-FACE v0.1 update 4 | 2026-10-02 (≈ 13:15 ET) | ICD rev 2 (Aidan's decisions): **face normals ≈ 45° / 135°** (M2c answered, C-18 closed; module frame unchanged); BP J9/J10 re-placed (fp5) → cable jogs 13.7 mm (Face P) / 10.5 mm (Face S); **CR-2 closed by a flat-twinax jog cable** (§3.5, §3.6); **445 W system ceiling** replaces the 405 W rule (§6.3); new **§6.8 live power target** (12 V monitor INA228 @0x40 mandatory for modules > 3 W, power-target agent @0x58, THERM_ALERT# fast cap); SMBus map §8 updated. |
| MP62-FACE v0.1 update 5 | 2026-10-04 (≈ 08:45 ET) | ICD rev 2.1, **O-6 answered**: MCIO plug data sourced (SFF-TA-1016 Rev 1.3 Tables 5-4/6-2/6-3, Amphenol AssembleTech DS-0002); BP mating-face error corrected (n 30.0 / 30.3, not 43.3 / 43.6) → ≈ 28–37 mm free cable, 90° bend fits; **the 13.7 / 10.5 mm lateral jog does not fit a flat twinax ribbon** (§3.6). Centreline (X 52) fallback rejected (≥ 3.5 mm jog). **Proposal O-10** (needs Aidan): J_PCIE X 47.0, J_DISP X 82.5, narrow cable plugs, BP fp6 zero-jog landing (§3.5). Positions X 43.5 / 82.0 stay normative until approved. Cross-section `docs/o6_mcio_cross_section.png`. |
| MP62-FACE v0.1 update 6 | 2026-10-04 (≈ 09:10 ET) | ICD rev 3, **O-10 approved by Aidan and applied**: **J_PCIE X 43.5 → 47.0**, **J_DISP X 82.0 → 82.5** (normative, ±0.5), **narrow cable plugs (no anti-skew flanges) normative** (plug bodies 1.3 mm apart; keep-outs X 25.4–68.6 / 68.9–96.1; mated heights 10.0 / 9.0 at the latch). BP fp6 lands J9/J10 at s = +5.0 = X 47.0: **zero jog**, straight ↔ straight cable ≈ 52.8 / 56.3 mm mating face ↔ mating face at M1 15 (§3.5, §3.6). KiCad template (J1/J2), SM-1 J1, drawing, DXF and footprints (narrow courtyards) updated; DRC 0. Vendor RFQ drafted (OQ-1). |

---

## 1. Scope [v0.1]

1. **What a module is.** A printed circuit board that replaces the stock D300/D500/D700 GPU board on one of the two non-CPU faces of the triangular thermal core. The enclosure, core, fan, stock 450 W PSU and the stock X-shaped retention bracket stay.
2. **Two slots [Proposal]:**
   - **Face P (primary):** PCIe up to **x16**, Gen4 (rev A). GPU slot. Has DISPLAY-LINK.
   - **Face S (secondary):** PCIe **x4** in host rev A; the cable and connector are x16-capable, and x8 is possible with a later host. Storage, NIC, capture, accelerators. Low power.
   - Both slots use the **same mechanical outline and the same connectors**, so a module that fits the power and lanes works in either (declared in the EEPROM `slot_mask`).
3. **Three host interfaces per module:**
   - **J_PCIE:** right-angle **MCIO 124** receptacle (SFF-TA-1016, 16i). Twinax cable from BP J9 (Face P) / J10 (Face S).
   - **J_AUX:** right-angle **JST GH 15-pin** receptacle. Management cable from BP J3 / J4.
   - **12 V input:** the stock PSU bus bar (primary), plus an optional PCIe 8-pin header (alternative). The stock GPU 2 board is a mirror image of GPU 1 at its 12 V screws, so the two faces' bus bars land on **opposite sides**. Every module therefore carries **two lug pairs, site A (X ≈ 97) and its mirror site B (X ≈ 7), wired in parallel**, and fits either face (§6.4.1).
   - GPU modules add **J_DISP:** right-angle **MCIO 74** receptacle (8i), with a twinax cable **directly to the I/O board (IOB)**.
4. **Rev-A defaults:** PCIe **Gen4**; Gen5 optional (needs the BP-G5 redriver build). S0/S5 only (no S3 for modules). No hot-plug. No USB4 and no 10GbE on face lanes (10GbE AQC107 goes on chipset lanes later).
5. **Non-goals for v0.1:** modules that need more than 150 W; fans on modules; display through the BP; module-to-module links.
6. **Cost rule [Proposal]:** use connectors JLCPCB/LCSC lists, standard JLC stackups and no exotic processes, so a hobbyist can order a module as JLC turnkey assembly. Prices are in §15.

## 2. System context and coordinate frame [v0.1]

![System diagram](macpro62-face/macpro62-face-v0.1-system.png)

- **Host** = CPU board (**CB**, own LGA1700 + Z790 board since 2026-10-01; the COM-HPC carrier CC is the archived fallback) + round base board (**BP**, Ø122, 6 layers). The BP is the PCIe hub. It routes **x16 to J9 (Face P)** and **x4 to J10 (Face S)**, both MCIO 124 right-angle receptacles with the SFF-TA-1016 footprint [Sourced: BP KiCad `backplane.kicad_pcb` fp4 (2026-10-02): J9 at s = +8.0 rot −60°, J10 at s = −5.0 rot +60°; see C-2 status in §13].
- **IOB** = the new rear I/O board. Planned rear ports: 2 × DP 1.4 + 1 × HDMI 2.1 from the GPU, and 4 × USB-C, 2 of them with DP alt-mode through a mux [Proposal, user brief].
- **Module frame (normative).** Origin at the bottom-left corner of the outline's bounding box, **seen from the core side**. +X runs along the bottom edge. +Y points up toward the fan. The bottom edge faces the BP.
  - **Core side = KiCad F (top) layer.** Outer side (toward the enclosure shell) = KiCad B (bottom) layer.
  - All coordinates in this document, the DXF and the KiCad template use this frame, including outer-side features, drawn see-through. A point seen from the outer side has x_outer = 104 − x.
  - The stock board scan in `bracket/gpu_board/` was traced from the **outer** (bracket) side. Asymmetric stock features (bus-bar standoffs, MEG-Array screws) are mirrored into this frame here [Inference: the scan is the back view, per `bracket/gpu_board/summary.md`]. The core GPU-face scan (`bracket/core_gpu_face/`) is consistent with this: its tab feature lands at X ≈ 100, the same side as the lug sites at X ≈ 97 (§3.3).
- **Face geometry [Sourced: spec v0.2, BP files].** The module's core-side surface sits in a plane about **55 mm from the enclosure axis** [Estimate]. The core plate surface lies **G = 4.5 ± 0.5 mm** further in, because the board rests on the core's standoff bosses [Sourced: Aidan, measured; §3.3]. Its bottom edge is about **15 mm above the BP top surface** (TO MEASURE M1b).
- **Lateral position [Inference].** The module centreline X = 52 is assumed to lie on the enclosure axis's projection (the BP draws the faces this way). The v0.2 plane-triangle model would put the face centre about 24.5 mm off-axis. That is geometrically impossible: at 55 mm from the axis the half-chord of an R 80 shell is only √(80² − 55²) = 58.1 mm. A 104 mm board therefore fits only if the offset is within **±6 mm** (core side), and within **±4.5 mm** at the outer surface. See conflict C-7 and measurement MF-3.
