
## 4. PCIe interface: J_PCIE (MCIO 124, 16i) [v0.1]

### 4.1 One 16i connector, not 2 × 8i (resolution)

- **[Sourced]** SFF-TA-1016 Rev 1.3 defines the **74-contact** receptacle as the 8-lane ("8i") size and the **124-contact** receptacle as the 16-lane ("16i") size. Each row of the 124 carries 16 differential pairs plus two 5-contact sideband groups. Amphenol's selector lists 124 pin as "16X + sideband". Contacts 1–37 of the 124 are identical to the 74.
- **So x16 needs one 124-pin (16i) connector.** Two 8i (2 × 74) would also carry x16, but that means double the connectors, cables and footprint area, and the BP already has **one 124-pin RA receptacle per face (J9, J10)**.
- The brief's "MCIO 124-pin (8i)" is a misnomer: 124-pin is 16i. The earlier part TE **1-2381578-9** is a 124-position (16i) **vertical** receptacle, which is consistent in size. On the module it is unsuitable: vertical receptacle plus straight plug plus cable bend is ≈ 25 mm, more than the ≤ 22 mm envelope. **The module uses a right-angle 124.**
- **Face S uses the same 124 receptacle [Proposal; resolves v0.2 OD-3]:** modules are interchangeable between slots, x8 later needs no module change, and one part number serves both. Rev A wires only lanes 0–3 on the BP side (J10 x4).

### 4.2 Contact map (module end)

**Convention.** SFF-9402 assigns the host end: host TX on row B, host RX on row A, sideband set A at positions 8–12, set B at 26–30 [Sourced: SFF-9402 Rev 1.1; SFF-TA-1016 Fig. C-3]. A compliant cable **crosses the rows** (P1 B-n ↔ P2 A-n). At the **module end**, therefore, host TX arrives on **row A** and the module transmits on **row B**, and the sideband pins appear row-swapped. The tables below are **module-end**. The BP end is the same table with rows A and B exchanged. All positions not listed are **GND**.

**Lanes**

{{PCIE_LANES}}

**Sideband (sets A and B)**

{{PCIE_SB}}

- **Mapping onto SFF-9402 names:**
  - REFCLK0± = REFCLKA±; PERST0# = PERSTA#; MCIO_PRSNT0# = CPRSNTA#; WAKE0# = CWAKEA#; CLKREQ0# occupies **BP_TYPEA**; PCIE_SMCLK/DAT = 2W-CLKA/DATA.
  - CLKREQ0# on BP_TYPEA is an MP62 assignment [Proposal]. Off-the-shelf SFF-9402 backplanes read BP_TYPE as a type strap, so a module **shall not** drive CLKREQ0# unless `clk_flags.bit2` is set. Hosts may ignore it: BP rev A runs REFCLK free-running.
- Full contact list: `macpro62-face/pinouts/mp62-face-v0.1_mcio124_pcie_module-end.csv`.
- **Cable requirement:**
  - Use SFF-TA-1016 straight-plug to straight-plug 124P cables with **all 32 pairs and all 20 sideband contacts wired**, crossed per Fig. C-3.
  - Many PCIe server cables wire only selected sidebands, or are "x8 + x8" splits. **Verify every cable type** (OQ-3). The BP shall also check MCIO_PRSNT0#.

### 4.3 Electrical rules [Proposal]

1. **Widths:** a module shall connect lanes contiguously from lane 0 (x1 → lane 0; x4 → 0–3; x8 → 0–7; x16 → 0–15). It shall train down to x1 and to Gen3. Lane reversal and polarity inversion are allowed by PCIe, but modules shall not need them: the host routes straight.
2. **AC coupling:** module TX (row B) gets **220 nF** (176–265 nF) 0201/0402 caps, close to the module's transmitter. Host TX is AC-coupled on the host [v0.2 §3.7].
3. **Impedance:** 85 Ω ±10 % differential (PCIe 4/5 and MCIO practice). Intra-pair skew ≤ 0.13 mm. GND reference void under the connector pads per the vendor drawing.
4. **Module loss budget** (endpoint package excluded), from v0.2 §3.6: **≤ 1.8 dB @ 8 GHz for Gen4** (≈ 3 in on JLC NP-155F). Gen5-capable modules: **≤ 4.5 dB @ 16 GHz**, and declare `pcie_gen_max = 5`. The host enables Gen5 only on a BP-G5 build (DS320PR810 redrivers); otherwise it forces Gen4.
5. **REFCLK:** 100 MHz HCSL, common-clock architecture, 85–100 Ω. SRIS is not required.
6. **PERST0#:** 3.3 V input, push-pull from the BP. The module shall not back-power it from 3V3_AUX or 12 V when off: use a back-drive-safe buffer or rely on the device's fail-safe input.
7. **Set B** (REFCLK1, PERST1#, CLKREQ1#, WAKE1#, MCIO_PRSNT1#) is reserved for **x8x8 bifurcated modules**. BP rev A does not drive set B. A module shall work with set B unconnected unless it declares `bifurcation = 1`, and then only on a host that supports it.

## 5. Management interface: J_AUX (JST GH 15-pin) [v0.1]

- **Part [Proposal]:** module **JST SM15B-GHS-TB(LF)(SN)** (RA, 1.25 mm, 1 A/contact; LCSC **C265027**, ≈ $0.87). Cable: GH 15-pin both ends, pin 1 ↔ pin 1, 26–28 AWG, ≤ 0.3 m.
- Pins 1–12 are **identical to the v0.2 GH14** so the BP logic carries over. 13–14 USB2 are now the **primary** USB2 path (SFF-9402 has no USB2 contacts). **15 = MOD_LED#** (new).

{{AUX_TABLE}}

- **I/O levels:** all signals are 3.3 V, powered from 3V3_AUX. Open-drain pull-ups are on the host side (2.2 kΩ for SMBus, 10 kΩ for the others). Module bus capacitance ≤ 50 pF.
- **Before FACE_PWR_GOOD** the module may only drive FACE_PRSNT# (strap), the SMBus devices on 3V3_AUX, FACE_SMB_ALERT# and THERM_TRIP#.
- **MOD_LED# [Proposal]:** low = module OK/active. Activity blinking is allowed. The BP maps it onto the face status LED. Blink codes: off = no module or no power; on = PG; BP-driven blink = fault or identify. *Identify* is a host function: the BP blinks its own LED, and modules with an SMBus controller may also expose an identify register (`led_caps.bit2`).

## 6. Power [v0.1]

### 6.1 Path decision: 12 V straight from the PSU [Proposal, consistent with v0.2 §5.1]

| Option | Verdict | Reason |
|---|---|---|
| **PSU → module directly via the stock bus bars** | **Chosen** | The stock PSU already feeds each GPU face through its own bus bar (2 × T8 lugs per face) [Sourced: v0.2 REF-S1 p.342]. Zero cable cost, high ampacity, no high current through the BP. |
| PSU → BP → MCIO / extra cable → module | Rejected | The BP takes only a ≤ 5 A harness (J2 Micro-Fit, fan and logic) [Sourced: v0.2 §4.4]. The MCIO carries no power contacts (0.5 A-class signal contacts). Routing 16 A (190 W) through the 6-layer controlled-impedance BP would need a new PSU harness and heavy copper. |
| Optional **PCIe 8-pin** on the module | Allowed (DNP by default) | For a non-stock PSU, a bench supply, or a missing bus bar. **Only one 12 V source per module may be connected** (no OR-ing in v0.1). |

### 6.2 Per-face budgets and power classes [Proposal]

| Class | Sustained (12 V input) | Peak (≤ 10 ms) | Face P | Face S (rev A) | Example |
|---|---|---|---|---|---|
| 0 | ≤ 3 W from 3V3_AUX only | 3.3 W | ✓ | ✓ | Sensor / test card |
| 1 | ≤ 40 W | 1.3 × | ✓ | ✓ (**slot max 40 W**) | ASM2824 + 4 × NVMe, NIC, capture |
| 2 | ≤ 75 W | 1.3 × | ✓ | Only if the host budget allows (CPU PL1 ≤ 65 W, §6.3) | Small GPU, accelerator |
| 3 | ≤ **150 W** | 1.3 × (≈ 195 W) | ✓ (**slot max 150 W**) | ✗ | Navi 23 GPU (RX 6600 TBP 132 W; RX 6600 XT 160 W needs a ≈ 7 % power limit; MXM RX 6600 ≈ 100 W) |

- **Averaging:** "sustained" is the average over any 1 s window, measured at the 12 V input. Thermally, the 60 s average shall stay ≤ sustained.
- **Face P 150 W, justified:**
  - The stock D700 drew ≈ 108–129 W per face [user data / v0.2].
  - In MP62 the other two faces carry far less than stock: CPU 35 W base / 92 W PL2 against the stock ≈ 130 W Xeon, and Face S ≤ 40 W against 129 W.
  - So the total heat into the core, ≤ 150 + 40 + 92 = **282 W**, stays well below the stock maximum of ≈ 388 W and the ~450 W rating. The aluminium core spreads heat between faces.
  - The per-face limit is therefore set by die heat flux and contact, not by core capacity. Until the P3 thermal test-module run passes, the host shall cap Face P at **130 W** (v0.2 Class 2). After that, Class 3 (150 W) is enabled [Proposal; validation required].
- **Face S 40 W, not 25 W:**
  - The reference storage module needs ≈ 35–41 W worst case: 4 × M.2 NVMe at up to ≈ 8 W each (3.3 V × 2.5 A max per M.2), plus ASM2824 ≈ 3–5 W, plus ≈ 90 % conversion.
  - 25 W would force NVMe power-state caps (PS1/PS2) that the host OS would have to enforce. 40 W costs only 15 W of PSU margin (§6.3).
  - A module may declare less (e.g. 25 W). The host budget uses the **declared** number.

### 6.3 PSU and core checks [Estimate]

| Load (sustained S0) | W | Source |
|---|---|---|
| CPU module i5-14500T at PL2 (PL1 35 W) | 92 | v0.2 §5.4 |
| CPU board regulators, NVMe | 8 | v0.2 |
| **Face P (Class 3)** | **150** | this spec |
| **Face S (Class 1)** | **40** | this spec |
| BP (MCU, 3V3_AUX × 2, SATA SSD) | 10 (+7 for BP-G5) | v0.2 |
| Fan | 10 | v0.2 (TBD) |
| IOB rev A | 40–50 | v0.2 |
| **Total** | **350–360 W** (367 W with BP-G5) | vs **450 W**: ≥ 20 % margin, inside the v0.2 rule **≤ 405 W (90 %)**. With Face S at 25 W: 335–345 W. |

- **Current:** 360 W / 12.1 V = 29.8 A of the 37.2 A main [Sourced: PSU 12.1 V / 37.2 A].
- **Transients:** face peaks of 1.3 × for ≤ 10 ms add ≈ 57 W → ≈ 417 W < 450 W. PSU OCP and transient response are TO MEASURE (MF-11).
- **Host rule (normative for hosts):** the MCU sums the declared `p_sustained_w` of both faces with its own table and refuses FACE_PWR_EN for a module that would exceed **405 W**, or exceed the slot maximum (150 W Face P, 40 W Face S rev A).
- **Core heat:** Face P + Face S + CPU PL1 ≤ **225 W sustained** (282 W with the CPU at PL2) [Estimate]. This is to be validated with the thermal test module in P3.

### 6.4 12 V input connectors [Proposal]

| Input | Part | Rating | Notes |
|---|---|---|---|
| **Bus-bar lugs, site A J20 (+12V_IN) / J21 (GND) and site B J22 (+12V_IN) / J23 (GND)** | No part: four PTH lug pads (two mirrored pairs, §6.4.1), **Ø3.2 drill, Ø8.8 pad both sides**, 8 × Ø0.5 stitching vias, ≥ 2 oz outer copper recommended. Stock screws T8 **923-0716**, 1.2 N·m [Sourced: v0.2]. | Design **≥ 15 A per lug** (12.5 A at 150 W). Contact ampacity of the stock bus bar TO MEASURE (M5). | Site A (97.26, 147.44) / (97.06, 159.13) are the stock STANDOFF_1/2 from the board scan, mirrored into core view [Inference]. Site B (6.74, 147.44) / (6.94, 159.13) is their mirror about X = 52. **Polarity, thread and the exact positions are TO MEASURE (M5).** If the stock lug needs a threaded insert, use Würth REDCUBE **7466003R** (M3, SMT, 50 A, 5 mm high; not stocked at LCSC) on the **outer side only**: the core side at the lug sites is outside the black plate (≤ 1.0 mm, KO-F2A/B). |
| **J_12V_ALT** (optional) | **Molex 45586-0005**, PCIe 8-pin RA, Mini-Fit Jr (not stocked at LCSC; JLC global sourcing). Face S may use the 6-pin **Molex 45558-0003** (LCSC C7545781, ≈ $1.07). | 8-pin: 150 W per PCIe CEM (3 × 12 V contacts, 9 A/contact Mini-Fit Jr rating). 6-pin: 75 W. | Pins 1–3 +12V, 5/7/8 GND, 4/6 SENSE. Use only when the bus bar is not connected (`v12_src_mask`). |

#### 6.4.1 Lug sites on mirrored faces: one universal module [Proposal]

Aidan reports that the stock GPU 2 board is a mirror image of GPU 1 at its 12 V power-input screws, so the bus bar of one face lands at site A (X ≈ 97, core view) and that of the other face at site B (X ≈ 7). There are two ways to handle this:

| Option | For | Against | Verdict |
|---|---|---|---|
| **(1) Per-face lug zone:** a Face P module carries only its face's site, a Face S module only the mirror site | Saves ≈ 16 × 27 mm of board corner; no idle live copper | Two board variants of every carrier; a module is locked to one face. A module fitted to the wrong face leaves its bus-bar tongue pressing on bare board or parts, so a 12 V short is possible. **We do not yet know which face (P or S) uses which site (M5b)**, so a single-site module cannot be laid out correctly today. | Not allowed in v0.1 |
| **(2) Universal: both sites on every module**, wired in parallel | One layout fits either face, so the module needs no variant and no face-specific BOM. It doesn't depend on M5b or OD-6 (Face P assignment). The `slot_mask` stays a power/lane decision, not a mechanical one. Cost is small: the site B corner (X 0–16, Y 139–166) lies in H-CORE-OUT (≤ 1.0 mm on the core side) and in the 3–8 mm outer height zone, where few parts fit anyway. | One corner of board area lost; the idle site is live at 12 V; up to ≈ 50 mm of extra 12 V copper | **Chosen (normative v0.1)** |

**Rules (v0.1):**

- Every module **shall** carry both lug pairs: **site A** J20 (+12V_IN) at (97.26, 147.44) and J21 (GND) at (97.06, 159.13); **site B** J22 (+12V_IN) at (6.74, 147.44) and J23 (GND) at (6.94, 159.13). All four are Ø3.2 drill / Ø8.8 pad on both sides with 8 stitching vias.
- KO-F2A, KO-F2B, KO-F5A and KO-F5B **shall** stay free of parts on the core side. The Ø10 screw-head keep-outs on the outer side **shall** stay free at both sites.
- Sites A and B **shall** be wired in parallel ahead of the eFuse: J20 to J22 (+12V_IN) and J21 to J23 (GND). Only one bus bar lands on a module, so only one site carries current. Each site-to-eFuse path must carry ≥ 15 A.
  - Put the eFuse near the top centre (about X 40–64, Y 125–145) so that neither path is longer than ≈ 50 mm.
  - Example: ≥ 10 mm wide pours on two 2 oz layers. A 50 mm path is ≈ 0.6 mΩ per polarity, so the round trip drops ≈ 15 mV at 12.5 A [Estimate].
  - The KiCad template draws reference tracks: In1 for +12V_IN at Y 140, In4 for GND at Y 163.4. Replace them with pours.
- **The idle site is live** (12 V and GND pads exposed on both sides).
  - Do not use it as a test point.
  - Keep ≥ 0.5 mm copper-to-edge clearance; the site B pads come 2.3 mm from the left edge, the same as site A on the right.
  - If MF-1 finds a core feature within 1.0 mm of the board at the idle site, cover that site's core-side pads with polyimide tape (Kapton, 0.06 mm) on that face [Proposal].
- **Polarity:** a mirror image in X keeps the Y order, so the template assumes +12V_IN at the lower lug (Y 147.4) of both sites [Inference]. **The polarity of each face is TO MEASURE (M5).**
  - If the faces turn out to differ, only the net names at site B swap; the geometry stays the same.
  - The reverse-polarity rule (§6.5) protects a module built on a wrong guess.
- **Screws:** stock 2 × T8 923-0716 go into the site in use only.
- Single-site modules may be allowed in MECH 0x0002, once M5b says which face uses which site. Such a module would then set `slot_mask` to that face only.

### 6.5 Input protection, inrush, capacitance [Proposal]

- Every module drawing more than 3 W **shall** gate 12 V with an on-module **eFuse / hot-swap switch** enabled by **FACE_PWR_EN**. The bus bar is live whenever the PSU is on, and the host does not switch it.
  - Reference part: **TI TPS25982** (2.7–24 V, 15 A, integrated FET, adjustable I_LIM and dV/dt; LCSC **C2155766** TPS259824ONRGER ≈ $5.90; LNR variant C2155879 ≈ $4.34 with low stock).
  - For Face P, set I_LIM ≈ 1.3–1.5 × the class (≤ 16 A); for Face S, ≈ 5 A.
- **Capacitance ahead of the eFuse:** ≤ 47 µF (it is charged at PSU turn-on).
- **Inrush after EN:** ≤ 3 A (Face P) / ≤ 1 A (Face S), with dV/dt-limited soft-start. Declared in `inrush_da`.
- **Reverse polarity:** the module **shall survive** reversed lug polarity without damage, for example with an eFuse with blocking or a series ideal-diode controller. The stock lug polarity is still unmeasured, per face (§6.4.1). A polarity-agnostic input (ideal-diode bridge controller, LT4320-class, with 4 FETs) is optional [Proposal].
- **Overvoltage:** the module shall tolerate 10.8–13.2 V and survive 15 V.

### 6.6 3V3_AUX [Sourced: v0.2 §4.4, §7.8]

- Supplied by the BP over AUX pins 1–2: from 3V3_SB in S5, from 3V3_BP in S0.
- Limits: **≤ 1.0 A (3.3 W) in S0**; **≤ 15 mA / 50 mW in S5**.
- The ID EEPROM, temperature sensor and presence logic **shall** run on 3V3_AUX alone. Nothing on 3V3_AUX may back-feed the main rails.

### 6.7 Sequencing (power-button independent) [Proposal]

Modules never see the power button. The BP MCU and PCH handle it. A module reacts only to **3V3_AUX, FACE_PWR_EN and PERST0#**. See the timing diagram in `macpro62-face-v0.1-system.png`.

| Step | Event | Owner | Requirement |
|---|---|---|---|
| 1 | AC on → 3V3_AUX (S5 level) | BP | The module draws ≤ 50 mW and answers on SMBus within 50 ms (EEPROM 0x50, sensor 0x48). |
| 2 | BP reads and validates the EEPROM: magic, CRC, class, slot, budget | BP MCU | Invalid or missing EEPROM → FACE_PWR_EN stays low (dev-mode override on the BP only). |
| 3 | Power-on request → PSU on (PS_ON#) → 12 V present at the lugs | BP / PSU | The module tolerates 12 V without EN, drawing only the eFuse quiescent current. |
| 4 | BP raises **FACE_PWR_EN** (after PWR_OK) | BP | — |
| 5 | Module soft-starts and releases **FACE_PWR_GOOD** | Module | **≤ 150 ms** after EN (`t_pg_ms`). Drive no PCIe, display, USB or sideband signal before PG. |
| 6 | REFCLK0 running, stable for ≥ 100 µs | BP | — |
| 7 | **PERST0# deasserted ≥ 100 ms after PG** (T_PVPERL), as PLTRST# ∧ FACE_RDY | BP | The module's PCIe device starts link training. |
| 8 | Shutdown / S5: **PERST0# asserted first**, then FACE_PWR_EN low after ≥ 1 ms | BP | The module drops PG and turns off its rails within **10 ms**. 12 V may stay present (the PSU turns off later). |
| 9 | **Faults:** PG falling in S0; FACE_PRSNT# or MCIO_PRSNT0# changing; THERM_TRIP# | BP / hardware | PG loss → the BP asserts PERST0#, drops EN and logs FAULT; at most one retry after 1 s. THERM_TRIP# latches the PSU off in hardware. |

**Not supported in v0.1:** S3 (suspend-to-RAM) with modules powered, D3cold / L2 wake from 3V3_AUX, and hot-plug.

## 7. Sideband summary [v0.1]

| Function | Signal(s) | Path | Rev-A host behaviour | Module requirement |
|---|---|---|---|---|
| Reference clock | REFCLK0± (REFCLK1± set B) | MCIO | Free-running 100 MHz HCSL in S0 | Shall use REFCLK0 (common clock) |
| Reset | PERST0# (PERST1#) | MCIO | PLTRST# ∧ FACE_RDY | Shall honour |
| Clock request | CLKREQ0# (BP_TYPE position) | MCIO | Pulled up, ignored | May drive only if `clk_flags.bit2` |
| Wake | WAKE0# | MCIO | Pull-up; ORed into WAKE0# on the BP | Optional (rev A has no S3) |
| Presence | FACE_PRSNT# (AUX), MCIO_PRSNT0# (MCIO), DLINK_PRSNT# (DISPLAY-LINK, to the IOB) | AUX / MCIO / display cable | Mismatch = FAULT (cable missing) | Shall tie to GND |
| Power control | FACE_PWR_EN, FACE_PWR_GOOD | AUX | §6.7 | Shall implement |
| Management | FACE_SMB_CLK/DAT/ALERT# | AUX | One segment per face, BP MCU master, 100 kHz | EEPROM 0x50 + sensor 0x48 mandatory |
| Device SMBus | PCIE_SMCLK/DAT | MCIO | NC in rev A | Optional; never the ID EEPROM |
| Thermal | THERM_ALERT# (bidirectional), THERM_TRIP# | AUX | Fan curve from the sensors; THERM_TRIP# latches the PSU off | Shall implement |
| Fan | — | — | **Host-owned** (BP fan control) | No fans on modules |
| LED | MOD_LED# | AUX | Mirrored to the face status LED | Should drive |
| USB2 | USB2_D± | AUX | BP USB2 hub port per face (TBD on the BP) | Optional (firmware update, MCU) |
| Display | DISPLAY-LINK | Separate cable to the IOB | — | §9 |
