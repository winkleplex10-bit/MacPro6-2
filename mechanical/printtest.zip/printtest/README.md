# MP62 / Mac Pro 6,1 PCB fit-test prints

3D-printable size-test models of the MacPro6,2 backplane and the stock Mac Pro 6,1 boards, for checking fit in the thermal core on a hobby FDM printer. All models are 1:1 in mm and built from 1:1 DXF/KiCad sources with CadQuery 2.8 (`/workspace/cadenv`). Every part comes as **STL** (for slicing) and **STEP** (for CAD).

Each board has a **true-thickness** version and a **stiff 3 mm print** version. The 3 mm version has the same outline and holes and only differs in Z. Use it for handling and outline/hole tests. Use the true-thickness version when the thickness matters, for example in slots, card edges or a stack-up.

## Files

Dimensions are the STL bounding box (X × Y × Z, mm), measured with trimesh after export. "Watertight" means trimesh reports the mesh as watertight, winding-consistent and a valid volume. All 34 STL/STEP files were checked. Each STEP re-imports as 1 valid solid with the same volume.

### New MP62 backplane (BP)

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `backplane_new_1.6mm_flat.stl` / `.step` | 122.00 × 121.96 × 1.60 | 1.6 | yes | courtyards engraved 0.6 w x 0.4 deep |
| `backplane_new_1.6mm_connectors.stl` / `.step` | 122.00 × 121.96 × 11.60 | 1.6 | yes | courtyards engraved 0.6 w x 0.4 deep; connector blocks on top |
| `backplane_new_3mm_flat.stl` / `.step` | 122.00 × 121.96 × 3.00 | 3.0 | yes | courtyards engraved 0.6 w x 0.4 deep |
| `backplane_new_3mm_connectors.stl` / `.step` | 122.00 × 121.96 × 13.00 | 3.0 | yes | courtyards engraved 0.6 w x 0.4 deep; connector blocks on top |

### Stock CPU riser

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `cpu_riser_2.0mm.stl` / `.step` | 156.00 × 167.78 × 2.00 | 2.0 | yes | stock CPU riser |
| `cpu_riser_1.6mm.stl` / `.step` | 156.00 × 167.78 × 1.60 | 1.6 | yes | stock CPU riser |
| `cpu_riser_3mm.stl` / `.step` | 156.00 × 167.78 × 3.00 | 3.0 | yes | stock CPU riser |

### Stock GPU board

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `gpu_board_1.6mm.stl` / `.step` | 104.00 × 166.00 × 1.60 | 1.6 | yes | stock GPU board |
| `gpu_board_3mm.stl` / `.step` | 104.00 × 166.00 × 3.00 | 3.0 | yes | stock GPU board |

### Stock I/O board

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `io_board_1.6mm.stl` / `.step` | 101.00 × 173.62 × 1.60 | 1.6 | yes | stock I/O board |
| `io_board_3mm.stl` / `.step` | 101.00 × 173.62 × 3.00 | 3.0 | yes | stock I/O board |

### Stock PSU board

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `psu_board_1.6mm.stl` / `.step` | 102.96 × 159.02 × 1.60 | 1.6 | yes | stock PSU board |
| `psu_board_3mm.stl` / `.step` | 102.96 × 159.02 × 3.00 | 3.0 | yes | stock PSU board |

### GPU retention bracket

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `gpu_bracket_1.5mm-thickness-unknown.stl` / `.step` | 83.40 × 58.83 × 1.50 | 1.5 | yes | GPU retention bracket; thickness NOT measured |
| `gpu_bracket_3mm.stl` / `.step` | 83.40 × 58.83 × 3.00 | 3.0 | yes | GPU retention bracket; thickness NOT measured |

### Stock base/logic board (extra reference)

| File | Bbox X × Y × Z (mm) | Board t (mm) | Watertight | Notes |
|---|---|---|---|---|
| `base_board_stock_1.0mm.stl` / `.step` | 122.00 × 121.96 × 1.00 | 1.0 | yes | stock logic/base board |
| `base_board_stock_3mm.stl` / `.step` | 122.00 × 121.96 × 3.00 | 3.0 | yes | stock logic/base board |

Also: `preview_all_parts.png` (an iso view and top view of the true-thickness set, plus the backplane courtyard map), and `src/` (build scripts and `build_report.json` with all checks, hole lists and block data).

## Sources and what was modelled

**New backplane** (`kicad/macpro62-backplane/backplane.kicad_pcb`, rev A-fp2-hub, 1.6 mm 6-layer):
- Outline: the Edge.Cuts circle, Ø122.0, centre KiCad (150.0, 100.0). Model frame: origin at the disc centre, +Y = KiCad −Y, which is the spec frame (J1 at (0, −12.6), the MCIOs on the +Y core side, M.2 and PSU-IN on the −Y PSU side). Seen from the component (top) side.
- Holes: 2 × Ø4.0 at (±49, 0), taken from the H1/H2 MountingHole_4mm_Pad drills. Small footprint drills are **not** modelled: J1 board locks Ø1.1, MCIO pegs Ø1.3, Micro-Fit pins/pegs Ø1.02, M.2 standoff Ø2.2.
- Courtyards: every footprint courtyard (F.CrtYd) is **engraved** into the top face, 0.6 mm wide and 0.4 mm deep (2 layers at 0.2 mm), centred on the courtyard line. This shows where every part sits without changing the board thickness. In the `_connectors` versions, the parts that have a block are not engraved.
- `_connectors` versions add solid boxes on the top face. Each box uses the **KiCad courtyard** footprint (position and rotation from the PCB file) and the height from the spec:

| Ref | Part | Centre (x, y) | Rot | Box W × D (courtyard) | Height above board top | Real body / note |
|---|---|---|---|---|---|---|
| J1 | CPU-LINK Amphenol Mini Cool Edge 224 vertical | (-0.00, -12.60) | +0° | 86.40 × 7.50 | 6.0 | Spec: keep-out 85.86 × 6.30, 85.56 overall; height "≈ 6 class" (4C+ sibling 5.95 max) [estimate] |
| J9 | MCIO 124 right-angle, Face P | (29.79, 22.51) | -60° | 45.50 × 25.90 | 10.0 | Courtyard includes the 13.1 mm straight-plug and cable-exit zone; RA receptacle height ≈ 9–10 [estimate, drawing not read] |
| J10 | MCIO 124 right-angle, Face S | (-29.79, 22.51) | +60° | 45.50 × 25.90 | 10.0 | Same as J9 (Face S) |
| J7 | M.2 2242 socket area | (0.00, -30.00) | +0° | 50.50 × 23.00 | 4.0 | M.2 M-key socket plus the 2242 card area (socket fab 5 × 22, card 42 × 22); spec "≈ 4 mm" envelope |
| J2 | PSU-IN Micro-Fit 2×4 | (-13.00, -48.00) | +0° | 17.16 × 9.78 | 9.9 | Molex Micro-Fit 3.0 2×4 vertical 43045-0812; spec "≈ 9.9 mm" [estimate] |

- The blocks are solid envelopes. J1 has **no card slot**, so the printed CPU riser cannot be plugged into it. In the 3 mm versions the blocks sit on the 3 mm top face, so the heights above the board top are true but the total stack is 1.4 mm taller than the real board.

**Stock CPU riser** (`bracket/cpu_board/cpu_board_outline_corrected.dxf`): layer OUTLINE_CORRECTED (the outline Aidan confirmed, with true arcs) + 4 × Ø5.0 HOLES_HEATSINK + 4 × Ø5.0 ILM_SCAN holes (the scanned ILM positions, not ILM_CAD). DXF frame (tab tip at the bottom). Thickness has not been measured; the Fusion CAD uses 2.0. The 1.6 version is for the new 1.57 mm Mini Cool Edge card.

**Stock GPU board** (`macpro62-cad/v2/gpu_board_outline.dxf`): OUTLINE + 4 × Ø5.0 holes (74 × 50 pattern). The STL volume at 1.6 mm (27 110.8 mm³) matches Fusion Body4 exactly.

**Stock I/O board** (`bracket/io_board/io_board_outline.dxf`, back-side view): BOARD_OUTLINE + POWER_PLUG_CUTOUT (31.95 × 22.98) + the 6 plated MOUNT_HOLES. Their through-hole sizes are scan estimates, Ø3.76–4.28 ±0.5. The 2 small Ø2.8 MEG-Array flank holes are **not** included.

**Stock PSU board** (`macpro62-cad/v2/psu_board_outline.dxf`): OUTLINE + 6 × Ø2.0 holes. The underside Ø3 × 2 mm standoff bosses are not modelled.

**GPU retention bracket** (`bracket/gpu_bracket_outline.dxf`): OUTLINE (traced from a 75 dpi scan as a 262-point polyline, so the edges are slightly faceted) + 4 × Ø5.65–5.67 holes + the Ø25.5 centre ring hole. **Thickness unknown**: 1.5 mm is a placeholder, and the 3 mm version is for stiffness.

**Stock base board** (`macpro62-cad/v2/base_board_outline.dxf`): Ø122, 2 × Ø4 at ±49, 1.0 mm (Fusion). This is an extra for comparison against the new BP; it is the same disc without courtyards.

Cross-checks: the imported outline areas match an independent ezdxf flattening to within 0.02 mm² (CPU 24 594.7, I/O 16 996.1, cutout 663.4, bracket 1 602.8 mm²). The STL bbox matches the source outline to within 0.04 mm. The only deviation is the disc tessellation chord: 121.96 vs 122.00 in Y.

## Holes are print-true (no compensation)

Holes are modelled at their nominal CAD/scan diameter. **FDM printers usually print holes about 0.2–0.3 mm undersize** (more for small holes), and the outer outline can grow slightly from elephant's foot on the first layer. If a screw or standoff does not pass, ream or drill the hole to size (Ø4 → 4 mm drill, Ø5 → 5 mm drill). Don't scale the whole part. Small holes like the PSU Ø2.0 may close up almost completely.

## Print tips

1. **Check the scale with a ruler first.** Import at **100 % scale** (units mm). Print one small part first and measure a known distance: BP/base hole spacing **98.00** mm centre to centre, GPU hole pattern **74.0 × 50.0**, CPU heatsink pattern **69.5 × 55.0**, disc **Ø122.0**. Measure centre to centre, or edge to edge plus one hole diameter.
2. **Flat on the bed**, large face down (as exported, Z up). Don't rotate the parts onto an edge. For the `_connectors` backplane, the board face goes down and the blocks point up. No supports are needed.
3. **0.2 mm layers.** 1.6 mm = 8 layers, 1.0 mm = 5, 3 mm = 15. Use 3–4 perimeters, and 100 % infill (or ≥ 40 %) for the thin versions so they do not flex. PLA or PETG.
4. Thin, large parts warp. Use a clean bed, a brim (3–5 mm) or mouse ears on the corners, and no part-cooling fan for the first layers. Calibrate the first layer squish, because it sets the true thickness on the 1.0/1.6 mm parts.
5. Bed size: the CPU riser is 156 × 168 mm and the I/O board is 101 × 174 mm, so these need a bed of at least about 175 mm in one axis, or a diagonal placement. Everything else fits a 165 mm bed.
6. The courtyard grooves on the backplane are 0.6 mm wide. With a 0.4 mm nozzle they come out as shallow lines. If your slicer fills them in, enable "detect thin walls / gap fill = off" or ignore it, since they are only markings.

## Known issues / to verify

- **PSU thickness:** printed at **1.6 mm as requested**, but the Fusion CAD (Body1) is **1.2 mm** plus 2 mm bosses. Measure with calipers.
- None of the stock-board thicknesses were measured: CPU 2.0 (CAD), GPU 1.6 (CAD), I/O 1.6 (assumed), bracket 1.5 (placeholder).
- The connector heights are spec estimates: J1 ≈ 6, MCIO RA ≈ 10, M.2 ≈ 4, Micro-Fit ≈ 9.9. The block footprints are KiCad courtyards, which include the assembly margin. J1's courtyard (86.40 × 7.50) is 0.54 × 1.20 mm larger than the 85.86 × 6.30 keep-out, so the blocks are slightly conservative.
- The backplane positions are rev A-fp2/fp3 placeholders. J1 sits on the estimated stock riser-slot chord, y = −12.6, which has not been measured (M2b).
- The I/O hole diameters are ±0.5 scan estimates. The GPU bracket outline comes from a 75 dpi scan.

## Rebuild

```
source /workspace/cadenv/bin/activate
python /workspace/printtest/src/build.py      # STL + STEP + build_report.json
python /workspace/printtest/src/render.py     # preview_all_parts.png
python /workspace/printtest/src/write_readme.py
```
