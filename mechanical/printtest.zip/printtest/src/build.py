"""Build 3D-printable fit-test models (STL + STEP) of MacPro6,2 / Mac Pro 6,1 PCBs."""
import json, math, os, sys
import numpy as np
import cadquery as cq
import ezdxf
from ezdxf import path as ezpath

sys.path.insert(0, os.path.dirname(__file__))
import kicad_parse as kp

W = '/workspace'
OUT = f'{W}/printtest'
os.makedirs(OUT, exist_ok=True)

def dxf_area(fname, layer):
    """Independent area of a closed LWPOLYLINE outline (ezdxf bulge flattening) for cross-checking."""
    m = ezdxf.readfile(fname).modelspace()
    ents = [e for e in m if e.dxf.layer == layer and e.dxftype() == 'LWPOLYLINE']
    if len(ents) != 1:
        return float('nan')
    v = np.array([(q.x, q.y) for q in ezpath.make_path(ents[0]).flattening(0.002)])
    return 0.5*abs(np.dot(v[:-1, 0], v[1:, 1]) - np.dot(v[1:, 0], v[:-1, 1]))

def circles(fname, layers):
    m = ezdxf.readfile(fname).modelspace()
    return [(e.dxf.center.x, e.dxf.center.y, 2*e.dxf.radius, e.dxf.layer)
            for e in m if e.dxftype() == 'CIRCLE' and e.dxf.layer in layers]

def outline_face(fname, layer):
    wp = cq.importers.importDXF(fname, include=[layer])
    f = wp.faces().vals()
    assert len(f) == 1 and f[0].isValid(), (fname, layer, len(f))
    return f[0]

def board_from_dxf(fname, outline_layer, hole_layers, t, cut_layers=()):
    face = outline_face(fname, outline_layer)
    solid = cq.Workplane('XY').add(face).wires().toPending().extrude(t)
    # inner cutouts (e.g. power-plug window)
    for L in cut_layers:
        cf = outline_face(fname, L)
        cut = cq.Workplane('XY').add(cf).wires().toPending().extrude(t + 2).translate((0, 0, -1))
        solid = solid.cut(cut)
    hs = circles(fname, hole_layers)
    for (x, y, d, _) in hs:
        solid = solid.cut(cq.Workplane('XY').center(x, y).circle(d/2).extrude(t + 2).translate((0, 0, -1)))
    return solid, face, hs

# ---------------------------------------------------------------- backplane
PCB = f'{W}/kicad/macpro62-backplane/backplane.kicad_pcb'
edge, fps = kp.load(PCB)
ec = edge[0]
cx, cy = float(kp.first(ec, 'center')[1]), float(kp.first(ec, 'center')[2])
ex = float(kp.first(ec, 'end')[1]); ey = float(kp.first(ec, 'end')[2])
R = math.hypot(ex-cx, ey-cy)
def B(p):  # KiCad (y down) -> disc frame, origin = disc centre, +y up (spec frame)
    return (p[0]-cx, -(p[1]-cy))

FP = {f['ref']: f for f in fps}
# tall parts: ref -> (height above board top, note)
TALL = {
    'J1':  (6.0,  'CPU-LINK Amphenol Mini Cool Edge 224 vertical (ME1022410103011); spec: keep-out 85.86 x 6.30, height ~6 class (4C+ sibling 5.95 max) [estimate]'),
    'J9':  (10.0, 'MCIO 124 right-angle receptacle, Face P (placeholder courtyard incl. 13.1 mm plug/cable zone); spec: ~9-10 mm [estimate]'),
    'J10': (10.0, 'MCIO 124 right-angle receptacle, Face S (placeholder courtyard incl. plug/cable zone); spec: ~9-10 mm [estimate]'),
    'J7':  (4.0,  'M.2 M-key socket + 2242 card area (placeholder courtyard); spec: ~4 mm'),
    'J2':  (9.9,  'PSU-IN Molex Micro-Fit 3.0 2x4 vertical (43045-0812); spec: ~9.9 mm [estimate]'),
}

def courtyard_segments(f):
    segs = []; rings = []
    for kind, pts, extra in f['crtyd']:
        P = [B(p) for p in pts]
        if kind == 'poly':
            segs += [(P[i], P[(i+1) % len(P)]) for i in range(len(P))]
        elif kind == 'line':
            segs.append((P[0], P[1]))
        elif kind == 'circle':
            rings.append((P[0], extra))
        elif kind == 'arc':
            segs += [(P[0], P[1]), (P[1], P[2])]
    return segs, rings

def courtyard_poly(f):
    """Ordered courtyard rectangle corners in disc frame (all tall parts have rectangular courtyards)."""
    segs, _ = courtyard_segments(f)
    pts = np.array([s[0] for s in segs] + [s[1] for s in segs])
    # oriented rectangle from footprint rotation
    a = math.radians(f['rot'])
    u = np.array([math.cos(a), math.sin(a)]); v = np.array([-math.sin(a), math.cos(a)])
    pu, pv = pts @ u, pts @ v
    c = (pu.min()+pu.max())/2*u + (pv.min()+pv.max())/2*v
    return c, pu.max()-pu.min(), pv.max()-pv.min(), f['rot']

GROOVE_W, GROOVE_D = 0.6, 0.4

def backplane(t, with_blocks):
    disc = cq.Workplane('XY').circle(R).extrude(t)
    holes = []
    for f in fps:
        if f['lib'].startswith('MountingHole'):
            for p, d in f['drills']:
                x, y = B(p); holes.append((f['ref'], x, y, d))
                disc = disc.cut(cq.Workplane('XY').center(x, y).circle(d/2).extrude(t+2).translate((0, 0, -1)))
    # engraved courtyard outlines (top face), skipped where a block sits
    grooves = None
    for f in fps:
        if f['lib'].startswith('MountingHole'):
            continue
        if with_blocks and f['ref'] in TALL:
            continue
        segs, rings = courtyard_segments(f)
        for (a, b) in segs:
            L = math.hypot(b[0]-a[0], b[1]-a[1])
            if L < 1e-6: continue
            ang = math.degrees(math.atan2(b[1]-a[1], b[0]-a[0]))
            g = (cq.Workplane('XY').box(L + GROOVE_W, GROOVE_W, GROOVE_D + 1, centered=(True, True, False))
                 .rotate((0, 0, 0), (0, 0, 1), ang)
                 .translate(((a[0]+b[0])/2, (a[1]+b[1])/2, t - GROOVE_D)))
            grooves = g if grooves is None else grooves.union(g)
    if grooves is not None:
        disc = disc.cut(grooves)
    blocks = []
    if with_blocks:
        for ref, (h, note) in TALL.items():
            c, lu, lv, rot = courtyard_poly(FP[ref])
            blk = (cq.Workplane('XY').box(lu, lv, h, centered=(True, True, False))
                   .rotate((0, 0, 0), (0, 0, 1), rot).translate((c[0], c[1], t)))
            disc = disc.union(blk)
            blocks.append(dict(ref=ref, centre=[round(c[0], 3), round(c[1], 3)], size=[round(lu, 3), round(lv, 3), h], rot=rot, note=note))
    return disc, holes, blocks

# ---------------------------------------------------------------- stock parts
CPU = f'{W}/bracket/cpu_board/cpu_board_outline_corrected.dxf'
GPU = f'{W}/macpro62-cad/v2/gpu_board_outline.dxf'
IOB = f'{W}/bracket/io_board/io_board_outline.dxf'
PSU = f'{W}/macpro62-cad/v2/psu_board_outline.dxf'
BRK = f'{W}/bracket/gpu_bracket_outline.dxf'
BASE = f'{W}/macpro62-cad/v2/base_board_outline.dxf'

def io_holes_6():
    # the 6 plated mounting holes (exclude the 2 small MEG-flank holes, d=2.8)
    return [h for h in circles(IOB, ['MOUNT_HOLES']) if h[2] > 3.0]

parts = []   # dicts: name, solid, t, expected bbox, source, notes

def add(name, solid, t, exp_xy, src, notes, extra=None, exp_z=None):
    parts.append(dict(name=name, solid=solid, t=t, exp=(exp_xy[0], exp_xy[1], exp_z if exp_z else t),
                      src=src, notes=notes, extra=extra or {}))

def exp_from_face(fname, layer):
    bb = outline_face(fname, layer).BoundingBox()
    return (bb.xlen, bb.ylen)

# backplane (new): 1.6 true + 3.0 stiff, with/without blocks
for t, tag in ((1.6, '1.6mm'), (3.0, '3mm')):
    for wb in (False, True):
        s, holes, blocks = backplane(t, wb)
        hmax = max(b['size'][2] for b in blocks) if blocks else 0
        add(f"backplane_new_{tag}_{'connectors' if wb else 'flat'}", s, t, (2*R, 2*R),
            'kicad/macpro62-backplane/backplane.kicad_pcb (Edge.Cuts disc, MountingHole drills, F.CrtYd)',
            'courtyards engraved 0.6 w x 0.4 deep' + ('; connector blocks on top' if wb else ''),
            dict(holes=holes, blocks=blocks), exp_z=t + hmax)

# stock base board (Fusion v2) - optional reference
for t, tag in ((1.0, '1.0mm'), (3.0, '3mm')):
    s, f, hs = board_from_dxf(BASE, 'OUTLINE', ['HOLES'], t)
    add(f'base_board_stock_{tag}', s, t, (122.0, 122.0), 'macpro62-cad/v2/base_board_outline.dxf', 'stock logic/base board', dict(holes=hs))

for t, tag in ((2.0, '2.0mm'), (1.6, '1.6mm'), (3.0, '3mm')):
    s, f, hs = board_from_dxf(CPU, 'OUTLINE_CORRECTED', ['HOLES_HEATSINK', 'ILM_SCAN'], t)
    add(f'cpu_riser_{tag}', s, t, exp_from_face(CPU, 'OUTLINE_CORRECTED'),
        'bracket/cpu_board/cpu_board_outline_corrected.dxf (OUTLINE_CORRECTED, HOLES_HEATSINK, ILM_SCAN)', 'stock CPU riser', dict(holes=hs))

for t, tag in ((1.6, '1.6mm'), (3.0, '3mm')):
    s, f, hs = board_from_dxf(GPU, 'OUTLINE', ['HOLES'], t)
    add(f'gpu_board_{tag}', s, t, exp_from_face(GPU, 'OUTLINE'), 'macpro62-cad/v2/gpu_board_outline.dxf', 'stock GPU board', dict(holes=hs))

for t, tag in ((1.6, '1.6mm'), (3.0, '3mm')):
    s = None
    face = outline_face(IOB, 'BOARD_OUTLINE')
    s = cq.Workplane('XY').add(face).wires().toPending().extrude(t)
    cf = outline_face(IOB, 'POWER_PLUG_CUTOUT')
    s = s.cut(cq.Workplane('XY').add(cf).wires().toPending().extrude(t + 2).translate((0, 0, -1)))
    hs = io_holes_6()
    for (x, y, d, _) in hs:
        s = s.cut(cq.Workplane('XY').center(x, y).circle(d/2).extrude(t + 2).translate((0, 0, -1)))
    add(f'io_board_{tag}', s, t, exp_from_face(IOB, 'BOARD_OUTLINE'),
        'bracket/io_board/io_board_outline.dxf (BOARD_OUTLINE, POWER_PLUG_CUTOUT, 6x MOUNT_HOLES)', 'stock I/O board', dict(holes=hs))

for t, tag in ((1.6, '1.6mm'), (3.0, '3mm')):
    s, f, hs = board_from_dxf(PSU, 'OUTLINE', ['HOLES'], t)
    add(f'psu_board_{tag}', s, t, exp_from_face(PSU, 'OUTLINE'), 'macpro62-cad/v2/psu_board_outline.dxf', 'stock PSU board', dict(holes=hs))

for t, tag in ((1.5, '1.5mm-thickness-unknown'), (3.0, '3mm')):
    s, f, hs = board_from_dxf(BRK, 'OUTLINE', ['HOLES'], t)
    add(f'gpu_bracket_{tag}', s, t, exp_from_face(BRK, 'OUTLINE'), 'bracket/gpu_bracket_outline.dxf (OUTLINE, HOLES)', 'GPU retention bracket; thickness NOT measured', dict(holes=hs))

# ---------------------------------------------------------------- export + checks
import trimesh
report = []
for p in parts:
    s = p['solid']
    sol = s.val()
    assert sol.isValid(), p['name']
    stl = f"{OUT}/{p['name']}.stl"; stp = f"{OUT}/{p['name']}.step"
    cq.exporters.export(s, stl, tolerance=0.01, angularTolerance=0.1)
    cq.exporters.export(s, stp)
    m = trimesh.load(stl)
    ext = m.bounding_box.extents
    exp = np.array(p['exp'])
    dev = np.abs(ext - exp).max()
    r = dict(name=p['name'], watertight=bool(m.is_watertight), winding=bool(m.is_winding_consistent),
             volume_ok=bool(m.is_volume), faces=len(m.faces), bbox=[round(float(e), 3) for e in ext],
             expected=[round(float(e), 3) for e in exp], max_dev=round(float(dev), 4),
             bbox_ok=bool(dev < 0.05), mesh_vol=round(float(m.volume), 1), brep_vol=round(sol.Volume(), 1),
             t=p['t'], src=p['src'], notes=p['notes'],
             holes=[[round(h[1] if isinstance(h[0], str) else h[0], 3), round(h[2] if isinstance(h[0], str) else h[1], 3),
                     round(h[3] if isinstance(h[0], str) else h[2], 3)] for h in p['extra'].get('holes', [])],
             blocks=p['extra'].get('blocks', []),
             stl_kb=os.path.getsize(stl)//1024, step_kb=os.path.getsize(stp)//1024)
    report.append(r)
    print(f"{r['name']:42s} wt={r['watertight']} vol={r['volume_ok']} bbox={r['bbox']} exp={r['expected']} dev={r['max_dev']} V(mesh/brep)={r['mesh_vol']}/{r['brep_vol']}")

# area cross-check of DXF outline import vs ezdxf flattening
checks = {}
for fn, L in ((CPU, 'OUTLINE_CORRECTED'), (IOB, 'BOARD_OUTLINE'), (IOB, 'POWER_PLUG_CUTOUT'), (BRK, 'OUTLINE')):
    a1 = outline_face(fn, L).Area(); a2 = dxf_area(fn, L)
    checks[f'{os.path.basename(fn)}:{L}'] = (round(a1, 2), round(a2, 2), round(a1 - a2, 3))
    print('area', os.path.basename(fn), L, round(a1, 2), round(a2, 2))
json.dump(dict(parts=report, area_check=checks, disc_R=R, disc_centre_kicad=[cx, cy]), open(f'{OUT}/src/build_report.json', 'w'), indent=1)
