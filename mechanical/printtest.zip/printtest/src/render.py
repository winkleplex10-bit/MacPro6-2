import numpy as np, trimesh, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.collections import LineCollection
O = '/workspace/printtest'
names = ['backplane_new_1.6mm_connectors', 'backplane_new_1.6mm_flat', 'base_board_stock_1.0mm', 'gpu_bracket_1.5mm-thickness-unknown',
         'cpu_riser_2.0mm', 'gpu_board_1.6mm', 'io_board_1.6mm', 'psu_board_1.6mm']
cols = ['#2e7d32', '#43a047', '#9e9e9e', '#8d6e63', '#1565c0', '#c62828', '#6a1b9a', '#ef6c00']
meshes = []
x0 = 0; row = 0; y0 = 0; rowh = 0
place = []
for i, n in enumerate(names):
    m = trimesh.load(f'{O}/{n}.stl'); b = m.bounds
    if i == 4: x0 = 0; y0 -= rowh + 25; rowh = 0
    m.apply_translation([x0 - b[0, 0], y0 - b[1, 1], 0])  # top-aligned rows
    place.append((n, m)); x0 += (b[1, 0]-b[0, 0]) + 20; rowh = max(rowh, b[1, 1]-b[0, 1])
fig = plt.figure(figsize=(20, 16), dpi=110)
gs = fig.add_gridspec(2, 2, width_ratios=[1.6, 1], height_ratios=[1, 1.1])
ax = fig.add_subplot(gs[0, 0], projection='3d')
light = np.array([0.4, -0.5, 0.8]); light /= np.linalg.norm(light)
allv = []
for (n, m), c in zip(place, cols):
    v, f = trimesh.remesh.subdivide_to_size(m.vertices, m.faces, max_edge=3.0)
    mm = trimesh.Trimesh(v, f, process=False)
    tri = mm.vertices[mm.faces]
    sh = np.clip(mm.face_normals @ light, 0, 1)*0.6 + 0.4
    base = np.array(matplotlib.colors.to_rgb(c))
    fc = np.clip(base[None, :]*sh[:, None], 0, 1)
    ax.add_collection3d(Poly3DCollection(tri, facecolors=fc, edgecolors='none', linewidths=0))
    allv.append(m.vertices)
V = np.vstack(allv); mn, mx = V.min(0), V.max(0)
ax.set_xlim(mn[0], mx[0]); ax.set_ylim(mn[1], mx[1]); ax.set_zlim(0, 15)
ax.set_box_aspect((mx[0]-mn[0], mx[1]-mn[1], 15*3)); ax.view_init(elev=35, azim=-60)
ax.set_title('MP62 / Mac Pro 6,1 fit-test parts (true-thickness set, iso; Z exaggerated 3x, grid in mm)')
ax2 = fig.add_subplot(gs[1, :])
for (n, m), c in zip(place, cols):
    segs = trimesh.intersections.mesh_plane(m, [0, 0, 1], [0, 0, 0.5])
    ax2.add_collection(LineCollection(segs[:, :, :2], colors=c, linewidths=1))
    if m.bounds[1, 2] > 3:  # connector-block footprints
        zt = 1.6 + 1.0
        s2 = trimesh.intersections.mesh_plane(m, [0, 0, 1], [0, 0, zt])
        ax2.add_collection(LineCollection(s2[:, :, :2], colors='k', linewidths=1.6))
    b = m.bounds
    ax2.text((b[0, 0]+b[1, 0])/2, b[0, 1]-7, f"{n}\n{b[1,0]-b[0,0]:.2f} x {b[1,1]-b[0,1]:.2f} x {b[1,2]-b[0,2]:.2f} mm",
             ha='center', va='top', fontsize=8)
ax2.autoscale(); ax2.set_aspect('equal'); ax2.grid(alpha=0.3); ax2.set_title('Top view (section at z=0.5 mm; black = connector-block outlines at z=2.6)')
ax2.set_xlabel('mm'); ax2.set_ylabel('mm')
ax3 = fig.add_subplot(gs[0, 1])
import json
rep = {p['name']: p for p in json.load(open(f'{O}/src/build_report.json'))['parts']}
mb = trimesh.load(f'{O}/backplane_new_1.6mm_flat.stl')
for z, c, lw in ((0.8, 'g', 1.2), (1.4, 'k', 0.6)):
    sg = trimesh.intersections.mesh_plane(mb, [0, 0, 1], [0, 0, z])
    ax3.add_collection(LineCollection(sg[:, :, :2], colors=c, linewidths=lw))
for b in rep['backplane_new_1.6mm_connectors']['blocks']:
    ax3.text(b['centre'][0], b['centre'][1], f"{b['ref']}\n{b['size'][0]:.1f}x{b['size'][1]:.1f}\nh {b['size'][2]}", ha='center', va='center', fontsize=7, color='b')
ax3.autoscale(); ax3.set_aspect('equal'); ax3.grid(alpha=0.3)
ax3.set_title('backplane_new_1.6mm_flat: engraved courtyards (black, z=1.4)\nblue = blocks in *_connectors (W x D, height above board top)', fontsize=9)
plt.tight_layout(); plt.savefig(f'{O}/preview_all_parts.png'); print('ok')
