"""Minimal KiCad .kicad_pcb s-expression parser: Edge.Cuts, courtyards, drills."""
import re, math, json, sys

def tokenize(s):
    for m in re.finditer(r'\(|\)|"(?:[^"\\]|\\.)*"|[^\s()"]+', s):
        t = m.group(0)
        yield t

def parse(s):
    stack = [[]]
    for t in tokenize(s):
        if t == '(':
            stack.append([])
        elif t == ')':
            x = stack.pop(); stack[-1].append(x)
        else:
            if t.startswith('"'): t = t[1:-1]
            stack[-1].append(t)
    return stack[0][0]

def find(node, key):
    return [c for c in node if isinstance(c, list) and c and c[0] == key]

def first(node, key):
    r = find(node, key); return r[0] if r else None

def xy(n): return (float(n[1]), float(n[2]))

def load(path):
    root = parse(open(path).read())
    # board centre from Edge.Cuts circle
    edge = []
    for g in root:
        if not isinstance(g, list): continue
        if g[0].startswith('gr_') and first(g, 'layer') and first(g, 'layer')[1] == 'Edge.Cuts':
            edge.append(g)
    fps = []
    for fp in find(root, 'footprint'):
        at = first(fp, 'at'); x, y = float(at[1]), float(at[2]); rot = float(at[3]) if len(at) > 3 else 0.0
        side = first(fp, 'layer')[1]
        ref = None
        for p in find(fp, 'property'):
            if p[1] == 'Reference': ref = p[2]
        val = [p[2] for p in find(fp, 'property') if p[1] == 'Value'][0]
        def tf(lx, ly):
            # KiCad: footprint-local -> board; rotation is CCW on screen (y down) => use -rot
            a = math.radians(-rot)
            return (x + lx*math.cos(a) - ly*math.sin(a), y + lx*math.sin(a) + ly*math.cos(a))
        crt = []; fab = []
        for g in fp:
            if not (isinstance(g, list) and g and g[0].startswith('fp_')): continue
            L = first(g, 'layer'); L = L[1] if L else ''
            if g[0] == 'fp_rect':
                s = xy(first(g, 'start')); e = xy(first(g, 'end'))
                pts = [tf(s[0], s[1]), tf(e[0], s[1]), tf(e[0], e[1]), tf(s[0], e[1])]
                item = ('poly', pts, (s, e))
            elif g[0] == 'fp_poly':
                pts = [tf(*xy(p)) for p in find(first(g, 'pts'), 'xy')]
                item = ('poly', pts, None)
            elif g[0] == 'fp_line':
                item = ('line', [tf(*xy(first(g, 'start'))), tf(*xy(first(g, 'end')))], None)
            elif g[0] == 'fp_circle':
                c = xy(first(g, 'center')); e = xy(first(g, 'end'))
                item = ('circle', [tf(*c)], math.hypot(e[0]-c[0], e[1]-c[1]))
            elif g[0] == 'fp_arc':
                item = ('arc', [tf(*xy(first(g, k))) for k in ('start', 'mid', 'end')], None)
            else:
                continue
            if L.endswith('CrtYd'): crt.append(item)
            elif L.endswith('Fab'): fab.append(item)
        drills = []
        for pad in find(fp, 'pad'):
            d = first(pad, 'drill')
            if d:
                pa = first(pad, 'at'); dia = float(d[1])
                drills.append((tf(float(pa[1]), float(pa[2])), dia))
        fps.append(dict(ref=ref, value=val, lib=fp[1], x=x, y=y, rot=rot, side=side, crtyd=crt, fab=fab, drills=drills))
    return edge, fps

if __name__ == '__main__':
    edge, fps = load(sys.argv[1])
    for e in edge: print('EDGE', e[0], first(e, 'center'), first(e, 'end'))
    for f in fps:
        kinds = [(c[0], len(c[1])) for c in f['crtyd']]
        print(f"{f['ref']:5s} {f['side']} at=({f['x']:.3f},{f['y']:.3f}) rot={f['rot']:6.1f} crt={kinds} drills={[(round(p[0],2),round(p[1],2),dd) for p,dd in f['drills']]} {f['lib'].split(':')[-1]}")
