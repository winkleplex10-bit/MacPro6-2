# GPU board (D300/D500/D700 class): back side with the X bracket installed

Frame: **Fusion `gpu_board_outline.dxf`** (origin bottom-left, mm). The Fusion "bottom" (Y=0, with the 17×13 chamfered corners) is the **MEG-Array end**. Registration is a rigid least-squares fit of the 4 bracket screws to the Fusion 74 × 50 holes at (15/89, 44.5/94.5). The scan is viewed from the back (bracket) side, rotated 180° and not mirrored. Fusion doesn't say which face its outline is drawn from; if it is the front (die) view, mirror X about 52.

**Board thickness: not measurable from the scan** (Fusion says 1.6).

Files: `gpu_board_scan_features.dxf` (layers FUSION_OUTLINE/FUSION_HOLES for reference, BRACKET_SCREWS, BRACKET_OUTLINE (the traced bracket from the bracket-only scan, fitted onto the screws), DIE_CENTRE, CONN_MEG_ARRAY, MOUNT_HOLES_OTHER, KEEPOUT_INDUCTORS, KEEPOUT_CAPS, KEEPOUT_OTHER, SCAN_BOARD_EDGES (measured end edges), SCAN_DARK_ENVELOPE). Also `gpu_board_overlay.png`.

## Calibration

- The scan is 979×1311 px at about 100 dpi. The ruler sheet was rotated 2.09° on the glass, so the image was de-rotated before the mm-tick FFT. Result: X 3.9508 px/mm and Y 3.9376 px/mm, with inner and outer rulers agreeing to within 0.07 %. The anisotropy is 0.33 %.
- Check: the MEG-Array row pitch reads 1.270 / 1.266 mm (nominal 1.27).
- The contrast is low (black bracket on a black board), and the aluminium rails on the long sides are off-glass and blurred.

## Bracket screws (installed) vs 74 × 50

| screw | X | Y | Fusion hole | residual |
|---|---|---|---|---|
| TL (scan image) | 89.57 | 43.95 | (89, 44.5) | +0.57, -0.55 |
| TR (scan image) | 14.85 | 44.50 | (15, 44.5) | -0.15, -0.00 |
| BL (scan image) | 88.60 | 94.77 | (89, 94.5) | -0.40, +0.27 |
| BR (scan image) | 14.98 | 94.78 | (15, 94.5) | -0.02, +0.28 |

Spacings: X 74.72 (MEG side) / 73.62, Y 50.82 / 50.29, diagonals 90.26 / 89.25. That averages to 74.17 × 50.55. The rms residual to an ideal 74 × 50 is 0.49 mm, and the screw-centre uncertainty is about ±0.6 mm because the head and eyelet contrast is poor at 100 dpi. **It is consistent with 74 × 50.**
- **Cross-check against the bracket-only scan** (74.30 / 74.32 × 49.68 / 49.76, diagonals 89.49 / 89.34): the installed screws agree to within ±0.7 mm, which is inside this scan's uncertainty. The bracket outline traced from the bracket-only scan, fitted onto these screws, overlays the bracket in this image well (ring, arms and eyelets; see the overlay). Fit residual is 0.55 mm rms and rotation 0.02°.

## Bracket position, die centre and MEG-Array

- The screw-pattern centre (taken as the die / bracket-ring centre) is at **(52.00, 69.50)**, which is the Fusion hole-pattern centre (52.0, 69.5) by construction. The fitted bracket ring centre is (52.01, 69.46). In the bracket-only scan the ring centre and hole-pattern centre agree to within 0.04 mm.
- So the die centre sits on the board's long centreline (X 52 of 104) at 69.5 from the MEG end and 96.5 from the far end. The ±0.6 hole-fit error applies to all positions relative to the board.
- MEG-Array connector body: X 32.3–74.2, Y 0.0–18.5 (about 42 × 18, flush with the MEG-end edge). Centre (53.3, 8.8), ±1.
- Die centre relative to the MEG body centre: ΔX -1.3, ΔY +60.7. The MEG body is about 1.3 mm off the centreline in this (back) view.

## Board outline vs Fusion 104 × 166 with 17 × 13 corner cuts

- MEG-end edge: the scan edge is at Y 0.16 (Fusion 0). Chamfers: the scan's dark edge on the corner cuts is within about 0.1–0.3 mm of the Fusion 17 × 13 chamfers (p10 0.06). The chamfered corners at the MEG end are confirmed visually in the overlay.
- Far-end edge: Y 166.75, so the scan length is **166.6 ± 0.6 vs Fusion 166**. That is +0.6, within the registration error. The far-end corners are rounded, consistent with the Fusion R5.
- Long sides: **the scan can't measure them**. The off-glass rails darken a band about 3.5 mm beyond the Fusion edges on each side (dark envelope 111.5 wide). Visually, the Fusion 104 width lines up with the chamfer ends and the board edge in the overlay. **No significant disagreement with 104 × 166 was found**; width is unverified to about ±1.5.

## Other holes / mounts

- SCREW_MEG_L: (77.6, 2.6), head/standoff Ø≈5.9 (±0.8)
- SCREW_MEG_R: (27.2, 2.5), head/standoff Ø≈6.0 (±0.8)
- STANDOFF_1: (6.7, 147.4), head/standoff Ø≈8.8 (±0.8)
- STANDOFF_2: (6.9, 159.1), head/standoff Ø≈8.8 (±0.8)
- These four aren't in the Fusion model. SCREW_MEG_L/R are 2 silver screws flanking the MEG-Array, about 2.6 mm from the MEG edge. STANDOFF_1/2 are 2 large round standoffs near one side of the far end.

## Back-side keep-outs (component bodies, ±1 mm; DXF layers KEEPOUT_*)

- INDUCTOR_ROW: X 7.7–100.6, Y 111.9–131.2
- CAP_CLUSTER_RIGHT: X 15.7–39.3, Y 139.0–166.0
- CAP_CLUSTER_MID: X 62.5–78.5, Y 143.3–166.0
- CAP_CLUSTER_MEG_LEFT: X 75.9–94.8, Y 6.7–25.4
- SQ_INDUCTOR_TOP: X 74.1–87.2, Y 25.8–39.0
- CAP_TOP_RIGHT: X 16.0–23.1, Y 9.7–16.8
- The inductor row is 6 power inductors, each about 8 × 12.7, in one row at Y about 112–131. Individual bodies are on KEEPOUT_INDUCTORS. Electrolytic or polymer caps are about Ø6.3 each (KEEPOUT_CAPS circles). Heights can't be measured from the scan; the caps look tall (cans).
