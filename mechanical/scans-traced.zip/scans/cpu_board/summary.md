# CPU riser board: full trace from the sharp socket-side scan

Input: `scan.jpg` (1173×1294 px, about 100 dpi; sharp replacement scan, socket side). The gold fingers are at the bottom, the DIMM pairs are on the left and right, and the 4 power lugs are at the top. The earlier blurry scan is superseded.

Files (this folder): **`cpu_board_scan_features.dxf`** (R2010, mm, audit 0 errors), **`cpu_board_overlay.png`** (full-res, Fusion frame, 10 px/mm), `cpu_board_overlay_small.png`, `cpu_results.json`, `reg.json`, `probe.json`, `socket.json`, `lugs.json`, `rect.png` (the scan resampled into the Fusion frame: X = (u/10) − 15, Y = 200 − (v/10)).

DXF layers: FUSION_OUTLINE / FUSION_HOLES (the reference, copied from `cpu_board_outline.dxf`), SCAN_OUTLINE (traced board edge), SCAN_TAB (measured tab, key notch and gold-end line), HEATSINK_STANDOFFS, ILM_SCREWS, SOCKET_ILM, SOCKET_CENTRE, DIMM_SLOTS, DIMM_CENTRELINES, POWER_LUGS, KEEPOUT_COMPONENTS, GUIDE_POSTS, NOTES.

**Board thickness can't be measured from a scan.** Fusion uses 2.0; check the edge-tab thickness with calipers.

## Important: the reference DXF and the v2 summary disagree

`all_pcbs_v2_summary.md` (11:23) puts the 8 holes at x 40.0 / 109.5, i.e. the socket 3.25 mm left of the board centreline. **The current `cpu_board_outline.dxf` (modified 11:46) has them at x 43.25 / 112.75**, i.e. the socket is centred on x = 78. I registered to the DXF. **The scan supports the DXF:** the board, the tab and the socket are all centred to within ±0.3 mm (see below). The 3.25 mm offset in the v2 summary text is wrong, or out of date.

## Calibration and registration

- Both cm rulers were used. The ruler sheet is tilted −0.66° / +0.70° (H / V baselines), and is square to 0.04°. Tick FFT along the tilted baselines gives sx = 3.9517 and sy = 3.9358 px/mm (inner and outer rulers agree within 0.03 %; anisotropy 0.40 %). That matches the GPU scan from the same scanner (3.9508 / 3.9376).
- Scale check: the DDR3 DIMM contact pitch reads **1.004–1.006 mm** along Y (nominal 1.000), so the Y scale at slot level is right to about +0.5 %.
- Rigid least-squares fit (no scale) of the 8 measured holes to the DXF holes. The scan board is rotated -1.71° on the glass. **No mirror**: the socket-side view matches the DXF, because the key notch lands at x 86.97 against the DXF 87.0, and a mirror would put it at 69. Hole rms is 0.84 mm, dominated by the ILM-screw Y spacing (see below). The best uniform scale is 0.9966, so no scale correction is needed.

## Holes: 4 heatsink standoffs (outer, knurled) and 4 ILM screws (inner, black)

Centres come from radial-edge circle fits; the screw heads and standoff tops sit at the glass and are sharp. Centre uncertainty is about ±0.3 mm per hole, plus about ±0.3 mm registration. The visible Ø is the head or standoff, not the drilled hole, which is hidden.

| feature | X | Y | DXF | residual | visible Ø |
|---|---|---|---|---|---|
| HS_BL | 42.98 | 46.49 | (43.25, 46) | -0.27, +0.49 | 8.4 |
| HS_BR | 113.17 | 46.23 | (112.75, 46) | +0.42, +0.23 | 8.1 |
| HS_TL | 43.26 | 101.40 | (43.25, 101) | +0.01, +0.40 | 8.4 |
| HS_TR | 113.25 | 101.13 | (112.75, 101) | +0.50, +0.13 | 8.0 |
| ILM_BL | 43.59 | 56.53 | (43.25, 58) | +0.34, -1.47 | 9.0 |
| ILM_BR | 112.60 | 57.06 | (112.75, 58) | -0.15, -0.94 | 7.9 |
| ILM_TL | 43.30 | 89.67 | (43.25, 89) | +0.05, +0.67 | 8.0 |
| ILM_TR | 111.86 | 89.49 | (112.75, 89) | -0.89, +0.49 | 9.1 |

- **Heatsink (outer) pattern: X 70.19 / 69.99, Y 54.91 / 54.90, diagonals 89.01 / 89.06, against DXF 69.5 × 55 (diagonal 88.63).** That is X +0.6 (±0.4) and Y −0.1. It agrees with 69.5 × 55 to within about 0.6 mm. Treat X ≈ 70.0 ± 0.4 as possible.
- **ILM (inner) pattern: X 69.01 / 68.55, Y 33.14 / 32.44, diagonals 75.81 / 76.58, against DXF 69.5 × 31 (diagonal 76.11). Flag: Y reads about 32.8 ±0.5, i.e. +1.8 mm over the DXF 31.** X is about 68.8 (−0.7), so the ILM screws sit about 0.6 mm inboard of the standoff columns, while the DXF puts both patterns on the same x. Two independent circle-fit methods (gradient-ring and threshold-ring) agree to within 0.4 px (0.1 mm), so this isn't a fitting artefact. Measure the ILM screw spacing with calipers before relying on 31.
- Pattern centres: heatsink (78.16, 73.81), ILM (77.84, 73.19). DXF is (78.0, 73.5), and the centroid is fixed to it by the registration.

## Socket / ILM

- ILM assembly envelope (outer dark grooves): X 37.6–118.4 (80.8) × Y 41.2–104.7 (63.5), centre **(78.00, 72.95)**, ±0.5. The inner edges of the ILM cross-bars are at Y 52.3 and 98.3.
- Socket window / load-plate opening: X 61.1–95.8 (34.7) × Y 63.2–84.9 (21.7), centre **(78.45, 74.05)**. The left window edge is soft (±1); the others are ±0.3.
- Two bright ILM bosses/pins at (50.93, 74.02) and (105.73, 73.82), Ø≈3, centre (78.33, 73.92).
- **Socket centre: about (78.1 ±0.4, 73.6 ±0.6)**, combining the hole patterns, the ILM envelope, the window and the bosses. DXF: (78.0, 73.5). ✓

## Edge tab (gold fingers) vs DXF

The tab edges are the sharpest edges in the scan (white background), so these are ±0.3 mm, plus ±0.3 mm registration for absolute positions.

| item | scan | DXF | Δ |
|---|---|---|---|
| tab left / right edge X | 45.36 / 111.02 | 44.00 / 112.00 | +1.36 / -0.98 |
| **tab width** | **65.66** | 68.00 | **-2.34** |
| tab centre X | 78.19 | 78.00 | +0.19 |
| key notch X (half-max) | 85.92–88.03 | 84.50–89.50 | |
| **key notch width** | **2.12** (area-integral 2.32) | 5.00 | **-2.9** |
| key notch centre X | 86.97 (+8.78 from tab centre) | 87.00 (+9.0) | -0.03 ✓ |
| **key notch depth** (from tip) | **7.0** (rounded end at Y 8.74; end radius about half the width) | 16.06 (full tab depth, R2.5) | **-9.0** |
| finger segments (left / right) | 40.55 / 22.99 | 40.50 / 22.50 | +0.05 / +0.49 |
| tab tip Y | 1.72 | 0.00 | +1.72 |
| shoulder Y (left / right) | 13.18 / 12.78 | 16.06 | -3.08 |
| **tab depth** (tip to shoulder) | **11.26** | 16.06 | **-4.8** |
| gold fingers | Y 1.72–8.20 (6.5 long), 2 rows (Y about 1.7–4.6 and 5.6–8.2) | none | |
| tip to socket centre | 71.78 | 73.50 | -1.72 |

**Tab summary:** position, centring, notch position and the left segment agree with the DXF. Three things don't:
1. The **notch is about 2.2 wide, not 5**, and it stops about 7 mm above the tip instead of running the full tab depth.
2. The **tab is about 11.3 deep, not 16.06**: the shoulder is about 3 mm lower and the tip about 1.7 mm higher, relative to the holes.
3. The **tab is about 2.3 mm narrower** (65.7 vs 68). The right segment is +0.5.

The tip Y and shoulder Y are absolute positions. They include the ±0.3 hole-registration error, but the 11.3 depth doesn't depend on it. The gold-finger pitch reads about 1.4 mm, but at 100 dpi that's not a reliable standard, so it's not used.

## Board outline vs DXF

- Sides (50 % edge crossing; the side edges are soft, with a blur/shadow ramp about 4 mm wide): X -0.36 and 156.23, so **W = 156.59 ±0.8 against 156.0**. Board centre X 77.94 (DXF 78.0). There is a slight +0.6 mm widening from Y 30 to Y 165, within the edge uncertainty. Scan-to-DXF median distance on the sides is +0.1 mm. ✓
- Top edge: Y **169.8 ±0.3** where it is clean (X 48–104), against DXF 169 (+0.8). Board length tip→top = **168.1 ±0.5 against 169** (-0.9).
  - Near the DIMM end-caps (X 3–19 and 136–150) the edge is ambiguous, reading 166.5–169.5, because the slot ends and the shadow band merge.
  - The **two 24 × 5 top notches (X 24–48 and 108–132) can't be confirmed**: the lug bases cover them. The lug bases do sit inside the DXF notch spans (see Power lugs).
- **Lower corners: the scan doesn't match the DXF chamfers.**
  - DXF: the corner is cut from (0, 30) to (24, 16.06) with R5 fillets.
  - Scan: the side runs straight down to Y ≈ 21.5. A short step at Y ≈ 21 runs to X ≈ 5 (mirror: 151). A shallow cut of about 27° then reaches the shoulder (Y ≈ 13) at about X 20 (mirror: 137).
  - The scan board is **outside** the DXF there by a median 3.7 mm and up to 7.3 mm on the left (3.8 / 7.0 mm on the right). In other words, the DXF removes too much corner, and its shoulder is about 3 mm too high. These are soft edges (±1).
- The SCAN_OUTLINE polyline is the 50 % iso-contour (T = 128, or 75 in the top shadow band), smoothed and simplified to 0.12 mm. The tab is replaced by the measured tab, and the outline is clipped at Y 170 at the lug bases.

## DIMM slots (4 × DDR3, 2 per side)

- Card-slot centrelines (midway between each pair of contact rows, ±0.3): **X 6.5, 15.8 (left pair) and 140.55, 149.85 (right pair)**. That's a 9.3 pitch within each pair, and the pairs are symmetric about X ≈ 78.2.
- Slot-pair bodies (keep-out, ±1): left X 2.5–18.5, right X 137.0–153.0. Both run Y 22.5–168.2 including the end latches and caps, so **slot length ≈ 145.7 ±1**.
- Contact span Y 34.0–158.7 (124.7 mm, consistent with 240-pin DDR3 at 1.0 mm pitch). Slot height can't be measured.

## Power lugs (12 V bus-bar tabs)

- LUG1: leaves the top edge at X 23.8–31.8 (about 8.0 wide, centre 27.8), ±0.7
- LUG2: leaves the top edge at X 36.2–44.4 (about 8.2 wide, centre 40.3), ±0.7
- LUG3: leaves the top edge at X 110.0–117.6 (about 7.6 wide, centre 113.8), ±0.7
- LUG4: leaves the top edge at X 121.0–129.9 (about 8.9 wide, centre 125.5), ±0.7
- The left pair spans X 23.8–44.4 (DXF notch 24–48) and the right pair X 110.0–129.9 (DXF notch 108–132). Both pairs fall inside the DXF top notches.
- The pairs are not mirror-symmetric (left pair centre 34.1, right 119.95, about the board centre 78: offsets −43.9 / +41.95).
- Eyelet ring centres (projected; the lugs are bent out of the board plane toward the glass, so their positions are approximate, ±1.5): (34.5, 186.2) Ø≈6.8, (47.2, 187.8) Ø≈6.8, (111.8, 183.4) Ø≈6.0, (122.4, 181.9) Ø≈6.6. They project about 13–18 mm beyond the top edge.

## Large-component keep-outs (socket side, ±1.5; heights unknown)

- POWER_STAGE_ROW: X 45–113, Y 133.5–143.5
- TOP_IC: X 70–90, Y 148–164
- CAP_ARRAY_TOP_RIGHT: X 110–135, Y 154–163
- RIGHT_COMPONENT_COLUMN: X 114–124, Y 107–152
- POWER_STAGE_ROW is 6 parts at X ≈ 49, 60, 72, 84, 96, 108 (pitch about 11.8).
- Also on the keep-out layers: the ILM envelope (above), the 4 standoffs, both DIMM pairs, and the lugs.
- GUIDE_POSTS: 2 cylindrical posts, Ø≈6, at X 26.05–32.05 and 123.95–130.0 (centres 29.05 / 126.98, symmetric about 78.0). They run from the shoulder down to Y ≈ −2, i.e. alongside the tab, and are out of focus, so off the glass. They may be riser guide pins or part of the scan fixture; check them on the part.
- The lower area (Y 13–45) has only small parts.

## Confidence

- High (±0.3–0.5): hole positions and the heatsink spacing; tab edges, notch position and width, gold end; socket centre; DIMM centrelines; the board centring result.
- Medium (±0.8–1): board width, top edge, ILM envelope, lug bases.
- Low (±1.5): lower-corner shape, keep-out boxes, eyelets (out of plane).
- **Recommend calipers on:** the ILM screw Y spacing (31 vs about 32.8), the tab depth and notch (5 / full depth vs about 2.2 / 7), and the lower-corner geometry.