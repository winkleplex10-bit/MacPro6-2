# Mac Pro 6,1 GPU retention bracket: scan trace

All values are in mm. Frame: origin at the **centre-ring centre**, X/Y aligned to the hole rectangle (long side = X), Y up. The scan was rotated 180° (upside-down page) and is un-rotated here; 180° is a pure rotation, so nothing is mirrored. The part was rotated a further -2.61° on the glass, and that is removed.

**Thickness: NOT measurable from a flatbed scan.** Measure it with calipers or a micrometer.

## Files
- `gpu_bracket_outline.dxf`: OUTLINE (closed LWPOLYLINE, traced, 262 vertices), HOLES (4 eyelet holes + ring ID as circles), REFERENCE (fitted eyelet OD and ring OD circles), CENTER marks, DIMS (true DIMENSION entities: hole X/Y and diagonal spacings, envelope, ring ID, hole Ø), NOTES
- `gpu_bracket_keepout.dxf`: KEEPOUT = outline offset +1.0 mm (round joins; verified min/Hausdorff offset 0.98/1.02 mm). KEEPOUT_VOID = ring window −1.0 mm (Ø23.52), optional. REFERENCE = bracket outline and holes
- `gpu_bracket_overlay.png` (scan with features overlaid), `gpu_bracket_dims.png` (dimensioned drawing)
- Both DXFs: R2010, $INSUNITS = mm, ezdxf audit 0 errors.

## Calibration

- The scan is 637×877 px at about 75 dpi. Both printed rulers on the sheet are **cm** scales (inner 0–21 / 0–15, outer 1–25 / 1–18); there is no inch scale in the scan.
- From the cm-tick linear fits (inner and outer rulers agree to within 0.02 %): X (horizontal) **2.9691 px/mm**, Y (vertical) **2.9427 px/mm**. The scanner is anisotropic by **0.90 %**, and this is corrected per axis. Nominal 75 dpi would be 2.9528 px/mm.
- Is the ruler at true scale? On the I/O-board scan (same ruler sheet, same scanner), the MEG-Array contact pitch reads 1.2707/1.2703 mm against the nominal 1.27 mm. So the ruler print is accurate to about 0.1 % in both axes; it is **not** misprinted.

## Measurements

| feature | value | ± |
|---|---|---|
| eyelet hole TR centre | (37.12, 24.88) | 0.15 |
| eyelet hole TL centre | (-37.19, 24.91) | 0.15 |
| eyelet hole BL centre | (-37.15, -24.77) | 0.15 |
| eyelet hole BR centre | (37.17, -24.88) | 0.15 |
| eyelet hole Ø (4 holes: 5.66, 5.67, 5.65, 5.66) | **5.66** | 0.2 |
| eyelet outer Ø (8.89, 8.90, 9.01, 8.90) | **8.92** | 0.2 |
| eyelet OD-to-hole eccentricity | 0.07–0.13 | 0.1 |
| centre ring ID | **25.52** | 0.2 |
| centre ring OD (fitted between the arm roots) | **34.21** | 0.25 |
| ring wall (radial) | 4.34 | 0.2 |
| arm width (4 arms: 4.52, 4.47, 4.58, 4.44) | **4.50** (tapers about 0.2 toward the ring) | 0.2 |
| arm angle from the X axis | ±33.8° (the arms point radially at the hole centres; atan(50/74) = 34.0°) | 0.3° |
| overall envelope | **83.48 × 58.89** (X -41.75…41.73, Y -29.27…29.62) | 0.2 |
| hole-pattern centre vs ring centre | (-0.01, +0.04) | 0.15 |

## Hole pattern vs the 74 × 50 board pattern (Fusion: 4 × Ø5.0)

| spacing | measured | nominal | Δ |
|---|---|---|---|
| X_top | 74.30 | 74.00 | +0.30 |
| X_bot | 74.32 | 74.00 | +0.32 |
| Y_left | 49.68 | 50.00 | -0.32 |
| Y_right | 49.76 | 50.00 | -0.24 |
| D_TL_BR | 89.49 | 89.31 | +0.18 |
| D_TR_BL | 89.34 | 89.31 | +0.03 |

- The pattern is **close to 74 × 50**: X reads +0.30 to +0.32 and Y reads −0.24 to −0.32. The rectangle is square: the diagonals differ by 0.15.
- A uniform scale correction **does not explain it**. The best uniform factor is k = 1.0012, which leaves X at +0.22/+0.24 and Y at −0.30/−0.38. Matching 74 × 50 would take +0.42 % in X and -0.56 % in Y at the same time, and the MEG-Array pitch check rules out a ruler or scanner error of that size (the scale is good to about 0.1 %).
- The likely causes are real part tolerance and the free (unclamped) shape of the spring plate: its arms are slightly bent or joggled out of plane near the eyelets (visible as shading in the scan), so the projected spacing differs a little from the installed spacing.
- **Fit check**: the eyelet holes (Ø5.66) are about 0.33 mm per side larger in radius than Ø5.0. The worst corner offset against a 74 × 50 grid is about 0.2 mm, which fits inside that float, so the bracket is compatible with the 74 × 50 board pattern.

## Confidence / error

- Pixel size is about 0.34 mm. Edges come from the 50 % threshold between paper and part on an 8× cubic-upsampled image, so they are sub-pixel. Moving the threshold between 35 % and 65 % changes diameters by ±0.13 (holes), ±0.12 (eyelet OD), ±0.18/±0.14 (ring ID/OD) and ±0.14 (arm width). Hole **centres** move by less than 0.02.
- Circle-fit residuals are 0.05–0.10 mm rms. Scale uncertainty is about 0.1 % (≈0.08 mm over 74).
- Overall: hole centres and spacings ±0.15, diameters and widths ±0.2, envelope ±0.2. Out-of-plane spring shape adds an unknown projected-length error of up to a few tenths, which is the most likely reason for the ±0.3 departure from 74 × 50.
- The ring OD is not a perfect circle (it has fillets into the arms and a slight flat at the sides), so treat it as a fitted reference; the DXF polyline is the authoritative outline.
