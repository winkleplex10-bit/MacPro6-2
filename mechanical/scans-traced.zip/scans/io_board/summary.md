# Mac Pro 6,1 I/O (port) board: scan trace

All values are in mm. Board-local frame: **back-side view** (MEG-Array edge at the top, as in the back scan), origin at the **bottom-left** virtual sharp corner (left edge × bottom edge), X to the right, Y up. The front-view DXF mirrors X (X_front = W − X_back).

**Board thickness: UNKNOWN.** A flatbed scan can't measure it. Measure it with calipers (it's probably about 1.6 mm, but that is unverified).

## Files
- `io_board_outline.dxf`: layers BOARD_OUTLINE (closed LWPOLYLINE with true arcs), POWER_PLUG_CUTOUT (its own layer), MOUNT_HOLES (through-hole Ø plus 2 small MEG-flank holes), MOUNT_PADS, CENTER, DIMS, NOTES
- `io_board_features.dxf`: outline, cutout and holes, plus CONN_MEG_ARRAY, CONN_BOTTOM and CONN_STANDOFFS layers
- `io_board_ports.dxf`: front-side ports in the **same back-view board frame** (so it overlays directly on the outline DXF). `io_board_ports_frontview.dxf` is the same data mirrored to the front (port-side) view
- `io_board_overlay.png` (back scan with the trace overlaid), `io_board_dims.png` (dimensioned drawing), `io_board_front_overlay.png` (front scan with the back outline registered and the ports)

## Calibration

- Back scan (637×877 px, about 75 dpi): from the cm ticks of both printed cm rulers in each axis, X = 2.9692 px/mm, Y = 2.9472 px/mm. The scanner is anisotropic by 0.75 %, and this is corrected. The inner and outer rulers agree to within 0.02 %. Note: both rulers on this sheet are cm scales; there is no inch scale in the scan.
- **Independent scale check**: the MEG-Array contact pitch (nominal 1.27 mm) measures 1.2707 mm in Y and 1.2703 mm in X (+0.06 % / +0.02 %). That means the printed ruler is at true scale to within about 0.1 % in both axes.
- The ruler sheet is square to within 0.02°, so the scan has no skew.
- Edges were located at the maximum gradient (sub-pixel), so they don't depend on a threshold. Fixed thresholds of 100–150 move each edge by ±0.17 mm, and that spread was used to cross-check.

## Board outline

- **W × H = 101.00 × 173.62** (±0.2). The left and right edges are parallel to within 0.06°. The bottom edge runs 0.27° off square, with a peak-to-peak of 0.8 mm. It is partly obscured by the bottom connectors, so treat Y=0 as ±0.3.
- Bottom corners: R7.9 (BL) and R7.4 (BR), each ±0.3. Most likely the nominal is R7.5–8.
- Top corners are chamfered, not square. TL chamfer: 25.0 (X) × 19.9 (Y) to the virtual corner, at 38.5° from horizontal. TR chamfer: 25.4 × 20.2 at 38.4°. Fillets: chamfer-to-side R7.9/R8.1 (±0.5), chamfer-to-top R15.7/R17.1 (±1).
- There are no notches in the outline.

## Mounting holes (6, plated)

| hole | X | Y | pad Ø | through-hole Ø (est.) |
|---|---|---|---|---|
| TL | 4.13 | 146.76 | 7.77 | 3.8 |
| TR | 96.62 | 146.40 | 7.46 | 3.9 |
| ML | 4.06 | 77.96 | 7.27 | 4.3 |
| MR | 96.67 | 77.85 | 7.23 | 4.1 |
| BL | 4.11 | 18.80 | 7.71 | 3.8 |
| BR | 96.46 | 18.59 | 7.50 | 3.8 |

Spacings: X 92.49 (top) / 92.60 (mid) / 92.35 (bottom). Y left 68.79 (TL–ML) and 59.17 (ML–BL). Y right 68.55 and 59.25.
Centres are ±0.15. Pad Ø is ±0.2 (ML and MR are lower-contrast pads). The through-hole Ø is only an estimate, ±0.5: it's the bright core seen through the barrel, which is hard to resolve at 3 px/mm. Gauge it with a pin. Two more small holes (Ø≈2.8 ±0.5) flank the MEG-Array at (24.00, 163.75), (76.80, 163.56).

## Power-plug cutout (HARD REQUIREMENT, layer POWER_PLUG_CUTOUT)

- Shape: a rounded "octagon". The two **top** corners are 45° chamfers with filleted ends; the two **bottom** corners are plain radii.
- **Width 31.95 ± 0.15**, **height 22.98 ± 0.15**. Edges: X 34.46 → 66.41, Y 119.57 → 142.55.
- **Centre (50.43, 131.06)** ±0.15. That is -0.07 from the board centreline (W/2 = 50.50), so it is effectively centred. It is +0.06 from the TL/TR hole mid-point.
- Top of the cutout: 31.07 below the board top edge and 4.03 below the TL–TR hole line. Bottom of the cutout: 41.66 above the ML–MR hole line.
- Top chamfers at 45° (measured 44.8° / 45.3°), with legs to the virtual corner of 7.07 (TL) and 7.15 (TR), ±0.2. Fillets at the chamfer ends: R5.1/R5.0 (TL) and R5.4/R5.1 (TR), ±0.5. Bottom corners: R6.62 / R6.40, ±0.15.
- The traced edge deviates from the ideal shape by 0.032 mm rms (0.12 max). Area is 663 mm².
- Uncertainty budget: edge location ±0.08 per edge (gradient fit sd 0.015–0.07, ¼-pixel), scale ±0.05 % (0.02 mm), and threshold-model choice. Combined: about ±0.15 on width and height, ±0.2 on position relative to the board edges, ±0.15 relative to the holes.
- Recommendation: check it with calipers against the actual AC inlet. If the inlet body must pass through, add clearance (for example +0.25 mm per side) rather than copying the stock size line-for-line.

## Connectors (layer CONN_*, ±0.6–0.8)

- MEG_ARRAY_BODY: X 28.3–73.2, Y 154.8–172.6 (44.9 × 17.8), centre (50.8, 163.7)
- CONN_A_FLEX: X 5.5–14.3, Y 1.3–9.1 (8.8 × 7.9), centre (9.9, 5.2)
- CONN_B_HEADER: X 14.3–36.9, Y 0.3–11.3 (22.6 × 11.0), centre (25.6, 5.8)
- CONN_C_BODY: X 44.3–55.1, Y 2.2–7.7 (10.8 × 5.5), centre (49.7, 5.0)
- CONN_C_STANDOFF_L: centre (41.06, 5.17), Ø≈4.0
- CONN_C_STANDOFF_R: centre (59.92, 5.20), Ø≈4.0
- MEG-Array: 1.27 mm pitch receptacle (the pitch is verified above). Its body is flush with the top edge to within about 1.2 mm. CONN_A is probably the audio-jack flex connector; CONN_B is a box header; CONN_C is a connector flanked by two threaded standoffs.

## Front (port-side) scan cross-check

- Calibration from the FFT of the mm ticks: X 11.800 px/mm, Y 11.777 px/mm (at ¼ resolution, so about 1199 dpi at full resolution). Inner and outer rulers agree to within 0.03 %.
- The front scan is mirrored. It was registered (mirror plus rigid fit) to the back outline: rotation -0.22°, outline residual median 0.18 mm, p90 0.50 mm. Its board bounding box is 101.06 × 174.01, which matches the back scan to within blur (±0.5).
- Cutout at 50 % blurred edge: X 34.14–67.04, Y 119.22–142.63, centre (50.59, 130.92). The centre agrees with the back scan to within 0.2 mm. The size reads larger (+0.9 / +0.4) and depends heavily on threshold because the edges are defocused, so **the back-scan values are the ones to use**.
- Holes front vs back (blur-limited, ±1): TL ΔX -0.36 ΔY -0.36, TR ΔX +0.79 ΔY +0.78, ML ΔX -0.07 ΔY -0.29, MR ΔX -0.52 ΔY +0.40, BL ΔX -0.49 ΔY -0.50, BR ΔX +0.37 ΔY +0.39. These are consistent.

## Stock port openings (front side, shell outlines, ±1 mm; coordinates in the back-view frame)

| item | layer | X range | Y range | size | centre |
|---|---|---|---|---|---|
| HDMI | PORT_HDMI | 34.3–51.3 | 104.5–111.1 | 17.0×6.6 | (42.8, 107.8) |
| ETH_1 | PORT_ETHERNET | 55.8–71.5 | 85.9–99.8 | 15.7×13.9 | (63.6, 92.9) |
| ETH_2 | PORT_ETHERNET | 35.0–50.3 | 85.6–99.7 | 15.3×14.1 | (42.7, 92.6) |
| TB_a1 | PORT_THUNDERBOLT | 58.1–70.1 | 70.2–79.2 | 12.1×9.0 | (64.1, 74.7) |
| TB_a2 | PORT_THUNDERBOLT | 58.0–70.1 | 60.5–69.6 | 12.1×9.1 | (64.1, 65.0) |
| TB_a3 | PORT_THUNDERBOLT | 58.0–70.1 | 50.7–60.1 | 12.1×9.4 | (64.0, 55.4) |
| TB_b1 | PORT_THUNDERBOLT | 36.6–48.5 | 70.3–79.3 | 11.9×9.0 | (42.6, 74.8) |
| TB_b2 | PORT_THUNDERBOLT | 36.6–48.5 | 60.5–69.7 | 11.9×9.1 | (42.5, 65.1) |
| TB_b3 | PORT_THUNDERBOLT | 36.6–48.5 | 50.8–60.2 | 11.9×9.4 | (42.5, 55.5) |
| USB_a1 | PORT_USB_A | 54.7–73.0 | 37.9–47.8 | 18.3×9.8 | (63.9, 42.9) |
| USB_a2 | PORT_USB_A | 54.7–72.9 | 27.5–37.6 | 18.3×10.1 | (63.8, 32.5) |
| USB_b1 | PORT_USB_A | 34.0–53.1 | 38.0–47.9 | 19.1×9.8 | (43.5, 42.9) |
| USB_b2 | PORT_USB_A | 33.9–53.0 | 27.6–37.7 | 19.1×10.1 | (43.5, 32.6) |
| TB_BRACKET | TB_CENTRE_BRACKET | 48.4–58.1 | 50.3–80.5 | 9.7×30.2 | (53.3, 65.4) |
| SQUARE_PART_unidentified | OTHER_COMPONENTS | 69.5–91.4 | 131.4–150.5 | 21.9×19.0 | (80.4, 141.0) |
| LATCH_KNOB | LATCH_SLIDER | 15.1–29.5 | 47.9–62.3 | 14.4×14.4 | (22.3, 55.1) |
| TB_BRACKET_SCREW | TB_CENTRE_BRACKET | 53.1–55.7 | 56.3–58.8 | 2.5×2.5 | (54.4, 57.5) |
| COIN_CELL_BR2032 | OTHER_COMPONENTS | 9.3–31.1 | 125.1–147.0 | 21.8×21.8 | (20.2, 136.1) |
| LATCH_SLOT | LATCH_SLIDER | 12.4–30.3 | 42.8–86.1 | 17.9×43.3 | (21.4, 64.5) |

Notes:
- 2 Ethernet, 1 HDMI, 6 Thunderbolt (2 columns × 3, with a centre bracket strip and screw between them) and 4 USB-A (2×2) are traced. In the front view, the order from the cutout end is HDMI → Ethernet → TB → USB.
- The latch/lock slider is a stadium-shaped slot (≈17.9 × 43.3) with a round knob (≈Ø14.4).
- The round part next to the cutout (≈Ø21.8) looks like the BR2032 coin cell holder, not a port. The square part (≈21.9 × 19.0) at the other side of the cutout is unidentified; it could be the power-button switch or carrier, so check it.
- **The headphone and audio-out jacks and the power button could not be identified on this board.** The far end of the front scan is too defocused to show them. iFixit's teardown says the audio jacks connect to the I/O board by a ribbon cable, so they are probably not on this PCB. No geometry was invented for them.
